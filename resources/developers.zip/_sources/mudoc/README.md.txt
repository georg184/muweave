# MuDoc

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.

`mudoc` is the optional backend-neutral document-model layer for typed
MuWeave expansions. It classifies retained text and semantic values as
paragraph, inline, block, or mathematical structure without choosing LaTeX,
MyST, HTML, or another output target.

MuDoc is independently installable. MuWeave never imports it, and MuWeave's
ordinary string-returning expansion APIs do not activate document parsing.

## Current public model and layout plan

The public package deliberately exposes immutable model/layout values and its
generic parser/planner:

| Name | Meaning |
| --- | --- |
| `Text` | One original `muweave.ExpansionText` occurrence |
| `Inline` | One retained semantic value classified as inline content |
| `InlineMath` | One retained semantic value classified as inline mathematics |
| `Paragraph` | A nonempty ordered tuple of inline nodes |
| `Block` | One retained semantic value classified as block content |
| `DisplayMath` | One retained semantic value classified as display mathematics |
| `SemanticBody` | One retained positional body or named typed argument, recursively structured or explicitly opaque |
| `DocumentBoundary` | Exact source-mapped whitespace at one structural boundary |
| `Document` | Ordered blocks plus leading, internal, and trailing boundaries |
| `iter_semantic_nodes` | Parent-before-child traversal of evaluated semantic occurrences |
| `BoxSpacing` | One visible box's preferred internal and flow-edge clearances |
| `GapLength` / `GapUnit` | Portable body-relative and centimetre components retained until target rendering |
| `GapOperation` / `GapDirective` | Ordered boundary transformations and their original occurrence |
| `LayoutBox` / `ResolvedGap` / `BlockFlow` | A visible vertical box sequence with every boundary resolved |
| `OverlayBlock` | An annotation retained at a boundary without participating in body spacing |
| `plan_block_flow` | Vocabulary-classified vertical planning without rendering |

Every leaf keeps the original MuWeave typed-expansion object. Source spans,
generated-source producer chains, exact-copy status, literal protection,
structured command bodies, named structured arguments, and source metadata
are therefore retained rather than copied into a competing mapping format. Every node exposes ordered
`provenances`; boundary, paragraph, and document containers derive them from
their leaves without inventing one inaccurate coarse source span.

A vocabulary classifier may attach positional `SemanticBody` values through a
semantic node's `bodies` tuple and named values through its read-only
`arguments` mapping. Each child keeps the original `TypedExpansion` by
identity. Its `document` is a recursively parsed `Document`, or `None` when
the vocabulary declares the child opaque. MuDoc itself does not choose between
those alternatives.

When paragraph syntax splits one text part, `Text` still stores that original
`ExpansionText` together with relative `start_offset` and `end_offset` values.
Its visible text and immediate provenance are the corresponding precise view.

Immutability is structural: a node cannot be changed after construction. MuDoc
does not attempt to freeze an arbitrary Python object retained inside an
`ExpansionValue`.

```python
from mudoc import Document, Paragraph, Text
from muweave import ExpansionText, Provenance, ProvenanceKind, SourceText

source = SourceText("Kinematik", filename="lesson.muweave")
part = ExpansionText(
    text=source.text,
    provenance=Provenance(ProvenanceKind.SOURCE, source.span(0, len(source.text))),
    exact=True,
)
document = Document((Paragraph((Text(part),)),))
```

## Paragraph parsing

`parse_expansion()` converts a `muweave.TypedExpansion` into a `Document`.
Physical blank lines separate paragraphs; a single newline remains ordinary
inline whitespace. Exact text is clipped with exact source positions even when
a separator crosses two typed parts or inserted physical sources.
Recognized separators and whitespace-only edge regions remain in the
document's one-extra `boundaries` tuple. Parsing therefore classifies every
`ExpansionText` character exactly once instead of consuming formatting
whitespace. A LaTeX-oriented serializer can reproduce those leaves exactly;
an HTML serializer can use the same boundaries as structure without printing
raw source whitespace into the DOM.

The parser never guesses how a semantic value should be placed. Supply a
classifier that returns a node retaining the same `ExpansionValue` occurrence:

```python
from dataclasses import dataclass

from mudoc import Block, Inline, parse_expansion
from muweave import (
    ExpansionValue,
    MuWeaveContext,
    SemanticValue,
    expand_parsed_typed,
    parse_string,
)


@dataclass(frozen=True, slots=True)
class ExampleValue(SemanticValue):
    display: bool


def classify(part: ExpansionValue) -> Inline | Block:
    if isinstance(part.value, ExampleValue) and part.value.display:
        return Block(part)
    return Inline(part)


expanded = expand_parsed_typed(
    parse_string('before µExampleValue(display=True)'),
    MuWeaveContext({"ExampleValue": ExampleValue}),
)
document = parse_expansion(expanded, classify_value=classify)
```

The callback is optional for text-only expansions. Inline values join the
current paragraph; blocks and display mathematics close it. `lit` text remains
protected from MuWeave but uses normal paragraph syntax. Registered raw or
verbatim bodies remain opaque inside their `ExpansionValue` and are not
rescanned or split.

The concrete MuVocab adapter lives in `muvocab`, downstream of this generic
parser. `iter_semantic_nodes(document)` supplies deterministic parent-first
traversal through positional bodies and then named arguments, and stops at
opaque children. MuVocab
uses that generic traversal to apply its own numbering and reference policy;
MuDoc never imports or recognizes MuVocab values. Target renderers, templates,
publishers, and builders remain outside MuDoc's parser/model boundary.

`plan_block_flow()` is a separate pass over a `Document`. The caller receives
each node and its preceding `DocumentBoundary`, then supplies the visible
node's `BoxSpacing`, identifies it as a `GapDirective`, or marks a
target-inapplicable structural node as a `TransparentBlock`. Transparent
blocks contribute neither output nor an operation; their surrounding exact
boundaries are joined. Adjacent box requests reduce with
`max(previous.after, following.before)` before all directives at that boundary
run in source order. A following box's optional
`join_before` or a preceding box's optional `join_after` starts that internal
boundary at zero; directives still transform the result, and a target can
retain the structural relationship. Optional `at_start` and `at_end` values
let a vocabulary distinguish enclosing-flow edges from internal boundaries;
when omitted they reuse `before` and `after`. Negative values are retained.
`plan_block_flow(..., edge_requests=False)` is for an enclosing value that
already accounts for its child's outer box requests: start/end defaults are
zero, but explicit boundary directives and every internal request still apply.
It does not trim source text or turn the flow into one unbreakable box.
Optional `paragraph_break_before` and `paragraph_break_after` requests replace
the corresponding ordinary request when the complete retained boundary has a
blank line. MuDoc selects them only after invisible directives have joined
their surrounding whitespace, so a generated or file-backed directive cannot
accidentally hide the author's boundary structure.
Automatic requests begin as body-font components. Explicit operations may add
or replace a centimetre component; factors scale both independently. The
resulting `GapLength` deliberately remains unresolved so each target can emit
native font-relative and physical dimensions without converting through one
backend's font metrics. Every `ResolvedGap` also keeps its exact
`source_boundary`; invisible directives combine surrounding boundary parts in
source order.
An `OverlayBlock` is equally transparent to the spacing calculation, but is
retained in `ResolvedGap.overlays` for target-owned out-of-flow painting.
Renderers must handle leading, internal, trailing, and overlay-only flows;
an overlay must not create an empty paragraph or a body-height placeholder.
See [ARCHITECTURE.md](ARCHITECTURE.md) for the exact boundary model.

A classifier may return a complete `LayoutBox` instead of just `BoxSpacing`.
`inline_box=True` certifies that the original paragraph contains one native
inline box and otherwise only ordinary source whitespace. Targets can compose
its native extent without a text-line strut. MuDoc validates the shape and
retains the paragraph, identity, spacing and source boundaries unchanged;
it does not guess which semantic values support this placement.

## Measured boxes

The separate public submodule `mudoc.boxes` supplies `BoxBounds`,
`EdgeReserves`, and `BoxMetrics` for backend adapters. It records measured
content and layout bounds, a baseline, anchors, and certified automatic edge
reserves in local centimetres. These immutable measurements are separate from
both semantic nodes and the structural `LayoutBox` spacing plan above.

`BoxMetrics.trim()` removes only certified automatic outer reserves;
deliberate padding, phantoms and explicit bounding boxes remain intact.
Unknown provenance is an error, not permission to guess from empty space.
See [the measured-box API and examples](docs/BOX_METRICS.md). This foundation
does not itself measure HTML/LaTeX or add author-facing MuVocab commands.

MuWeave source executes unrestricted Python code before MuDoc receives a typed
expansion. Process only trusted sources and contexts.

See [ARCHITECTURE.md](ARCHITECTURE.md) for the dependency and source-mapping
boundary.
