# pymyst examples

Audience: pymyst users and package maintainers

The self-contained worksheet shell now lives in
`../src/pymyst/offline_worksheet_template.html` and is filled by pymyst's
offline builder. A project-mode build creates a sibling `.html` file that can
be opened directly in a current browser; it needs neither a server nor external
resources.

The shell displays only the expanded author body and explicitly supplied
metadata; it does not inject its former response field, graphic slot, or sample
page. It provides vector pen strokes and export to a new independently usable
HTML copy. A concise MuVocab author API for stable response and graphic slots
is still open. The separate `pymyst --html` switch still selects the
conventional large MyST site.
