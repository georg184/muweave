# pymyst

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.

PyMyST is the MyST frontend for MuWeave. It expands trusted MuWeave source to a
standalone MyST page or complete one-page project, publishes local assets, and
builds one self-contained offline HTML worksheet by default in project mode.
It can also run the conventional MyST site or an experimental MyST PDF build.

MuWeave owns parsing and expansion. `muvocab` is the default portable author
vocabulary and supplies MyST renderers for its semantic values.

> **Security warning:** PyMyST documents, selected vocabularies, and custom
> templates execute unrestricted Python code. Process only trusted inputs.

Python 3.13 or newer is required.

## Command line

Low-level mode writes only expanded page text:

```console
pymyst chapter.pymyst                 # writes/replaces chapter.md
pymyst chapter.any --output out.md    # exact destination
pymyst -                              # stdin to stdout
```

Complete standalone frontmatter is enabled with `--document`. A project has
fixed `index.md`, `myst.yml`, and `pymyst.mjs` files and builds a sibling
self-contained HTML worksheet unless disabled:

```console
pymyst chapter.muweave --document --output chapter.md
pymyst chapter.muweave --project chapter.myst
pymyst chapter.muweave --project chapter.myst --no-offline-html
```

The default project build creates `chapter.html`; open it directly from the
file manager. The conventional large MyST site is a separate opt-in:

```console
pymyst chapter.muweave --project chapter.myst --html
```

Experimental PDF is opt-in. Unless `--no-offline-html` is also present,
project mode retains the normal offline worksheet alongside it:

```console
pymyst chapter.muweave \
  --project chapter.myst \
  --pdf
```

The implicit experimental PDF is `chapter_myst.pdf`. An explicit
`--pdf-output PATH` remains an exact destination.

Standalone file output publishes registered local assets beneath the output
directory's `assets/` tree. Standard output cannot carry such companion files
and is rejected when assets were registered. See the [complete usage
guide](docs/USAGE.md) for every CLI option, output and build rule,
project/template contract, layered `.mu`/`µ!` settings, and exit status.

## Python API

The simplest core-only API is:

```python
import pymyst

result = pymyst.expand_string("The answer is µexpr(6 * 7).")
assert result == "The answer is 42."
```

For MuVocab source, use its factory rather than a bare backend context:

```python
import muweave
import muvocab
import pymyst

schema = muvocab.create_text_command_schema()
context = muvocab.create_myst_context(schema)
parsed = muweave.parse_string(
    'Das ist µemph{wichtig}.',
    source_name="chapter.muweave",
    text_command_schema=schema,
)
myst = pymyst.expand_parsed(parsed, context, output_name="chapter.md")
```

`build_document` returns one complete page. `build_project` returns an
immutable in-memory project description; `publish_document` and
`publish_project` perform filesystem publication; `build_html` and `build_pdf`
invoke external MyST. A bare `PymystContext()` installs no MuVocab operations.

## Offline worksheet

The project-mode sibling `.html` opens directly from the local filesystem
without a server or network. Its fixed logical document geometry contains only
the expanded author body and explicitly supplied metadata; the worksheet shell
does not add sample prose or sample pages. A fixed palette sits to the left;
one transparent annotation canvas spans the document but not the palette.
Document mode exposes links and author-provided controls, while a drawing tool
activates the canvas. Narrow viewports scroll instead of reflowing the document,
and the view-scale control transforms text and annotations together. Dragging
the splitter at the palette's right edge changes its width; the size of its
controls and the document scale can be adjusted independently with two compact,
fixed `−`/`+` controls at the top. All settings are saved with the worksheet.

The shell provides pressure-aware vector ink,
pen/fountain/highlighter profiles, partial or whole-element erasing, four straight-line styles,
also available for freehand curves and selected through compact visual pattern
buttons, endpoint snapping, lasso movement, and a ruler. Saving embeds
author-provided responses and normalized global stroke points in a new
self-contained HTML copy. The concise MuVocab author API for placing graphic
insertion slots is still open; see the
[example note](examples/README.md).

## Documentation

- [Frontend usage and public API](docs/USAGE.md)
- [MuWeave Suite agent guide](../muweave-suite/docs/AGENT_AUTHORING.md)
- [MuWeave language topics](../muweave/docs/SYNTAX.md)
- [Offline ink dependency decisions](DEPENDENCIES.md)

## Development

From the workspace root:

```console
./pythonvenv1_dbg/bin/python -m unittest discover \
  -s pymyst/tests -p 'test_pymyst_*.py' -v
```

The normal suite mocks external tools. Real MyST builds are explicit opt-ins
through `PYMYST_RUN_MYST_INTEGRATION=1` and
`PYMYST_RUN_PDF_INTEGRATION=1`. Selected durable conditions are in
[REQUIREMENTS.md](REQUIREMENTS.md); unfinished decided work is in
[TODO.md](TODO.md).
