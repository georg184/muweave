# pytex5 executable examples

Every source in this directory is processed by the real command-line interface
and compared byte-for-byte with its neighboring expected output in
`tests/test_pytex5_examples.py`.

> **Security warning:** these setup scripts and documents execute unrestricted
> Python code. Apply the same trust requirement to your own projects.

## Complete document

The `complete/` pair exercises the end-to-end document from the original
design: canonical Python calls, stateful TikZ helpers, indexing, attributes,
`expr`, dynamic `eval`/`exec`, registered nested brace commands, rendering, and
a literal marker.

```bash
pytex5 examples/complete/document.pytex \
    --setup examples/complete/setup.py \
    -o /tmp/pytex5-complete-output.tex
```

The result should match `examples/complete/expected.tex`.

## Focused documents

All focused examples share `focused/setup.py` except `literal-markers.pytex`,
which requires no setup:

| Source | Demonstrates |
| --- | --- |
| `calls-and-expr.pytex` | canonical calls, attributes, indexing, and `expr` |
| `deferred.pytex` | late values, no-rescan output, references, and raw quotation |
| `dynamic.pytex` | context-bound `eval`, `exec`, and persistent definitions |
| `text-commands.pytex` | nested braces, raw modifiers, and post-body trailers |
| `rendering.pytex` | `None`, strings, `__pytex__`, registry, fallback, containers |
| `verbatim-showcase.pytex` | protected inline/block source and source/result views |
| `literal-markers.pytex` | marker escapes, impossible starts, unnamed form, raw `%` |

For example:

```bash
pytex5 examples/focused/text-commands.pytex \
    --setup examples/focused/setup.py \
    -o -
```

Here `-o -` makes the result easy to compare with the committed expected file.
Without that option, pytex5 creates
`examples/focused/text-commands.tex`. Expected files are intentionally
committed rather than generated during tests. A behavior change therefore
requires an explicit review of both source and output.
