# pytex5

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.

PyTeX5 is the LaTeX frontend for MuWeave. It expands trusted MuWeave source to
a LaTeX fragment or complete document, owns LaTeX rendering and templates, can
run LuaLaTeX, and provides experimental lwarp HTML support.

MuWeave retains scanning, Python evaluation, recursive expansion, references,
provenance, and generic diagnostics. The default portable vocabulary is
provided by `muvocab`.

The default font setup includes content-aware matrix and optical-fraction
primitives. They measure native math boxes without inheriting paragraph line
spacing or redefining ordinary `\frac`; see `ARCHITECTURE.md`. Custom templates
can use the same undelimited matrix primitive for configured parenthesis
sizes and inner clearance without resizing the content. Templates
using these vocabulary values must include `font_setup()` or its equivalent
inner-math setup as described in MuVocab's authoring guide. It also supplies
the native box primitives for measured equation trimming, isolated inline
drawings and column alignment without table-cell struts. These need the same
setup in custom templates; ordinary text-line spacing remains unchanged.

Structured document templates also make semantic flow the sole owner of
quotation spacing. The native `quote` keeps its side insets and page breaks,
but contributes no list or paragraph skips of its own. MuVocab's before/after
requests and explicit gap overrides therefore apply symmetrically. Low-level
fragments and core-only documents retain their enclosing template's policy.

> **Security warning:** PyTeX5 documents, selected vocabularies, setup files,
> and custom templates execute unrestricted Python code. Process only trusted
> inputs.

Python 3.13 or newer is required.

## Command line

Low-level preprocessing invokes no compiler:

```console
pytex5 chapter.pytex                 # writes/replaces chapter.tex
pytex5 chapter.any --output out.tex  # exact destination
pytex5 -                             # stdin to stdout
```

Complete-document mode wraps the author body in a trusted template and enables
PDF by default:

```console
pytex5 chapter.muweave --document --title "Mechanics"
pytex5 chapter.muweave --document --no-pdf --output chapter.tex
```

To additionally extract physical PDF pages after compilation:

```console
pytex5 chapter.muweave --document --pdf-extract-pages 5-8
```

This keeps the complete `chapter.pdf` and writes `chapter_pages_5-8.pdf` beside
it. Repeat the option for separate excerpts, or supply a single page number.
The operation requires MuPDF's `mutool` on `PATH`; ordinary PDF builds do not
require it unless another selected feature uses it. See
[PDF page excerpts](docs/USAGE.md#pdf-page-excerpts) for naming and validation.

PDF exams can opt into an inherited A/B batch with this source directive:

```muweave
µ! pytex5 --groups=A,B
```

Then `pytex5 exam.muweave` builds `exam_A.pdf` and `exam_B.pdf`, with separate
LaTeX sources and fresh frontend processes. `--groups` implies document mode;
the plain command is not a low-level fragment expansion for this source.
An explicit `--config group=B` builds only B; `--no-groups` restores one ordinary
unsuffixed output. `--output` and `--pdf-output` are filename **bases** in
batch mode. See [PDF series builds](docs/USAGE.md#pdf-series-builds).

For one print job containing an independently shuffled exam per learner:

```console
pytex5 exam.muweave --exam-copies 24
pytex5 exam.muweave --exam-copies 24 --exam-seed class-9
```

This builds 24 total copies in A/B order and publishes `exam_gesamt.pdf`,
`exam_gesamt.exam-batch.json` and `exam_gesamt.quellen.tar.gz` in a **new**
timestamped directory under `exam_Druckbestände`. Existing packages and loose
outputs are never replaced. Copies compile sequentially in fresh processes;
temporary individual artifacts are removed after their seeds, page ranges,
and available scan manifests are retained in the durable batch JSON. Reusing
the master seed reproduces the learner batch; teacher copies replay the
recorded accepted per-copy seeds. See [combined exam copies](docs/USAGE.md#combined-exam-copies) for group
selection, replay, external-tool requirements, and manifest interpretation.

Already printed trios can be validated and copied into separate timestamped
directories using `pytex5.print_package`. This is also Schoolman's shared
import interface. It never recompiles an archived source. See
[retaining print packages](docs/PRINT_PACKAGES.md) for automatic build-time
source capture, original MC keys, provenance limits and Schoolman import.
Only the PDF is for learners; both companions contain teacher-only material.

Exam batches now use **format three**: per-copy semantic free-response tasks
are retained with optional model solutions and exact inline checkpoint scores.
Missing marking is explicitly pending and does not prevent printing. Later
revisions are separate, original-print-bound supplements, never replacements
of a printed trio or MC results. `--exam-replay PRINT_DIRECTORY` rebuilds a new
batch using the actual recorded permutations. For marking alone,
`pytex5.grading_build.compile_grading_draft` avoids a native PDF rebuild.
See [post-print grading](docs/EXAM_GRADING.md) for the public producer/reader
interfaces, approval boundary and legacy limitations.

The built-in template is A4 with an explicit 10 pt Latin Modern Sans text face
and Latin Modern Math. It centers a body occupying 76% of the paper width and
85% of its height. Override either fraction with
`--body-width-ratio` or `--body-height-ratio`.
With MuVocab's exam page style, the height ratio instead describes the complete
header/text/footer frame on every page, including the footer depth. The text
area is reduced accordingly; grading/name fields and private margin notes stay
outside the flow. See [exam geometry](../muvocab/docs/AUTHORING.md#exams-and-occurrence-specific-points).

Complete MuVocab documents include a front **Inhaltsverzeichnis** with clickable
titles/page numbers and matching PDF outline bookmarks. `--config ~toc` omits
both; `--config toc.max_level=1` limits navigation depth without removing any
content. The default includes logical levels 0–2, also unnumbered headings.
The original body starts on a fresh page after the contents; page numbers
include these front pages. LuaLaTeX runs automatically until references and
contents pagination stabilize (two to six passes). See the
[contents guide](docs/USAGE.md#table-of-contents-and-pdf-outline).

Experimental lwarp uses a dedicated project. Publish its source and assets
without either external builder with both negative switches:

```console
pytex5 chapter.muweave --html        # creates chapter_lwarp/
pytex5 chapter.muweave \
  --html-project chapter_lwarp \
  --no-html \
  --no-pdf
```

Automatic project names always gain a fresh `_lwarp` marker. An explicit
`--html-project DIRECTORY` remains exact; ordinary `--output` is not accepted
in lwarp mode.

All selected files are published atomically per file and replace existing
build artifacts. The input source remains. See the
[complete usage guide](docs/USAGE.md) for every CLI option, default, output
rule, template contract, asset mode, layered `.mu`/`µ!` setting, builder, and
exit status.

## Python API

The root package deliberately exports only PyTeX5-owned context, expansion,
document/PDF, rendering, and LuaLaTeX-diagnostic APIs. Import format-neutral
types from `muweave`; experimental lwarp operations live in `pytex5.lwarp`.

For core-only source:

```python
import pytex5

result = pytex5.expand_string("The answer is µexpr(6 * 7).")
assert result == "The answer is 42."
```

For source using MuVocab, create its schema and target context together:

```python
import muweave
import muvocab
import pytex5

schema = muvocab.create_text_command_schema()
context = muvocab.create_latex_context(schema)
parsed = muweave.parse_string(
    'Das ist µemph{wichtig}.',
    source_name="chapter.muweave",
    text_command_schema=schema,
)
latex = pytex5.expand_parsed(parsed, context, output_name="chapter.tex")
```

A bare `PytexContext()` does not install MuVocab. It adds only core/LaTeX
facilities, the target-specific `verb` and `verb_block` commands, and a legacy
LaTeX showcase for compatibility. When a vocabulary schema declares
`showcase`, as MuVocab does, that portable vocabulary operation owns the name.

## Documentation

- [Retaining and importing print packages](docs/PRINT_PACKAGES.md)
- [Version-three tasks and later marking revisions](docs/EXAM_GRADING.md)
- [Measured scan manifests](docs/SCAN_MANIFEST.md): opt-in export of actual
  answer/name rectangles, arbitrary-count reference marks and exact PDF binding.
  Format two also measures the first-page grading table and individual writable
  task/total/grade fields, separately from learner answers. Old prints remain
  unchanged and have no inferred return coordinates.
- [Frontend usage and public API](docs/USAGE.md)
- [LuaLaTeX diagnostic mapping](docs/LUALATEX_DIAGNOSTICS.md)
- [Frontend architecture and out-of-flow annotations](ARCHITECTURE.md)
- [MuWeave Suite agent guide](../muweave-suite/docs/AGENT_AUTHORING.md)
- [MuWeave language topics](../muweave/docs/SYNTAX.md)

## Development

From the workspace root:

```console
PYTHONPATH=pytex5/src:muweave/src \
  ./pythonvenv1_dbg/bin/python -m unittest discover \
  -s pytex5/tests -p 'test_pytex5_*.py' -v
```

The normal suite mocks external tools. Real LuaLaTeX and lwarp tests are
explicit opt-ins through `PYTEX5_RUN_LUALATEX_INTEGRATION=1` and
`PYTEX5_RUN_LWARP_INTEGRATION=1`. Selected durable conditions are in
[REQUIREMENTS.md](REQUIREMENTS.md); unfinished decided work is in
[TODO.md](TODO.md).

The real PDF navigation tests also use `pdftotext`, `mutool`, and Pillow. They
run with temporary output/font-cache directories and verify actual ink and
page destinations, including multi-page contents:

```console
PYTEX5_RUN_LUALATEX_INTEGRATION=1 ./pythonvenv1_dbg/bin/python \
  -m unittest discover -s pytex5/tests -p test_pytex5_navigation_integration.py
```
