# muvocab

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.

`muvocab` is the batteries-included, target-neutral author vocabulary for
MuWeave documents. Its constructors return semantic values; fresh LaTeX,
MyST, direct-HTML, and semantic-AI contexts interpret those values for
`pytex5`, `pymyst`, `pyhtml`, and `pyai`. A separate fresh document context
retains them in MuDoc without selecting a target.

The bare command `µweave` inserts the **µWeave** wordmark using its woven µ
symbol. HTML/MyST and PDF share the same artwork; AI retains the readable name.
Technical identifiers and `.muweave` filenames stay unchanged. See the
[product-name reference](docs/AUTHORING.md#product-name).

General `variant` scopes select reusable content before nested evaluation.
Content constructors and file/item insertions accept `variant=`, while
`variant.values(name, factory)` supplies optional sequence entries before their
consumer validates them. Repeated reference labels select the last preceding
occurrence by default, with explicit occurrence overrides. See
[variants](docs/AUTHORING.md#general-content-variants) and
[reference occurrences](docs/AUTHORING.md#repeated-reference-names).

Named people use a canonical catalogue: `µperson.Newton`, a custom spelling
through `text=...`, a PDF short-biography footnote through `footnote=True`, or
a complete `µblock.person(person.Newton)` profile. Direct HTML embeds
accessible information cards; AI retains identity, biographies and named
resources. Configure `--persons-dir` or `MUWEAVE_PERSONS_DIR`. See
[people and reusable biographies](docs/AUTHORING.md#people-and-reusable-biographies)
for the source format and target support.

Mathematical `v(...)`/`Matrix(...)` use compact, content-aware row spacing in
HTML/PDF. `frac(...)` / `µfrac{numerator,,denominator}` provide optical fraction
clearance without moving the mathematical axis or changing raw `\frac`.
A configurable reduction strength shrinks only native gaps above the selected
threshold, keeping smaller gaps unchanged instead of equalizing everything.
Explicit fences and matrix parentheses have a configurable inner clearance;
matrix parentheses can use automatic or fixed sizes without scaling content.
`muvocab.math_defaults.DEFAULTS` exposes the immutable defaults used by the
renderers, including the fraction preset `gap_em=0.12`, `reduction=0.5`.
See [Mathematics](docs/AUTHORING.md#mathematics) for the shared settings,
composition forms, and target-specific limitations.

`root(index, radicand)` / `µroot{n,,x}` retains an indexed root without
simplification. `sqrt(radicand)` / `µsqrt{...}` is the fixed square-root
specialization. Both accept nested mathematical objects or µ-bearing source
strings; the index expands before the radicand, exactly once. Native MathML
and semantic AI preserve both operands. See the
[root reference](docs/AUTHORING.md#portable-roots) for validation and examples.
Portable mathematics projects directly to Typst for PyHTML's default native
MathML renderer. It applies the same optical policies to measured native
MathML/font boxes; uncovered operations still fail explicitly. PyHTML's
`--math-renderer=mathjax` selects the legacy renderer; the document-build
command uses the target-qualified `--html-math-renderer=mathjax` spelling.
`µcal.A`, `µcal{Hallo Welt}` and Python `cal("Hallo Welt")` share one portable
calligraphic mathematical value. The existing `\mathcal` appearance retains
calligraphic capitals and mathematical italic lowercase, with literal spaces.
The automatic A-/L-navigation links use the same renderer. See the
[calligraphic alphabet](docs/AUTHORING.md#calligraphic-alphabet) contract.
Portable `mtext`, `mop`, `lim`, `accent`, `ol`, `overunder`, `mathstack` and `mathspace`
also retain unsimplified mathematical notation. Native HTML supports graphic
labels, equation previews, measured box layout and Reader notebook output;
see the [notation reference](docs/AUTHORING.md#portable-text-operators-accents-and-explanatory-notation)
and the linked renderer coverage guide.
`lim(variable=None, to=None, *, side=None)` describes a limit without computing
it. Use bare `µlim`, `µlim{x,,0}`, or `µlim[right]{x,,0}` for a one-sided
approach. Both operands retain nested mathematics and annotations; native
MathML and PDF choose operator placement from the surrounding math style.
See [limits](docs/AUTHORING.md#limits) for validation and target details.
`ol(value)` / `µol{...}` selects a mathematical overline over a string or
mathematical object, sharing the existing bar-accent semantics in every target.
Bare `µpara` and `µequi` express parallelism and equivalence. `µpara[-sp]`
and `µequi[-sp]` suppress only their occurrence-local automatic relation
spacing. Bare `µsp` or `µsp(factor)` adds a signed multiple of one thin
mathematical space (three mu); these layout choices do not change AI meaning.
Bare `µd` supplies an upright mathematical differential symbol, as in
`µfrac{µd x,,µd t}`. For calculations, `Term.diff(variable, order=1)` derives
scalar expressions symbolically, including dropdown alternatives.
`Term.integrate(variable, lower=None, upper=None)` supplies symbolic
antiderivatives or definite integrals. `g.area(...)` draws sign-separated
function fills with optional live bounds; it shares explicit discontinuity
breakpoints with `g.plot(...)`. See the
[calculus graphics contract](docs/AUTHORING.md#scalar-function-plots-signed-areas-and-riemann-sums).

MuWeave documents execute unrestricted Python code. Process only trusted
documents and trusted vocabulary modules.

## Authoring example

The same `.muweave` body can target LuaLaTeX, MyST, and direct HTML:

```text
µsection(title="Kinematik", label="sec:kinematik")

Die µmetadef{Kinematik} beschreibt die Bewegung von Körpern.

µblock.problem[label="problem:fall"]{
Beschreibe den Unterschied zwischen Ort und Weg.
}

Siehe µref("problem:fall").
```

Build both normal targets with:

```console
muweave lesson.muweave --title "Mechanik"
```

MuVocab currently covers:

- logical sections and portable references;
- a shared immutable heading outline with validated `toc`/`toc.max_level`
  selection, collapsible direct-HTML navigation, and native PDF contents pages
  with page links and outline bookmarks (see
  [the document-model guide](docs/DOCUMENT_MODEL.md#complete-outline-and-contents-selection));
- explicit lazy inclusion or exclusion of genuinely target-specific source;
- school-specific `µgym{...}` / `µfms{...}` content selected lazily by the
  independent `school=gym` / `school=fms` setting; see
  [school selection](docs/AUTHORING.md#school-specific-content) for inherited
  directory defaults, validation and all-target behavior;
- deferred private author notes, immutable publication suppression, and
  working-only structured-item identity markers;
- explicit portable annotations for tooltips, colors, and block spacing;
- scoped author guidance for the HTML learning coach through
  [`coach`](docs/AUTHORING.md#coaching-instructions), retained in semantic AI
  without printing the instructions in the worksheet;
- deterministic direct-HTML block spacing and ordered gap adjustments;
- backend-neutral sRGB colors with readable standard names and a semantic
  document palette;
- inline/display mathematics, symbolic scalar terms, affine points, column
  vectors, matrices, composable physical units and quantities, fences, and
  sets;
- generated Cartesian coordinate systems with reusable data scales and local
  alignment anchors, explicit 3D cameras, immutable lines, circular arcs, general arrows,
  named vector arrows, Hobby interpolating curves, and visible point markers
  with mathematical labels at fixed physical polar offsets, with shared projection for
  HTML and LaTeX, plus portable calibrated angle markers projected through
  registered native-MathML, MathJax/SVG and LuaHBTeX/TikZ profiles and retained without fitted
  presentation geometry by semantic AI;
- segment, vector and triangle side names use exact-profile MuGeometry
  calibration by default, with an explicit `0.2 em` fallback where evidence is
  absent; `label_clearance_em` sets a measured stroke-edge gap and an explicit
  `label_offset` retains a fixed centre-to-centreline distance;
- `g.curve(*points, ...)` interpolates numeric 2D knots using MuGeometry's
  dependency-free Hobby calculation. HTML and PDF draw the same native cubic
  Bézier controls; AI retains the knots, interpolation parameters and controls.
  See the [curve guide](docs/AUTHORING.md#hobby-interpolating-curves);
- natural-size inline `g.canvas` drawings and standalone/composed `g.triangle`
  figures with portable labels, layout-only bounding boxes, per-edge padding
  and explicit text baselines; vertex names follow the outward extensions of
  the visible interior angle bisectors in HTML/PDF. See the
  [drawing guide](docs/AUTHORING.md#free-inline-drawings-and-triangles);
- native parameter-driven content traced once from symbolic controls: compose
  axes and read-only `ui.output` fields with ordinary layouts, including
  vertically stacked `layout.rows(...)`, moving
  named segments, scalar/vector results, checkbox visibility and automatic
  label fitting. HTML updates a closed expression
  protocol, PDF renders authored defaults, and AI retains symbolic meaning;
- optional coordinate zoom and drag panning with `g.axis(zoom=g.zoom(...))`,
  coupled slider ranges that preserve interior values, retain sliders at their
  reached boundary and increase display
  precision, plus reusable `ui.condition`
  domains shared by line segments, arrows and computed outputs;
- `g.point(..., draggable=True)` binds direct 2D point movement to existing
  optionally hidden slider parameters, including fixed coordinates, range/step limits and
  synchronized dependent geometry. HTML supports pointer and keyboard input;
  PDF uses defaults and AI retains the intended movement. See
  [draggable points](docs/AUTHORING.md#draggable-points);
- emphasis, bold and underlined text, shared signed font-size steps,
  pedagogical blanks, layout phantoms, horizontal width partitions, and
  completion markers;
- general semantic enumerations with vertical or grid presentation and stable
  owner-qualified entry references;
- ordinary text, indented quotation, single-formula/aligned-equation, theorem,
  definition, remark, attention, proof, problem, exercise, sample-problem, and
  solution blocks;
- native `block.applet` items with full HTML content, a PDF description with a
  clickable margin QR code, and complete semantic AI; see the
  [applet contract](docs/AUTHORING.md#native-applet-items);
- portable block counters, labels, tags, and nested blocks;
- structured reusable `.muweave` block files, including canonical numeric
  `item=` occurrences from one configured library;
- expandable/protected file insertion, canonical shared-image lookup, local
  images, and single-image figures;
- clickable, source-anchored QR-coded web links placed in the document margin
  by default, with offline inline SVG for direct HTML and vector output for
  LaTeX;
- dedicated `block.canvas` and `block.response` items through the ordinary
  `file=` / `item=` interface, strongly recommended for independent response
  areas with stable item/part/input identities; see
  [response authoring](docs/AUTHORING.md#worksheet-response-fields);
- named fixed-geometry text responses, graphic insertion fields, and item-owned
  handwriting canvases whose paper can derive from padded immutable underlays
  for direct HTML worksheets and printable LaTeX;
- literal inline/block presentation and static or native-editable source/result
  showcases;
- selected-location keyword and symbol directories.

Ordinary Python expressions remain available. Optional `{...}` and
`[...]{...}` spellings come from MuVocab's shared text-command schema.

Measured equation-edge trimming is available as `layout.trim(value)` or
`block.equation(...).trim()` in structured HTML and LuaLaTeX. It preserves
explicit space, source/identity and AI meaning. Initially, general text-flow
and horizontal equation measurements are rejected, not guessed. See
[authoring details](docs/AUTHORING.md#measured-outer-edge-trimming).

An isolated `g.canvas` or `g.triangle` is composed as a native box in HTML and
complete PyTeX5, without incidental text-line reserves. In `layout.columns`,
alignment uses actual box edges/centres; mixed prose retains normal baselines.
Explicit graphic bounds, padding and external spacing remain unchanged.

Structured equations accept `row_gap="0.35em"` (also numeric em or cm)
for explicit clearance between native row boxes, independently of `.trim()`.
Omitting it preserves automatic spacing. HTML and LuaLaTeX support all system
shapes; AI omits the pure layout setting. See
[row clearance](docs/AUTHORING.md#equation-row-clearance).

Named `layout.columns` dependencies can fit one isolated canvas or triangle to
another column's measured height: `names=("grafik", "formeln")` with
`height_from={"grafik": "formeln"}`. Geometry scales uniformly; physical
typography and strokes do not. HTML/LuaLaTeX diagnose conflicting constraints;
AI retains the original content only. See
[dependent graphic height](docs/AUTHORING.md#dependent-graphic-height).

## Documentation

Exams use reusable `block.exam_problem` placements with occurrence-specific
points and explicit `Exam` identity. `block.exam_header` derives a grading grid
from those same placements; optional item history stays in a separately
selected part and compilation never writes it. See
[exams and points](docs/AUTHORING.md#exams-and-occurrence-specific-points).

`ExamRubric` and `grading` keep numerical marking plans in the exam while
reusable solutions contain named checkpoints. Inline score circles and private
working-time/difficulty notes are portable; use `ExamRubric(...,
duration_minutes=4, difficulty="mittel")` with `µgrading.time()` for one combined
private note (`leicht`, `mittel`, or `schwer`; both estimates are optional).
Shared validation checks task totals and
complete, nonduplicated checkpoints. Ungraded reuse emits neither annotation.
`muvocab.exam_export.export_exam_grading` projects already expanded PyAI tasks
and solution checkpoints into private print-format-three evidence, with both
semantic JSON and ordinary Markdown. Omitted solutions remain pending, and
MC tasks use their separate original-key protocol. This is a Python integration
API, not another author command; see
[later marking supplements](../pytex5/docs/EXAM_GRADING.md).
Task headings read `1. (4 Punkte)` or `1. (1 Punkt)`, without an automatic
kind name; semantic block identity and numbering remain unchanged.
Solutions owned by an `exam_problem` omit the visible solution heading and
completion marker, attached or detached. Their solution semantics, references
and item-owned response canvases remain intact; ordinary tasks are unchanged.
The exact `Exam.group` (A, B, N, N2, ...) is printed in the PDF footer.
`µgroup{...,,...}` lazily selects content for `config["group"]`;
`group(A=..., B=..., N2=...)` also selects ordinary Python values. The PDF
grading table sits above the first header; name fields repeat on odd pages.
These overlays do not affect document flow. On every exam page the height
ratio includes the complete header and footer; measured head/foot rules are
symmetric. The first page can retain its own height through
`exam.first_page_body_height_ratio`; see the linked exam guide.
With PyTeX5 scan setup, structured exam headers also export measured table,
task-point, total-point and grade blanks. These native PDF annotations consume
no additional space, create no learner inputs and do not alter HTML/AI semantics;
see the [return-field contract](../pytex5/docs/SCAN_MANIFEST.md#grading-table-return-fields-version-two).
`Exam.topics` appears only as a private first-header margin note;
`duration_minutes` is metadata without automatic visible output.
An explicit `course_label` changes the header without changing `course`.
AI retains these exam facts independently of their private visual projection.

`block.single_choice` and `block.true_false` define reusable item-owned
questions with stable option/input keys and optional solution explanations.
`block.multiple_choice(items=(...))` assembles canonical question IDs with
fresh shuffled question/answer order and one aggregate scoring floor. Use
`exam.shuffle_seed` for deterministic shuffling or an exact retained
`exam.choice_order` plan for historical replay. Hidden solutions remove correct
keys and explanation source before nested evaluation; HTML and its embedded
AI share the exact same retained permutation. See the
[choice-question reference](docs/AUTHORING.md#single-choice-truefalse-and-multiple-choice-groups)
for exact signatures, scoring, exam rubrics and target limits.

- [AI-agent authoring guide](../muweave-suite/docs/AGENT_AUTHORING.md): complete system workflow,
  language, tools, examples, and quick reference.
- [Detailed authoring reference](docs/AUTHORING.md): MuVocab semantics, target
  behavior, validation, configuration, and worked examples.
- [Generated author API inventory](docs/AUTHOR_API.md): mechanically complete
  installed names, call shapes, target availability, and brace-schema policy.
- [Linear-algebra and 3D graphics reference](docs/LINEAR_ALGEBRA.md): terms,
  coordinate and symbolic points/vectors, matrices, cameras, and projection.
- [MuDoc integration](docs/DOCUMENT_MODEL.md): target-neutral typed evaluation,
  explicit semantic placement, recursive bodies, and opaque boundaries.
- [Human Sphinx guide](../muweave-suite/docs/index.rst): progressive tutorials, recipes,
  troubleshooting, and public Python API reference.
- [Runnable examples](examples/): portable sources, a structured block file,
  a local asset, and parse-once Python expansion.

Build the human HTML documentation without writing generated files into the
package:

```console
./pythonvenv1_dbg/bin/python -m sphinx \
  -W --keep-going -b html muweave-suite/docs /tmp/muweave-sphinx-html
```

## Python integration

Create the parse-time schema once, then create a fresh context for each target:

```python
import muweave
import muvocab
import pyai
import pyhtml
import pymyst
import pytex5

source = 'µsection(title="Kinematik")\nDas ist µbold{wichtig}.'
schema = muvocab.create_text_command_schema()
parsed = muweave.parse_string(
    source,
    source_name="chapter.muweave",
    text_command_schema=schema,
)

latex = pytex5.expand_parsed(
    parsed,
    muvocab.create_latex_context(schema),
)
myst = pymyst.expand_parsed(
    parsed,
    muvocab.create_myst_context(schema),
)
html = pyhtml.expand_parsed(
    parsed,
    muvocab.create_html_context(schema),
)
ai_bundle = pyai.build_parsed(
    parsed,
    muvocab.create_ai_context(schema),
)
```

For an explicit structured-document path, evaluate without target renderers
and adapt the retained semantic values:

```python
typed = muweave.expand_parsed_typed(
    parsed,
    muvocab.create_document_context(schema),
)
document = muvocab.document_from_expansion(
    typed,
    text_command_schema=schema,
)
prepared = muvocab.prepare_document(document)
```

`prepared` contains immutable target-neutral section/block placements, labels,
and resolved local references over the unchanged MuDoc tree. It requires no
LaTeX, MyST, HTML, or AI context. This does not change the ordinary string APIs.
See the [MuDoc integration guide](docs/DOCUMENT_MODEL.md) for the placement and
body contracts. Source using the explicit `backend` gate requires one of the
concrete target contexts and is intentionally rejected by
`create_document_context`.

A bare `PytexContext()`, `PymystContext()`, `PyhtmlContext()`, or
`PyaiContext()` intentionally contains only core and frontend facilities. It
does not install MuVocab. The context and schema factories are:

```python
create_text_command_schema()
create_document_context(schema, ...)
create_ai_context(schema, ...)
create_html_context(schema, ...)
create_latex_context(schema, ...)
create_myst_context(schema, ...)
```

The contexts are independent: namespace state, references, deferred work,
configuration changes, numbering, assets, and traces do not leak between
targets.

The shared frontends accept `--items-dir` / `MUWEAVE_ITEMS_DIR`,
`--images-dir` / `MUWEAVE_IMAGES_DIR`, `--interactive-dir` /
`MUWEAVE_INTERACTIVE_DIR`, and `--persons-dir` / `MUWEAVE_PERSONS_DIR`.
Matching context-factory keywords are `items_directory=`, `images_directory=`,
`interactive_directory=`, and `persons_directory=`. The
interactive root supplies validated `.muweb` artifacts to the portable
`µblock.interactive(...)` author command. See the
[interactive-module guide](docs/INTERACTIVE.md) before assigning stable
learner-state instances, and the detailed authoring reference before creating
canonical content or assigning numeric item IDs.
Within one HTML context, `pyhtml --embed-ai` may project the already evaluated
HTML view through MuVocab's matching AI adapter; it does not create or share a
separate PyAI process context.

## Pure multiple-choice grading

Consumers such as Schoolman can use `muvocab.choice_grading` independently of
rendering: `ChoiceScoring(correct=Decimal(1), floor=Decimal(0))`,
`ChoiceAnswer(options, correct, marked)` and `grade_choices(answers, policy)`.
Supply **all questions of the original group**, original stable option keys
and a teacher-confirmed original policy/key. `marked=()` is a reviewed blank;
`None` is unresolved and rejected. Two/three-option questions are supported.
Wrong or multiple selections lose `correct/(option_count-1)`; blank earns zero.
`ChoiceGrade` returns exact Decimal contributions, raw total, once-clamped total
and maximum. The caller verifies original completeness, identities and evidence;
the function does not read sources, recognize handwriting or persist grades.
The existing printed/AI policy projection uses the same `ChoiceScoring` metadata;
`policy.incorrect(option_count)` supplies its negative two/three-option penalty.
`CHOICE_SCORING_VERSION` identifies the pure rule contract (currently integer 1).
Persist it with teacher-confirmed policies and reject unsupported versions rather
than reinterpreting an old marking plan through later arithmetic rules.

## Development

Maintainers should follow [`DEVELOPMENT.md`](DEVELOPMENT.md) for tests and the
generated API/documentation synchronization workflow. See [`TODO.md`](TODO.md)
for decided unfinished work and
[`REQUIREMENTS.md`](REQUIREMENTS.md) for selected durable project guardrails.
