# MuVocab documentation examples

These files are executable companions to the shared guides in
`muweave-suite/docs` and the MuVocab reference in `muvocab/docs`:

- `minimal.muweave` is the smallest portable two-target body;
- `course.muweave` uses references, mathematics, a structured problem/solution,
  and keyword/symbol directories;
- `reusable_problem.muweave` is the structured source loaded by the course;
- `asset_document.muweave` verifies local-file resolution and target-specific
  asset paths without invoking an external builder;
- `linear_algebra.muweave` demonstrates scalar terms, 3D coordinate values,
  symbolic components, connecting vectors, and matrix multiplication;
- `graphics3d.muweave` projects the same retained cube through explicit
  orthographic and perspective cameras in direct HTML or LaTeX;
- `circular_arcs.muweave` demonstrates scalar side names, explicit vector
  names, clockwise/counterclockwise arcs, full circles, and anisotropic
  projection in HTML, native LuaLaTeX, and semantic AI;
- `parse_once.py` expands one retained parse result in fresh LaTeX and MyST
  contexts.

The checked-in asset is SVG so it stays reviewable as text and works in the
MyST project route. The expansion smoke test deliberately does not claim that
direct LuaLaTeX can include this format: use an image format supported by both
chosen external builders, such as PNG, for a real shared-source build.
