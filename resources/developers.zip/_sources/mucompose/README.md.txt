# MuCompose

MuCompose is the thin multi-target command-line adapter for one portable
`.muweave` source. It invokes the installed `pytex5` and `pyhtml` commands as
independent child processes and can additionally invoke `pyai` for a semantic
model bundle. It does not import their builders, parse MuWeave expressions,
render output, publish artifacts, copy assets, or run compilers.

```bash
mucompose chapter.muweave
```

The default selects the primary LaTeX and direct-HTML backends:

| Child | Normal result |
|---|---|
| `pytex5` | complete `chapter.tex` and LuaLaTeX `chapter.pdf` |
| `pyhtml` | self-contained interactive `chapter.html` worksheet with matching semantic context |

Both primary targets use a 76% body-width ratio by default.
`--body-width-ratio` changes both consistently. `--body-height-ratio` controls
the A4 LaTeX body height and the corresponding logical top/bottom spacing in
continuous direct HTML.

Each child reads and parses the same physical source with a fresh context. A
failure makes the combined command unsuccessful, but the other selected child
is still run and already published peer artifacts are not rolled back.

Select only one backend when required:

```bash
mucompose chapter.muweave --backends=latex
mucompose chapter.muweave --backends=html
mucompose chapter.muweave --backends=ai
```

For PDF exam series, opt into an ordered batch:

```bash
mucompose exam.muweave --backends=latex --groups=A,B
mucompose exam.muweave --backends=latex --groups=A,B --config group=N2
```

The first command produces `exam_A.pdf` and `exam_B.pdf` with independent
`exam_A.tex` / `exam_B.tex` intermediates. The second produces only
`exam_N2.pdf`. An explicit process-level `--config group=NAME` overrides the
batch, even when that group is not among its defaults. A source can set
`µ! mucompose --backends=latex --groups=A,B` so ordinary `mucompose exam.muweave`
builds both series. Add `µ! pytex5 --groups=A,B` to make standalone
`pytex5 exam.muweave` build the same pair. Shared source `--config group=A`
does not narrow either batch; it still supplies a single-run vocabulary default
when batching is disabled. MuCompose passes `--no-groups` to its already
selected PyTeX5 children, so these two source directives do not cause duplicate
builds or names such as `exam_A_A.pdf`.

Names are case-sensitive, unique and limited to letters, digits, `_` and `-`,
starting with a letter or digit. Explicit LaTeX/PDF output paths serve as bases
in this mode and receive the same `_GROUP` suffix before their extension.
`--no-latex-pdf` emits only the separate sources. Group batches currently
require the LaTeX backend alone and reject lwarp HTML. Normal non-batch builds
retain their existing filenames and target selection.

For one print job with an independent exam per learner:

```bash
mucompose exam.muweave --backends=latex --exam-copies 24
mucompose exam.muweave --backends=latex --exam-copies 24 --exam-seed class-9
```

This forwards one batch invocation to PyTeX5, which compiles 24 total copies
sequentially in A/B order and publishes a fresh timestamped directory below
`exam_Druckbestände/`. It contains `exam_gesamt.pdf`, the durable
`exam_gesamt.exam-batch.json` and `exam_gesamt.quellen.tar.gz`. Earlier print
runs and loose outputs are never overwritten. Only the PDF is for learners;
the companions retain private original keys, sources and build evidence.
MuCompose owns no copy merger or temporary-artifact policy.
Recorded accepted per-copy seeds replay shuffled question/option order
for individual teacher copies.
See [combined exam copies](docs/CLI.md#combined-exam-copies).

For a learner-facing release, `--publish` suppresses private author bodies and
all working-only draft/item markers in every selected child. This is an
immutable shared safety mode rather than an ordinary `--config` assignment.

`ai` writes a layout-free `chapter.ai/` bundle containing concise Markdown,
canonical semantic JSON, a manifest, and referenced local assets. It is
optional rather than part of the default so ordinary PDF/HTML builds do not
create an additional directory.

The HTML child places semantic context for its exact view inside `chapter.html`
by default; it does not run the separate AI backend or create `chapter.ai/`.
Use `--no-html-embed-ai` to omit that payload deliberately. A later explicit
`--html-embed-ai` can override an inherited negative setting.

`--html-math-renderer=typst-mathml` opts the HTML child into PyHTML's limited
native-MathML pilot; `mathjax` remains the default. The flag has the same
spelling in both commands and does not affect PDF/AI or output filenames.
The [HTML mathematics guide](../pyhtml/docs/MATHEMATICS.md#experimental-native-mathml)
documents the optional compiler dependency and unsupported cases.

The complete option, configuration-layer, child-process, artifact, failure, and
exit-status contract is documented in the [MuCompose CLI guide](docs/CLI.md).
It also gives safe single-target, source-only, lwarp, and source-map examples.

The common authoring workflow and portable vocabulary begin in the
[MuWeave Suite agent guide](../muweave-suite/docs/AGENT_AUTHORING.md).

MuCompose requires a file input; stdin cannot supply the same independently
readable source to every selected child process. The package deliberately
exposes no document-composition Python API; its import surface is only
`__version__`.

> **Security warning:** Selected backends execute unrestricted Python code.
> Only process trusted sources.

MuCompose requires Python 3.13 or newer. Normative package conditions are in
[REQUIREMENTS.md](REQUIREMENTS.md).
