# mucli

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.

`resolve_layered_arguments(..., read_text=reader)` optionally uses a frontend's
`Callable[[Path], str]` for inherited argument files, for example to retain
their actual UTF-8 bytes during a print build. Omit it for ordinary file reads.
The callback performs no evaluation; source ordering, validation and origin
tracking remain owned by this resolver. mucli adds no dependency on the caller.

`mucli` is the small shared command-line contract for independent MuWeave
document backends and their orchestrators. It gives `pytex5`, `pymyst`,
`pyhtml`, `pyai`, and the `muweave` build command one spelling and one validation policy for
portable document metadata, expansion settings, and vocabulary selection.
It also carries the canonical reusable-item, shared-image, and interactive-
module roots without assigning any resource semantics itself.

```python
import argparse

from mucli import SharedDocumentOptions, add_shared_document_arguments

parser = argparse.ArgumentParser()
add_shared_document_arguments(parser)
namespace = parser.parse_args(
    ["--title", "Kinematik", "--author", "Ada", "--language", "de-AT"]
)
options = SharedDocumentOptions.from_namespace(namespace)

assert options.authors == ("Ada",)
assert options.to_cli_arguments() == (
    "--title",
    "Kinematik",
    "--author",
    "Ada",
    "--language",
    "de-AT",
    "--vocabulary",
    "muvocab",
    "--no-publish",
)
```

`--vocabulary` names an importable Python module and defaults to `muvocab`.
The module is loaded dynamically: backend packages do not depend back on a
vocabulary package that itself imports their context and renderer APIs. The
shared loader calls the selected backend context factory with the parse-time
schema plus keyword arguments `debug`, `configuration`, and the immutable
`publish` safety mode.
It also passes optional `items_directory`, `images_directory`,
`interactive_directory`, and `persons_directory` paths. The shared CLI
spellings are `--items-dir PATH`, `--images-dir PATH`, `--interactive-dir PATH`,
and `--persons-dir PATH`; their environment defaults are `MUWEAVE_ITEMS_DIR`,
`MUWEAVE_IMAGES_DIR`, `MUWEAVE_INTERACTIVE_DIR`, and `MUWEAVE_PERSONS_DIR`.
Explicit CLI values override those defaults, and these options may be inherited
from `.mu/arguments` or an unqualified initial `µ!` line.
`--publish` and `--no-publish` use the same layered contract, but remain
separate from mutable vocabulary configuration so trusted source cannot undo
publication mode after context creation.

`mucli` does not parse or expand MuWeave source, render a target format, run a
backend command, or define backend-specific options. Those responsibilities
remain with MuWeave, the selected backend, and the orchestrator respectively.

## Layered invocation arguments

`resolve_layered_arguments` discovers project arguments for one known main
source while retaining where every argument came from. It applies these layers
from lowest to highest precedence:

1. `.mu/arguments` and then `.mu/PROGRAM.arguments` in every ancestor,
   starting with the most distant ancestor;
2. consecutive initial `µ!` lines in the main physical source;
3. the explicit process argument vector.

For example, PyTeX5 may use:

```text
.mu/arguments
.mu/pytex5.arguments
```

and this initial source block:

```text
µ! --config fms
µ! pyai --config tutoring=guided
µ! pyhtml --config target=html
µ! pymyst --config target=myst
µ! pytex5 --config target=print
```

An unqualified directive is shared. A directive prefixed by `muweave`,
`pyai`, `pyhtml`, `pytex5`, or `pymyst` applies only to that command. Every
physical directive is still reported as consumed so another scope cannot leak
into document output.

The temporary `mucompose` alias shares the canonical `muweave` build scope.
Resolving either spelling reads `.mu/arguments`, `.mu/mucompose.arguments`,
then `.mu/muweave.arguments` in each ancestor, so the canonical file wins
within that directory while deeper directories keep their precedence.
Mixed `µ! muweave` and `µ! mucompose` directives apply in physical source
order. Their original scope spelling and exact source spans remain intact;
other frontends consume both kinds without applying their options.

```python
from pathlib import Path

from mucli import resolve_layered_arguments

source_path = Path("course/chapter.muweave")
source = source_path.read_text(encoding="utf-8")
resolved = resolve_layered_arguments(
    "pytex5",
    explicit_arguments=("--no-html",),
    source_text=source,
    source_name=str(source_path),
    source_path=source_path,
    inheritable_options={"--config", "--html", "--no-html"},
)

arguments = resolved.arguments
origins = resolved.origins
bootstrap_end = resolved.bootstrap_end_offset
```

Argument files and directive payloads use POSIX shell-style quoting and
comments, but no shell is invoked and no variable, command, or wildcard is
expanded. Only explicitly supplied option names are accepted as inherited
arguments; the explicit process argument vector is unrestricted and remains
the final parser's responsibility.

The resolver never slices or rewrites `source`. Each directive retains
half-open Unicode code-point offsets plus one-based lines and columns in the
original physical source. PyAI, PyTeX5, PyMyST, PyHTML, and MuCompose omit the
complete initial directive block through MuWeave's start offset, so body
diagnostics, source coordinates, and source maps keep their original physical
positions.

`--config` is repeatable. `--config fms` sets `fms` to `True`,
`--config ~fms` sets it to `False`, and `--config language=german:swiss`
preserves the value after `=` as exact text. Ordered assignments from all
layers remain available, while `SharedDocumentOptions.configuration()` returns
the final value per name for a fresh expansion context. MuCLI does not infer
relationships between settings or evaluate their values as Python.

`parse_group_names(value: str) -> tuple[str, ...]` is the shared opt-in CLI
validator used by PyTeX5 and MuCompose for series lists such as `"A,B,N2"`.
It preserves order and case and raises `argparse.ArgumentTypeError` for empty,
repeated or non-filename-safe names. Names consist of ASCII letters/digits,
`_` and `-`, beginning with a letter/digit; whitespace is not stripped.
This does not register `--groups` on unrelated backends or add it to the
globally shared inheritable options. Consumers own batch selection, output
paths and processes; MuCLI performs no group-dependent source evaluation.

Python 3.13 or newer is required. Normative package conditions are in
[REQUIREMENTS.md](REQUIREMENTS.md).
