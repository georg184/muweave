# pyhtml

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.

`pyhtml` is the direct HTML document frontend for MuWeave. It evaluates a
trusted source through MuWeave's typed path, asks the selected vocabulary to
prepare its semantic document, and serializes a self-contained interactive
worksheet without MyST, JATS, Node.js, a browser build, or a local server.

MuWeave documents and setup scripts execute unrestricted Python code. Process
only trusted input and trusted vocabulary modules.

## Current vertical slice

The first implementation supports:

- ordinary blank-line-separated paragraphs with mandatory HTML escaping;
- deterministic semantic block spacing with ordered `gap` transformations,
  negative overlap, and no browser margin collapsing;
- complete HTML shells and optional title, subtitle, authors, language, and
  date metadata;
- MuVocab sections, bold/emphasized/definition text, ordinary and named text
  blocks, native quotations with independently authored emphasis, solution
  companions, local references, `noin`, `qedsymbol`, and inline/block verbatim;
- inline mathematics, display equations, and aligned equation systems through
  Typst-generated native MathML by default, including portable fractions,
  square roots, scripts and vectors;
- an explicitly selected pinned MathJax 4 compatibility renderer;
- explicit measured-row matrix and optical-fraction layout, retaining a fixed
  math axis and unchanged native TeX commands (see `ARCHITECTURE.md`);
- MuVocab Cartesian coordinate systems as physically sized inline SVG, with
  text-font tick numerals and mathematical labels; shared reactive layouts with
  named arrows, labelled points with fixed physical offsets, automatic
  segment-label fitting and `ui.output` numeric fields;
- dependent slider bounds that preserve values until a boundary is reached,
  disable collapsed ranges, and normalize saved values in declaration order;
  `ui.label` switches between already typeset mathematical alternatives without
  changing control identities, in MathJax and native MathML;
- coordinate zoom buttons, wheel zoom and drag panning that preserve physical
  plot size, adapt coupled slider ranges and precision while preserving interior
  values and holding reached endpoints, and restore the full view with worksheet
  state; wheel zoom uses continuous steps;
- dynamic function fills with independently colored positive/negative areas,
  moving bounds, and declared discontinuities shared with function plots;
- draggable MuVocab points with mouse, pen, touch and keyboard input,
  synchronized sliders, range/step constraints, and labels that follow the
  point; larger hit regions leave the visible marker size unchanged;
- calibrated native MathML angle labels with exact compiler/browser identity,
  measured boxes and preserved author overrides; MathJax compatibility uses
  ink-centred anchors, including later notebook typesetting;
- measured segment/vector label clearance using the shared MuGeometry
  contract, with complete symbol boxes and exact-profile automatic calibration
  by default unless the author specifies a fixed offset;
- target-neutral equation numbers, tags, labels, row anchors, and mathematical
  fences, sets, and points;
- local images stored once in a versioned, content-addressed offline asset
  store, plus native `layout.columns` and flowing `layout.wrap` CSS;
- validated `.muweb` entries as isolated inline frames or
  full-tab activities, with stable instance-owned learner state and a
  link-only alternative;
- native single-image figures with captions, width/alignment, source-order
  numbering for labeled figures, and local number/name references;
- MuVocab's portable `tooltip` annotation on nested inline content,
  references, complete formulas, and structured equation cells or segments,
  with keyboard focus, `aria-describedby`, and Escape dismissal;
- final-artifact MuWeave source maps, including nested text-command bodies;
- a fixed-width document surface, an external sectioned sidebar containing the
  drawing palette, a continuous global drawing layer rendered through sparse
  vertical canvas tiles, ruler, vector ink, selection, partial erasing,
  undo/redo, printing, and learner-owned `.work` state with
  immediate browser mirroring and Chrome single-file synchronization,
  including settings and drawing undo/redo history across reopening;
- named fixed-height text responses and fixed-size graphic insertion slots,
  with embedded previews and optional editable originals in saved work states;
- item-owned single-choice and true/false answers, stored by stable option
  keys independently of shuffled presentation, with an explicit clear action;
- item-owned local handwriting canvases with automatic content-fitting
  viewports, explicit scrollable viewport overrides, padded immutable
  underlays, and independent learner state;
- a layout-free semantic AI bundle derived from the same typed expansion and
  embedded as inert JSON by default;
- native-editable MuVocab showcases whose source remains read-only in an
  ordinary browser and becomes a Shift+Enter notebook cell only in the
  optional MuWeave Reader;
- strict UTF-8 input, stdout, and atomic replaceable `.html` output.

Person mentions use embedded information cards with rich short biographies,
optional portraits and ordinary clickable resource links. They support hover,
click/touch, keyboard opening, Escape and viewport placement at the current
document zoom without changing content geometry. Full profiles use ordinary
blocks. The [MuVocab person reference](../muvocab/docs/AUTHORING.md#people-and-reusable-biographies)
owns their source format; the matching AI data is retained by the same expansion.

Index and symbol directories remain intentionally unsupported. Such values
produce a located render error instead of being silently stringified. See
[TODO.md](TODO.md).

Local asset bytes are read on first use and retained by the current context.
Repeated references to the same canonical file reuse that snapshot, and even
distinct files with identical bytes share one stored object. Visible images
and embedded AI metadata refer to that same object instead of duplicating its
Base64 payload. No asset directory is created: the replaceable `.html` file
remains directly openable through `file://`. See the
[shared asset-store contract](docs/ASSETS.md).

A `.muweb` archive is an embedding input; this generated `.html` file is the
offline learner deliverable. Legacy format-one and format-two modules carry
their own runtime code. Format three can declare host runtime profiles, but the
closed registry accepts only exact profiles implemented by this PyHTML
release. The supported math profiles are `muweave-mathjax-4-svg-v1` and
`muweave-mathjax-4-svg-ink-v1` (the latter also guarantees the calibrated-label
measurement API). PyHTML stores the verified MathJax payload
once in the outer file and inserts it into every requesting isolated module
realm before that module executes. Unknown profiles fail the build; no profile
is ignored or obtained from the network.

`figure(...)` wraps the same snapshot in native `<figure>` and `<figcaption>`
markup. A label enables the figure number and target. Captions remain
structured MuWeave source, so nested vocabulary such as `µemph{...}` is
rendered rather than printed literally. A `display="name"` reference requires
a single-paragraph caption because reference content is inline.

Documents containing mathematics, including mathematical labels in generated
coordinate systems, likewise need no server or network access.
By default they contain Typst-generated native MathML and the embedded math
font. The explicitly selected MathJax compatibility renderer adds its verified
4.1.3 TeX-to-SVG component and font data only to documents containing math
(approximately 4.7 MB). Text uses embedded Latin Modern Sans at 10 pt; mathematics uses Latin
Modern Math at the same base size, with text style inline and display style in
equation blocks.
Equation numbering and references remain owned by the target-neutral document
model rather than by MathJax. See the [mathematics guide](docs/MATHEMATICS.md)
for syntax, supported sizing, and the deliberate offline restrictions.
The opt-in [calibrated-label contract](docs/CALIBRATED_MATH_LABELS.md) defines
the shared browser API and the separate historical measurement profiles. It
does not change ordinary mathematics or axis-name typography.

The default renderer is `typst-mathml`, available explicitly as
`pyhtml lesson.muweave --math-renderer=typst-mathml` or
`muweave lesson.muweave --html-math-renderer=typst-mathml`.
The direct frontend accepts only `--math-renderer`; the orchestrator qualifies
its option for HTML. Typst is a required build-time package dependency and
the output embeds native MathML plus Latin Modern Math. Ordinary static
formulas require no browser compiler. The normally enabled learning coach additionally
embeds Typst WASM for formulas received at runtime. Explicit
`--math-renderer=mathjax` selects the compatibility renderer. The graphics
backend still generates SVG separately:
portable graphic labels, equation previews, measured layout and Reader cells
use the same renderer. Raw TeX, incompatible external modules and other
uncovered cases fail explicitly. Native fractions and matrices apply the shared
optical settings after measuring loaded MathML/font boxes, including updated
Reader results. The formulas remain real MathML, not SVG or canvas images.
Parenthesis sizes and inner clearances are configurable; native matrices no
longer inherit the outer `0.4em` cell padding on each side. Fixed/minimum
fences work without scaling their contents.
See the [native renderer scope](docs/MATHEMATICS.md#native-mathml-through-typst).

## Learning coach

Ordinary `pyhtml` and `muweave` HTML builds include paragraph/item questions
by default, using an automatic document key. Each task has one margin button;
distinct paragraphs within it remain selectable inside the panel. Mouse hover
or keyboard focus reveals controls; touch devices keep them visible.
Included text chapters keep separate paragraph/task entries and inherited guidance.
This works with either worksheet
math renderer. MuVocab's `coach` annotation supplies
general and local didactic guidance; each request combines it with the exact
worksheet context for every question. Coach formulas are compiled offline to
native MathML with the worksheet's math font.
Concrete Typst examples guide the model. If its formula still fails local
compilation, the runtime allows one syntax-correction request, preserving the
explanation and all unaffected blocks; unresolved formulas retain readable source.

`--no-coach` disables it, for example when building an exam; `--coach` restores
the automatic default. `--coach-document-id KEY` selects an identity that stays
portable across renamed/moved sources and builds on different computers. These
settings can also be inherited through a leading `µ! pyhtml` directive.
Omitting semantic context with `--no-embed-ai` also omits automatic coaching.

When `~/.open_router_public_key` exists, normal CLI builds embed this dedicated
public OpenRouter key. Open the resulting HTML directly; the pinned Meta
Contributor model answers over the internet without a local service. Public
access is retained in downloaded HTML copies; chats remain in page memory.
Use `--coach-public-key-file PATH` to select another public file or
`--no-coach-public-key` to omit it. These are process-only options. The compiler
never embeds the personal `OPENROUTER_API_KEY` environment variable.

For private credentials, build with `--no-coach-public-key` and run
`python -m pyhtml.coach_server lesson.html`, using the server process's
`OPENROUTER_API_KEY`. See the
[learning-coach guide](docs/LEARNING_COACH.md) for a runnable example, session
behavior, Contributor data use and limits for both connection modes.

## Offline worksheet

The generated HTML opens directly through `file://`. Its author document uses
the direct PyHTML typography and spacing inside a stable A4-width surface. The
logical width is exactly 210 mm under CSS's fixed absolute-unit relation,
serialized as `793.700787401574803px`; screen calibration is an independent
view scale and never changes that document geometry.
The browser tab uses an explicit metadata title when supplied, otherwise the
first logical section including its visible number, and finally a readable
source filename with underscores converted to spaces.
By default the authorial body occupies 76% of that width, leaving equal 12%
side margins. Its 90% height ratio supplies equal initial and final whitespace
calculated from a logical A4 height, but the screen document remains continuous
and has neither a fixed A4 height nor page breaks. The sidebar remains outside
the surface and separates view, drawing, editing, work-state, and output
controls. Its drawing palette controls one transparent annotation canvas over
the complete document or an item-owned local canvas. A pinned **Zeichnen**
section selects the layer and explicitly activates or deactivates drawing.
When drawing is off, the palette is disabled under a grey veil and pointer
interaction passes through the canvases. Local activation buttons can switch
directly to their surface. The enabled state, selected layer, and tool are all
restored with the learner work.

The portable learner state for `lesson.html` is `lesson.work`. PyHTML also
mirrors it in the browser's IndexedDB under the exact local HTML path; that
mirror loads automatically without file permission. Each completed change is
committed there immediately; the physical sidecar follows after ten seconds
without another change. A red/orange/green status distinguishes unsaved,
browser-only, and fully portable revisions. Learners initially receive only
the HTML file. On first use in Chrome, **Arbeitsstand einrichten** asks once for
the directory containing that HTML file, verifies its filename, and opens or
creates the exact derived `lesson.work` there. An invalid existing sidecar is
reported rather than overwritten. The runtime then discards the directory
handle, remembers only the exact `.work` file handle, and normally reconnects
it automatically on later visits. The button is red before this setup and
green afterwards. Other browsers still retain the immediate IndexedDB mirror
but may not support the physical sidecar connection.
When the unchanged artifact is opened with `muweave-reader`, the native host
already knows its canonical path. It therefore loads, creates, and atomically
saves the exact sibling `lesson.work` automatically; the connection is green
without **Arbeitsstand einrichten** or a picker. The ordinary-browser workflow
is unchanged.
**Vollständige HTML-Kopie** remains available as an independent snapshot. See
the [worksheet guide](docs/WORKSHEET.md) for the exact workflow, tools, named
response fields, state boundary, and fixed geometry.

An author can mark a source/result showcase as an editable notebook cell. The
standalone artifact still opens normally and never executes Python in an
ordinary browser. When the same file is opened with `muweave-reader`, a
versioned Qt WebChannel bridge progressively enables the editor and run
button. Its transparent input remains synchronized with a live coloured source
layer supplied by MuWeave's structural analyzer through the reader; PyHTML does
not embed a second syntax parser. Input and coloured layer use exactly the same
font, line, wrapping, padding, and trailing-line geometry, so the native caret
stays on the visible source without an inner editor scrollbar. Edited source
belongs to `.work`, together with its author-source baseline. When a rebuild
changes that baseline, the current author source replaces the stale cell;
previous edits remain available through the cell's recovery disclosure.
Unchanged cells retain their edits. A result is shown only for its matching
source; a restored edit must be run manually. Generated result markup is
session-only. PyHTML supplies
only the inert browser UI and a public shell-free fragment serializer—the
reader owns native execution, non-evaluating live highlighting, and its trust
boundary.

## Command line

Documents with MuVocab headings include an **Inhaltsverzeichnis** button next
to document zoom. Its initially closed, scrollable panel overlays the document
without moving text or ink. It supports keyboard navigation, Escape, and a
current-section indication, also while drawing and in MuWeave Reader.
Use `--config ~toc` to omit it or `--config toc.max_level=1` to limit depth
(default: logical levels 0–2). Empty contents produce no control. These are
initial publication settings; see the [worksheet guide](docs/WORKSHEET.md#contents-navigation).

Create or replace the directly openable `lesson.html` worksheet:

```console
pyhtml lesson.muweave
```

Add document metadata and a source-map sidecar:

```console
pyhtml lesson.muweave \
  --title "Kinematik" \
  --author "Georg G" \
  --language de-AT \
  --body-width-ratio 0.76 \
  --body-height-ratio 0.9 \
  --source-map
```

The normal build embeds layout-free semantic context for a later
tutor/application layer:

```console
pyhtml lesson.muweave
```

The invisible, self-contained PyAI JSON envelope stays in the same file. It
does not contact a model and remains separate from answers and pen strokes.
Use `--no-embed-ai` only when that semantic context is deliberately unwanted.

`--output PATH` selects an exact destination. `--output -` writes the complete
HTML to stdout. Existing output files are replaced atomically; the source is
never overwritten. Any readable UTF-8 suffix is accepted, while `.muweave` is
the portable convention.

Like the other document frontends, `pyhtml` reads ancestor `.mu/arguments` and
`.mu/pyhtml.arguments` files from shallow to deep, then consecutive initial
`µ!` directives, then explicit process arguments. Run `pyhtml --help` for the
complete current CLI contract.

The shared canonical resource options are `--items-dir`, `--images-dir`,
`--interactive-dir`, and `--persons-dir`; their environment defaults are
`MUWEAVE_ITEMS_DIR`, `MUWEAVE_IMAGES_DIR`, `MUWEAVE_INTERACTIVE_DIR`, and
`MUWEAVE_PERSONS_DIR`. The interactive root is
the exclusive source for MuVocab `µblock.interactive(...)` artifacts. See the
[interactive-module author guide](../muvocab/docs/INTERACTIVE.md) and the
[worksheet state guide](docs/WORKSHEET.md).

`--embed-ai` and `--no-embed-ai` may be inherited from
`.mu/pyhtml.arguments` or a scoped `µ! pyhtml` directive.

`--body-width-ratio RATIO` sets the authorial body width divided by the fixed
document-surface width. It accepts values greater than zero and at most one;
the default is `0.76`. `--body-height-ratio` uses the same interval and controls
the initial and final whitespace calculated from a logical A4 height. It does
not paginate or constrain the continuous screen document.

## Python API

The default MuVocab provider creates the schema and matching HTML context:

```python
import muvocab
import pyhtml

schema = muvocab.create_text_command_schema()
context = muvocab.create_html_context(schema)

html = pyhtml.expand_string(
    'µsection(title="Kinematik")\n\nDas ist µbold{wichtig}.',
    context,
    source_name="lesson.muweave",
    output_name="lesson.html",
    body_width_ratio=0.76,
    body_height_ratio=0.9,
)
```

The returned string is the same complete interactive artifact written by the
CLI, including its sidebar, drawing palette, canvas, and embedded save state.
The default `embed_ai=True` makes the same exactly-once typed expansion supply
the inert semantic bundle; source commands are not evaluated a second time.
Pass `embed_ai=False` to omit it deliberately.

Complete-document calls also include the learning coach by default. Pass
`coach=False` (or `None`) to omit it; `embed_ai=False` omits automatic coaching
along with the required context. Explicit `LearningCoach` settings allow an
author-chosen key and instructions, as described in the [coach guide](docs/LEARNING_COACH.md).
Unlike the CLI, Python calls do not discover credential files; pass
`coach_public_api_key=public_key` explicitly for direct browser access.
The coach panel's **Settings** control reasoning effort and whether the provider
returns optional thinking text. Choices persist per worksheet in the browser;
the default remains low effort with thinking text excluded. The shared prompt
includes an explicit inline-math example so formulas within prose can render
through the same native Typst/MathML path as displayed formulas.

For parse-once use, call `muweave.parse_string(...)` with the same schema and
pass its `ParsedSource` to `pyhtml.expand_parsed(...)`. A bare
`PyhtmlContext()` is deliberately text-only; it does not install MuVocab.

Trusted native hosts can use `expand_body_string(...)` or
`expand_parsed_body(...)` to receive an `HtmlBodyFragment`: adapter-generated
body markup, its immutable asset store, and explicit runtime requirements,
without a second worksheet shell, AI bundle, or executable script payload.
Both default to `html_math_renderer="typst-mathml"`; explicit `"mathjax"`
selects the compatibility renderer. A native
fragment includes `math_styles` and its `html_math_renderer`; the receiving
host must already supply the embedded native font and optical measurement
runtime and insert the CSS as text.
Such a result never sets `requires_math_runtime` merely for native formulas.

Vocabulary providers implement the small `HtmlVocabularyAdapter` protocol:
prepare the document, classify each block's layout, and render semantic nodes.
They may certify a sole inline box through MuDoc's `LayoutBox.inline_box`.
PyHTML composes that paragraph without a text-line strut and forwards the
occurrence-local `HtmlRenderServices.isolated_inline` hint to its provider.
Ordinary mixed paragraphs and their baselines remain unchanged.
`HtmlRenderServices.whole_paragraph` (strict bool, default `False`) separately
identifies a sole non-whitespace semantic occurrence in an ordinary paragraph,
not in an inline body or a certified inline box. A font wrapper can then own
the line boxes instead of inheriting the larger parent strut. Its markup must
remain valid inside the enclosing `p`, preserve content, and stay breakable.
MuVocab uses a block-displayed `span` for this case; no source is re-evaluated.
The box runtime also supports provider-certified directed column height
dependencies. It measures trimmed reference content before fitting a free
drawing, reusing the normal tight-bounds service. Only the drawing's geometric
SVG group and label anchors move; math labels, strokes and physical marker
sizes stay unchanged. Dependency errors are visible. Resize/font/content
changes invalidate measurements; derived factors are not worksheet state.
Their prepared document may expose a plain logical `document_title`; PyHTML
uses it only as a browser-tab fallback and does not duplicate a visible title.
Its optional `navigation` tuple contains generic `HtmlNavigationEntry` values
from `pyhtml.protocol`, not vocabulary classes. Each entry carries a plain
title, effective level, assigned number, exact heading anchor, and optional
earlier parent anchor. Providers emit the matching heading IDs. An empty tuple
means no contents control; filtering and configuration belong to the provider.
When rendering shell-free fragments, providers prepend the unique
`HtmlRenderServices.heading_id_prefix` to heading IDs and references to them.
Complete publications receive an empty prefix. These result-local IDs are not
persistent author labels, and body fragments carry no document-wide navigation
shell.
`HtmlFragment.text(...)` escapes author text, while
`HtmlFragment.markup(...)` is reserved for trusted provider/frontend markup.
The read-only `HtmlFragment.html` property exposes the exact flattened trusted
fragment when a provider must display or transport that serialization. Reading
it neither renders nor evaluates the fragment again; callers that present it as
text must still pass it through `HtmlFragment.text(...)`.
See [ARCHITECTURE.md](ARCHITECTURE.md) for that package boundary.

## Development

Run its tests from the workspace root with:

```console
./pythonvenv1_dbg/bin/python -m unittest discover \
  -s pyhtml/tests -p 'test_*.py'
```

The optional navigation integration tests use real Chrome and the unchanged
MuWeave Reader, with temporary documents, profiles, settings, and `.work` files:

```console
PYHTML_CHROME_INTEGRATION=1 PYHTML_READER_INTEGRATION=1 \
  ./pythonvenv1_dbg/bin/python -m unittest discover \
  -s pyhtml/tests -p 'test_pyhtml_navigation_browser.py'
```

Chrome's test driver additionally uses the development dependency
`websocket-client` for its short-lived loopback debugging channel. Neither the
published document nor Reader's normal navigation needs that channel or a
server. Tests check actual hit regions over ink, internal scrolling, focus,
current-section tracking, and invariant document/canvas rectangles across zoom.

Native optical mathematics has cross-engine geometry regressions:

```console
PYHTML_CHROME_INTEGRATION=1 PYHTML_FIREFOX_INTEGRATION=1 \
  ./pythonvenv1_dbg/bin/python -m unittest discover \
  -s pyhtml/tests -p 'test_pyhtml_native_math_browser.py'
```

They require the packaged Typst compiler, installed Chrome/Firefox, and
`websocket-client` and Pillow for paint-level assertions. Firefox uses its built-in WebDriver BiDi with a temporary
profile and blocked external proxy, not geckodriver or a user session. Tests
cover reduction-only spacing, a common fraction axis, tall matrix rows,
script styles, font changes, repeated measurement, saved-copy cleanup and
late/initially hidden content. Screenshot assertions also keep the actual
vector glyphs inside their parentheses: correct DOM extents alone did not
catch a Gecko zero-line-height painting regression. Reader's full isolated GUI runner includes
real manual notebook replacement with modified fraction/matrix settings.
