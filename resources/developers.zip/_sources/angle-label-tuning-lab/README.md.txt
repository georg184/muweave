# MuWeave Tuning Lab

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.

`muweave-tuning-lab` is the maintainer application for adjusting mathematical
label spacing. It combines the existing angle lab with **Seiten und Vektoren**,
using the same geometry and symbol renderers as MuWeave documents.

```bash
muweave-tuning-lab
muweave-tuning-lab --family segment
```

The existing `angle-label-tuning-lab` command remains an alias. The distribution
and Python import still use their existing names during migration. Installing
`muweave-suite[tuning]` includes this optional application.
Existing editable installations immediately see source changes;
new console launchers appear when the environment is refreshed through its
normal package manager or installman workflow.

A fresh native installation opens the segment mode with **MathML über Typst**.
Existing profile settings, window geometry and unfinished angle work remain
available. The last mode and each segment renderer's unfinished case, manual
clearance, matrix and queue survive restarting the application.

## Segment and vector spacing

Choose inclination, geometric side, alphabet, letter, optional index,
scalar/vector notation, font size and shaft width. Labels remain horizontal at
the midpoint of a sufficiently long isolated segment. Inclination is in
`-90° < alpha <= 90°`; at exactly 90 degrees, **oben** means left and **unten**
means right. The [shared MuGeometry contract](../mugeometry/README.md#segment-and-vector-label-geometry)
also translates directed author-facing left/right before normalization.

The one tuning value, **Freier Abstand**, is in em and runs from the visible
stroke edge to the renderer's measured label boundary. It includes accents and
indices. Scalar and vector notation use the same placement operation.

The native segment mode offers:

- **MathML über Typst**, the default: ordinary MuVocab/PyHTML output, laid out
  and measured as native browser MathML with the packaged math font.
- **MathJax 4**, transitional: ordinary document SVG ink measurement.
- **LaTeX / PyTeX5**, exact: ordinary document TeX-box measurement and a real
  PDF preview. `PDF öffnen` opens the actual judged artifact.

`Vorschau erstellen` renders edited parameters. HTML clearance adjustments
reuse the measured formula without recompiling it; PDF changes require an
updated exact render. Saving a measurement stays disabled until the current
label is successfully measured or its current PDF has loaded. The matrix uses
the same actual renderers and can queue cases for subsequent tuning.

`Messpunkt merken und weiter` retains a measured observation locally and opens
the next queued or randomly generated case. `Messpunkte speichern und
verarbeiten` submits the selected environment's complete batch. Every sample
retains full letter/alphabet/index/vector identity, physical font size, measured
box, actual stroke width, free clearance and rendering evidence. Exact PDF
samples additionally retain the judged artifact hash.

MuGeometry owns the independent segment cloud, profile registry, model and
JavaScript evaluator. First observations register their exact environment;
there are no manufactured initial observations or borrowed angle measurements.
An unmatched case explicitly starts at an uncalibrated `0.2 em`. Saving validates
the complete batch, merges only new timestamps, updates all profiles in the
segment generation and activates the verified evaluator in the open lab.
Conflicting rows reject the whole batch. Failed saves leave observations
pending, and exact retries do not add them again.

Profiles separate compiler, renderer, font, measured-boundary convention and
browser-reported engine version. The browser's full version is used when its
API exposes it; a reduced user-agent version is retained as reported, without
inventing an executable patch version. Old environment batches remain separately
selectable for saving or JSON download after an engine or renderer change.

Ordinary `g.line`, `g.arrow`, `g.vector` and triangle side labels use the
calibrated measured boundary automatically. Matching observations therefore
change their placement on the next document build without an additional author
parameter. A numerical `label_clearance_em` fixes the free gap in em; an explicit
numerical `label_offset` fixes the historical centreline distance. These
explicit overrides remain effective. Triangle vertex-label offsets are
independent of side-label calibration. See the
[MuVocab author API](../muvocab/docs/AUTHORING.md).

The new segment symbol-compilation path requires the native application. The
historical MathJax angle lab remains usable directly in a browser, without
PySide6 or a background server. No in-browser Typst compiler is bundled.

## Angle tuning with MathML via Typst

Select **Winkel** and **MathML über Typst**. A fresh native angle session uses
this renderer by default; remembered renderer choices and their unfinished work
remain available. The label, arc and rays come from the ordinary MuVocab/PyHTML
document. Radius, label percentage and angular offset update the shared document
projection immediately without recompiling the symbol. Saving requires current
measured output; the matrix uses the same document renderer.

Each exact compiler/browser/font environment receives its own observation
profile. The older generic native profile supplies an explicitly provisional
fallback and cannot accept new observations. The first successfully processed
batch registers the exact environment and its evidence atomically. Later
ordinary HTML builds include the updated evaluator; when opened under matching
conditions, their angle labels use that environment's calibration automatically.
A fixed author radius, percentage or angular offset remains an override.

Browser upgrades retain older pending batches and manual work in separately
selectable saved environments. Those environments permit processing or exporting
existing observations; new judgment requires the currently available renderer.

## Existing MathJax and LaTeX angle workflow

The native window uses an asynchronous QWebChannel bridge. It runs the closed
preview request through the installed MuGeometry, MuVocab, PyTeX5, and
LuaLaTeX/TikZ pipeline without starting a server or opening a listening port.
Exact PDF and PNG artifacts are cached below the platform temporary directory.
Parameter changes update the immediate MathJax view and mark the exact view as
stale and cancel obsolete foreground work; `Neu rendern` renders the changed
parameters. On startup, the current case renders automatically after state
restoration and renderer validation, before background matrix work. Its
restored manual adjustments remain unchanged. After `Speichern und weiter` or `Überspringen`, the next preview
starts automatically. Completed matrix cases reuse their existing image, PDF
and render provenance without a new renderer call. Skipping a pending case
cancels only its request, and late results cannot activate the wrong preview.
The visual matrix is filled asynchronously with exact PyTeX5
previews and reports its progress without blocking the interface. The window
remembers its geometry between starts and cancels outstanding render work when
it closes.

All probability settings, edited placement, pending observations and the
matrix queue survive restart in profile-specific persistent browser storage.
The last renderer is restored unless `--profile` selects another one. Reopening
with unchanged calibration preserves
manual adjustments exactly, including fractional stroke widths.

After collecting observations, use `Messpunkte speichern und verarbeiten`. The native bridge
passes the complete profile-specific batch to MuGeometry. MuGeometry merges
only new observations into its package-owned canonical cloud, advances its
data version, rebuilds the portable model and JavaScript evaluator, validates
the installed generation, and returns that evaluator to the running lab. In
the source workspace, the bridge publishes every registered profile, static
consumer pin, vendor copy, cache version, package snapshot, and conformance
artifact in the same atomic release. The current case and the complete visual
matrix are then recalculated with the new placement function before tuning
continues. Exact resubmission is idempotent, and no intermediate file is
written to `~/Documents` or needs to be copied into a chat.

After the success message, another `muweave script.muweave` run in the same
installed environment reads that new model. The open lab also uses it for new
random cases without restarting. LuaLaTeX observations correct PDF placement;
MathJax-4 observations correct their own separate HTML measurement profile,
selected explicitly with `--html-math-renderer=mathjax`. Default HTML uses
Typst/MathML with matching exact-environment evidence and an explicitly
provisional fallback when that environment has no observations. Explicit placement
overrides in the authored document remain unchanged.

The MathJax lab remains an ordinary static application and does not import or
execute PySide6. Open the packaged entry in the system browser with:

```bash
muweave-tuning-lab --browser
```

In this mode, `JSON herunterladen` writes the same browser-produced batch
through the browser's normal download mechanism. This is the deliberate
fallback because a plain browser page cannot modify installed package data.

To open it manually or with a different browser, obtain the exact installed
path first:

```bash
muweave-tuning-lab --html-path
```

Both routes accept `--profile PROFILE_ID`. The native route additionally
accepts `--tex-bin DIR` and `--cache-dir DIR`. A direct MathJax page requires
neither the native GUI nor the exact LuaLaTeX toolchain. MathJax 4 is packaged
for offline use; the historical MathJax 3 comparison profile retains its
pinned network runtime.

For current HTML angle labels choose **MathJax 4 / SVG – aktuell (MuWeave)**
(`muweave-mathjax-4-svg-ink-v1`). It uses the same stroke-aware geometry and
ink-centred, font-independent glyph measurement as the document, in both the
editor and matrix. Saving waits for the current glyph measurement. This new
profile provisionally inherits the original MathJax-3 calibration, not the old
MathJax-4 residuals. New measurements improve only this new target.

The previous **MathJax 4 / SVG – bisherige Messbasis** stays available with its
authentic observations, edited case and matrix queue. No pending work is moved
between profiles. A fresh browser-only session defaults to the current HTML
profile; a remembered selection takes precedence. An existing lab may still open the old
profile until you select the current one explicitly.

The package contains a deterministic web-resource snapshot so a normal wheel
or editable installation does not depend on the adjacent `ggprojects`
workspace. The canonical browser application is maintained at
`software/HTML/ggprojects/angle_label_tuning_lab`; maintainers synchronize it
through the workflow in [DEVELOPMENT.md](DEVELOPMENT.md).

The package top-level Python API deliberately exposes only `__version__`.
