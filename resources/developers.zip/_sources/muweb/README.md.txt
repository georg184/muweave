# MuWeb

MuWeb builds and validates interactive web-module inputs for later composition
into MuWeave documents. It is deliberately independent of MuWeave parsing,
MuVocab, PyHTML, PyTeX5, PyAI, and MuCompose.

A source project supplies a complete project-owned `embed.html` and a strict
`muweave-module.json`. MuWeb turns that directory into a deterministic
`<module-id>.muweb` archive, validates it without extracting files, and can
atomically install it in the canonical interactive-module library.

```console
muweb build build/motion-module motion.muweb
muweb validate motion.muweb
muweb install motion.muweb --interactive-dir /path/to/muweave_library/interactive
```

`MUWEAVE_INTERACTIVE_DIR` may replace the explicit installation directory.
The installer accepts only a completely validated canonical-named artifact;
it never links a source checkout or partial build into the library.

The supported format is intentionally strict. It requires a complete HTML
entry, a network-denying Content Security Policy, inline module-owned scripts
and styles, and no exceptional browser permissions. A `.muweb` file is an
embedding artifact, not the learner-facing offline deliverable. Format version
3 may omit a shared library only by declaring a closed host-runtime profile;
the consuming frontend must resolve it from pinned local bytes or fail. The
finished PyHTML document owns deduplication and the offline guarantee. Versions
1 and 2 remain readable and declare no host runtime. The printable fallback is
the selected activity's canonical HTTPS URL. See the
[module format](docs/MODULE_FORMAT.md) for the exact source and archive
contract.

Source projects can inline the packaged host bridge into their embedded entry:

```python
from muweb import module_bridge_source

javascript = module_bridge_source()
```

Or publish the exact release-matched file during a project build:

```console
muweb bridge build/muweave-module-bridge.js
```

The bridge sends learner state to the containing host, exposes the selected
activity and compact/full presentation together with the host's typography to
the isolated module, and deliberately owns no browser persistence. Its
protocol is documented in [the bridge guide](docs/BRIDGE.md).

Python callers normally use `build_artifact`, `read_artifact`,
`write_artifact`, and `install_artifact`. A document integration reads a
published module with `read_installed_artifact(id, interactive_directory)`;
that exact lookup never searches a source checkout or fallback directory.
`ModuleManifest`, `ModuleActivity`, `ModuleArtifact`, the public format
constants, and the error hierarchy are immutable validation contracts.
`parse_artifact` accepts already
captured bytes and is the future frontend boundary: consumers retain those
exact bytes rather than reopening a mutable project directory.

MuWeb deliberately does not own the author command, iframe presentation, or
`.work` persistence. The implemented integrations belong to MuVocab and
PyHTML: see the
[MuVocab interactive-module guide](../muvocab/docs/INTERACTIVE.md). This keeps
artifact production usable without importing any document frontend.
