# MuWeave LSP

`muweave-lsp` provides non-evaluating live syntax diagnostics for `.muweave`
documents through the Language Server Protocol (LSP). It is the editor-facing
consumer of MuWeave's shared source analysis; it does not implement another
MuWeave parser.

The server currently provides the M2 through M4 foundation:

- stdio JSON-RPC/LSP initialization and shutdown;
- full-text open/change/close synchronization;
- recoverable parser diagnostics using MuVocab's default text-command schema;
- full semantic highlighting projected from retained MuWeave and Python token
  spans;
- whole-document and exact-selection prose reflow through LSP formatting,
  with executable syntax and protected bodies kept unchanged;
- exact Unicode-code-point to negotiated UTF-16 position conversion;
- background analysis with stale-version suppression.

Completion belongs to a later milestone. The separate MuWeave development
extension connects Zed to the implemented diagnostics, highlighting, and
formatting operations. Zed's standard `ctrl-shift-i` action formats the whole
document; the configured `ctrl-k ctrl-q` action formats nonempty selections.

## Running the server

Editors normally start the server and communicate over standard input/output:

```console
muweave-lsp --stdio
```

The formatter uses 100 code-point columns by default. An editor integration
can choose a width from 40 through 240 when it starts the server:

```console
muweave-lsp --stdio --line-length 88
```

For manual inspection:

```console
muweave-lsp --help
muweave-lsp --version
```

Standard output is reserved exclusively for framed protocol messages. Runtime
failures are sent as LSP log notifications or written to standard error before
a protocol connection exists.

## Safety and scope

Opening or editing a source calls `muweave.analyze_string()` with the installed
MuVocab schema. This scans and parses Python syntax but never evaluates a
document expression, imports a document setup script, starts MuCompose, or
runs a target builder. Importing the installed MuVocab package itself remains
ordinary trusted Python module loading.

Balanced qualified brace and modifier spellings are highlighted structurally
without checking whether their command names exist. The compiler consumes the
same analysis; only an actual expansion resolves command availability.

MuWeave documents execute unrestricted Python only when explicitly expanded or
built by the document tools. Process and build only trusted documents.

## Integration contract

The exact protocol, synchronization, diagnostic, and position rules are in
[the protocol guide](docs/PROTOCOL.md). Implemented internal ownership and the
reason for the direct standard-library protocol layer are in
[ARCHITECTURE.md](ARCHITECTURE.md).

The import package deliberately exports only `muweave_lsp.__version__`.
Protocol internals are not a supported application API.

## Development

Run the package tests from the workspace root:

```console
PYTHONPATH=muweave-lsp/src \
  ./pythonvenv1_dbg/bin/python -m unittest discover \
  -s muweave-lsp/tests -p 'test_*.py'
```

Then run Ruff:

```console
./pythonvenv1_dbg/bin/python -m ruff check \
  muweave-lsp/src muweave-lsp/tests
```
