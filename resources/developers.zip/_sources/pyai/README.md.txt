# PyAI

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.
Audience: users, AI agents, and developers

PyAI is the semantic, model-oriented frontend for trusted MuWeave documents.
It evaluates a source with the selected vocabulary and publishes a directory
containing:

- `document.md`: a compact reading view;
- `document.json`: the canonical versioned semantic tree;
- `provenance.json`: deduplicated source locations for tools, not model input;
- `manifest.json`: entrypoints, hashes, and local-asset metadata;
- `assets/`: only local files actually referenced by the document.

Different source files keep unambiguous bundle-relative asset references even
when their filenames collide. Embedding in HTML still shares byte-identical
payloads through its content-addressed store.

The export deliberately omits page breaks, spacing, layout dimensions, and
pure decoration. It retains headings, formulas, units, educational
block kinds, tasks and solutions, references, labels, tooltips, response
fields, and graphics semantics. Exact source coordinates remain separately
available to tools; local filenames and offsets no longer repeat throughout
the model-facing JSON. Existing labels, item IDs, and input keys stay in the
content. See [citation and provenance](docs/BUNDLE.md#citation-and-tool-provenance).
Explicit foreground scopes, graphic paint colors, and educational-panel
backgrounds remain attached to their content, so a model can identify "the red
curve" or "the green box" even without an author-written color legend. Panel
colors use each occurrence's configured theme rather than a fixed AI palette.
See [content colors](docs/BUNDLE.md#content-colors).
Paired regression tests protect the [appearance/content boundary](docs/BUNDLE.md#boundary-between-appearance-and-content):
font sizes, spacing and layout controls leave both semantic artifacts unchanged,
while mathematical notation, labels, explanations and identifying colors do not.
Literal code discussing layout remains content; no global TeX cleanup is applied.
Direct Python layouts and lists also retain nested semantic objects and
MuWeave content strings. Numbering, references, annotations, and source-ordered
state use the same typed bodies as registered brace syntax, shared with the
visible HTML and complete-document PDF paths; no late expansion is involved.
Interactive activities retain their stable instance, module and state
versions, canonical URL, localized titles, kind, and learning objectives; they
never copy JavaScript, CSS, archive bytes, or viewport geometry into the model
context.

```console
pyai chapter.muweave
pyai chapter.muweave --output chapter-for-ai
mucompose chapter.muweave --backends=ai
```

The default bundle is `chapter.ai/`. MuWeave sources execute unrestricted
Python and must therefore be trusted.

Shared metadata and expansion settings use the same `mucli` options as the
presentation frontends: `--title`, `--subtitle`, repeated `--author`,
`--language`, `--date`, `--vocabulary`, repeated `--config`, `--items-dir`,
`--images-dir`, `--interactive-dir`, and `--persons-dir`, plus
`--publish`/`--no-publish`. Resource paths default from `MUWEAVE_ITEMS_DIR`,
`MUWEAVE_IMAGES_DIR`, `MUWEAVE_INTERACTIVE_DIR`, and `MUWEAVE_PERSONS_DIR`. Project
defaults come from ancestor `.mu/arguments` and `.mu/pyai.arguments` files,
then initial `µ!` lines; explicit arguments win. `--setup` executes an
explicitly trusted Python setup file in the fresh AI context.
Private author bodies are omitted from AI in either mode, while structured
item identities remain semantic data rather than visual working badges.

For Python callers, parse once with MuWeave and pass the result to
`build_parsed(...)` with `muvocab.create_ai_context(schema)`. A bare
`PyaiContext` intentionally supports prose only because a frontend cannot
guess the meaning of an arbitrary vocabulary value.

See [Architecture](ARCHITECTURE.md) for the package boundary and
[AI bundle format](docs/BUNDLE.md) for the generated contract and current
reading-view limitations. The [static-context milestone](TODO.md) prioritizes
complete authored content and addressable input declarations before any learner
state integration. A model solution or given diagram inside a response area is
still authored content, not an answer supplied by a learner.

Existing input names, canvas item/part keys, module instances, graphic IDs, and
notebook sessions are retained with their owning content. Reading boundaries
distinguish nested tasks from following global inputs; occurrence labels do not
erase source-item identities. Reserved writing lines are layout, not expected
answer length. See [input identities and context](docs/BUNDLE.md#input-identities-and-context)
for the mapping, duplicate checks, and the deliberate boundary for blanks.

The reading view includes that available response content as a bounded group,
and describes coordinate systems/3D scenes with their exact semantic data
rather than only axis ranges. It does not load `.work` or infer learner progress.
Interactive graphics retain their exact slider contracts, all dropdown
alternatives, symbolic geometry and read-only computed outputs together.
Native applet blocks additionally retain their complete content, a distinct
print-description body, publication URL and ordinary block identity. PDF may
paint only the linked description; both semantic bodies remain available in
AI, including the HTML-embedded bundle.
Outputs retain their expressions, units and explicit domains, independently
of layout and ordinary numeric display precision. Coordinate zoom retains its
centre, panning, control coupling and the rule for preserving interior values
and holding reached slider boundaries; explicit comparisons of displayed slider values
also retain the precision that determines their domain. Activity descriptions retain
the metadata supplied by the module, not invented future quiz questions.
Defaults remain authored initial values, not learner contributions. See
[interactive input declarations](docs/BUNDLE.md#interactive-input-declarations).
Within mathematics, explanations stay attached to exact subexpressions, and
authored model solutions and intentional blanks remain distinct from givens.
See the [mathematical scope and visibility contract](docs/BUNDLE.md#meaning-inside-mathematics).
Formulas retain ordinary mathematical TeX together with author context and
add native Typst source plus a table of used symbol/expression spellings.
The learning coach can reuse `arrow(v)` directly instead of translating
`\vec{v}`. Unsupported raw notation is explicitly marked;
mathematical alphabets, accents, indices, and vector notation are not discarded
as font styling. See [notation and understanding](docs/BUNDLE.md#mathematical-notation-and-understanding).
Exam tasks retain occurrence-specific achievable points and exam/course/date
identity. Grading grids retain their task relationships; explicitly selected
item histories remain distinct from current tasks and learner results. See
[exam semantics](docs/BUNDLE.md#exams-and-assessment-context).

Solution checkpoints retain their achievable credit and exam/item identity in
both JSON and Markdown. A printed score circle is not a learner grade; private
per-task working-time notes remain excluded.
Native single-choice/true-false questions retain stable inputs and option keys,
actual shuffled order, prerequisites and aggregate scoring in both views.
Their at-most-one selection rule explicitly permits leaving a question
unanswered; this is input policy, not an inferred learner response.
Correct keys and explanations are present only when solutions are enabled;
learner bundles do not recover them. See the
[input contract](docs/BUNDLE.md#interactive-input-declarations).
Repeated reference names retain their selected occurrence anchor and the
authored `reference_name` in JSON and Markdown. Variant selection happens
before projection; unselected bodies never enter either artifact.
Links retain both their captions and destinations in the reading view,
including QR URLs, equation-row and list-entry targets, and solution owners.
See [links and targets](docs/BUNDLE.md#links-and-targets) for the exact mapping.
Explicitly selected index and symbol occurrences now form complete directories,
including later and nested passages. The reading view retains supplied symbol
meanings, hierarchy, roles, and linked locations; it neither indexes ordinary
appearances automatically nor recovers hidden solutions. See
[selected terms and symbols](docs/BUNDLE.md#selected-terms-and-symbols).
Quotations retain an explicit `quote` kind, their nested content, emphasis,
explanations and reference/item identity. The Markdown view bounds the quoted
passage and identifies its role; physical indentation is omitted.
Text roles remain distinct: emphasis, underlining, and explicit definition
conventions are not interchangeable. Questions retain their body, designation,
and explanations, not centering. Prose is escaped as literal text; verbatim and
showcase source preserve code whitespace without being evaluated again. See
[text roles and literal source](docs/BUNDLE.md#text-roles-and-literal-source).
Editable showcases also declare notebook input intent and their existing
`session` identity. Authored source and original build result remain separate
from any later learner edits; static examples do not become input requests.
See [showcases and notebook cells](docs/BUNDLE.md#showcases-and-editable-notebook-cells).

Person mentions and full profiles retain stable catalogue IDs, exact displayed
names, authored dates, separate short/full biographies, optional portraits and
named web resources. The reading view includes these identities and links;
HTML popup state and physical catalogue paths are excluded. See the
[versioned person contract](docs/BUNDLE.md).

PyHTML embeds the same bundle contract as inert JSON by default. Use
`pyhtml --no-embed-ai` to omit it deliberately. PyAI still performs no model
call or tutoring behavior. The tool-only provenance file is included in that
transport too; it can contain local author paths. Supply `document.md` and,
when useful, `document.json` to a model, not the entire transport envelope.

For package tests, the `test` dependency group supplies the CommonMark parser
used to verify the generated reading view's actual interpretation. It is not
a runtime dependency of PyAI.
