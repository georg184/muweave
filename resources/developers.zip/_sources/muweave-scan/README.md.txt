# muweave-scan

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.

Local PDF exam-scan registration and PNG extraction for MuWeave print templates.
This independent, optional tool consumes final `.scan.json` or
`.exam-batch.json` print metadata produced by PyTeX5. It never expands source,
reads `.work`, uploads learner data or grades
answers. The application workflow also provides conservative local MC-checkbox
observations; the separate CLI import does not yet provide an MC review UI.
**This remains a pilot:** an initial unfilled real copier scan is
covered; handwriting quality and broader copier acceptance remain unverified.

## Use

Python 3.13+, the declared package dependencies and system MuPDF (`mutool run`
and `mutool draw`, tested with 1.25.1) are needed. The command belongs to this
package, not to `mucompose` or the Suite umbrella.

```console
muweave-scan import scan.pdf \
  --template Druckprobe_A.pdf --template Druckprobe_B.pdf \
  --template Zusatzblatt.pdf --output auswertung-1
```

For the actual 18-copy examination, use the unchanged merged print PDF:

```console
muweave-scan import Probescan_300dpi.pdf \
  --template 1_gesamt.pdf --template Zusatzblatt.pdf --output Probescan_Auswertung
```

Each PDF needs **exactly one** original sibling `.scan.json` or
`.exam-batch.json`. No temporary individual PDFs, MuWeave sources or recompiling
are needed for a merged batch. Different copies remain distinct even within
the same group. The output directory must not exist.

Standalone geometry is verified against native PDF destinations. Merged PDFs
no longer contain those destinations: their **trusted original batch sidecar**
supplies the retained geometry. The importer checks its merged-PDF checksum,
audience, complete consecutive copy ranges, identities, physical dimensions,
marks and field bounds. On use, it also checks the reference page's actual QR
pixels. This is not a digital signature or a remeasurement of lost metadata;
keep the printed PDF and its original sidecar together. Historical individual
hashes are retained as provenance, never claimed to verify reconstructed files.

Open `auswertung-1/review.html` locally. It shows source pages, geometric
proposals, separate name/number and answer PNGs, and uncertain cases. The report
works offline. Readable exam QRs plus matching print scaffolds establish page
identity; generic supplements always require explicit visual confirmation in
this first implementation. **An unreadable exam QR never means supplement.**
Single- and multi-QR decoding are combined. Conflicting or unknown decoded
identifiers still require review; QR recovery does not relax the geometry or
printed-layout checks. See [QR recovery and scan resolution](#qr-recovery-and-scan-resolution).

Confirm page/template/orientation, name or ID on the START page, and handwritten
task/subtask numbers on supplements. Save `entscheidungen.json` using the
report's button, then reimport into a new directory:

```console
muweave-scan import scan.pdf \
  --template Druckprobe_A.pdf --template Druckprobe_B.pdf \
  --template Zusatzblatt.pdf --decisions entscheidungen.json --output auswertung-2
```

Decisions are bound to the original scan hash and the complete set of
copy-specific print references, including exact PDF and sidecar bytes.
The report does not save edits automatically or pretend its previous results
have already been recalculated. Reimport preserves prior directories.

Imports write `batch.json` format version 5 and decisions format version 2.
Import 5 adds bounded, resolution-preserving QR recovery and its attempt trace;
import 4 added original-page provenance for explicitly reordered input. Existing
reports remain unchanged; formats 3, 4 and 5 can supply ordering evidence. Review
decisions still require the exact input PDF and print-reference hashes: sorting
changes the PDF hash, so decisions for the original cannot silently apply to
the sorted file. Save fresh decisions from its new review report.

The existing mirrored workspace environments are not modified automatically.
For source development use `PYTHONPATH=muweave-scan/src python -m muweave_scan`;
the interpreter must have this package's runtime dependencies.

## Ordering before the final import

Use the first local recognition report to create a separate sorted scan:

```console
muweave-scan order 1_scan.pdf --from-import scan-erkennung/batch.json \
  --output 1_scan_ordered.pdf
muweave-scan import 1_scan_ordered.pdf \
  --template 1_gesamt.pdf --template Zusatzblatt.pdf \
  --ordering 1_scan_ordered.order.json --output scan-auswertung
```

The original PDF is never edited. MuPDF copies PDF pages without rasterizing or
resampling them for sorting. `1_scan_ordered.order.json` records exact source,
recognition-report and result hashes, both directions of the page permutation,
and unresolved cases. Both new files must not already exist. Keep them private
and together; the JSON is provenance, not a substitute for the original PDF.

Default `--mode contiguous` repairs, for example, a complete exam scanned as
pages 3, 4, 1, 2. It requires individually generated batch-copy identities and
moves only complete, consecutive runs of one confirmed copy. Whole-exam order
is unchanged. Unconfirmed pages, generic supplements and standalone prints
are barriers; incomplete or duplicate copies are preserved, not guessed or
discarded. A `partial` result still contains every original page exactly once.
It can be reimported, but unresolved recognition remains unresolved.

For completely mixed **regular exam pages**, use `--mode global`. Every page
must be confirmed, and each present printed copy must occur completely, once
per page. Absent whole copies are allowed. Copies are grouped in order of their
first occurrence in the scan, with their pages in printed order. Ambiguity,
duplicate pages, incomplete copies, generic supplements or non-unique
photocopied print IDs stop global sorting without publishing a result. A
missing QR is never recovered merely by similarity or neighbouring pages.

With `--ordering`, the new import retains `original_source_page` on pages and
crops and shows the original index in local review. Decision keys continue to
use the sorted input's `source_page`, not the original index. The order sidecar
does not transfer recognition or personal confirmations: every page is
recognized and extracted afresh. The initial recognition report currently
comes from an ordinary import; a lighter recognition-only pass is planned.

## QR recovery and scan resolution

The importer first decodes the unrectified whole-page raster. If no code is
readable, it fits the printed registration marks and uses plausible print
scaffolds to locate QR search areas. Locations come from the **unchanged print
PDF**, including white quiet margins; no hardcoded examination coordinates or
new print manifest is required. Reference pixels supply only locations, never
the learner scan's decoded payload.

Each area is tried as an original-pixel crop and as a crop rectified directly
from the source. Both views finish each attempt. A bounded fallback ladder
uses original grayscale, double-size nearest-neighbour scaling, Otsu and
adaptive thresholding, then moderately relaxed OpenCV finder tolerances.
These affect detection only, not QR error-correction capacity or identifier
matching. Further profiles stop after success, but results from distinct
candidate locations are combined, including repeated printed copies of one QR.
If needed, whole-page rectification remains a final fallback.

QR rectification now uses the requested `--dpi`, **not a fixed 300 dpi**.
For an actual 600-dpi copier scan, for example:

```console
muweave-scan import scan.pdf --template 1_gesamt.pdf \
  --template Zusatzblatt.pdf --dpi 600 --output auswertung-600
```

The default remains 300 dpi. Higher scanner resolution requires a matching
import density to retain that extra detail. Increasing `--dpi` on an existing
300-dpi scan does not recreate lost information. Cropping/resizing may help a
decoder independently of genuine optical resolution.

`batch.json` records per-page `qr_attempts`: source/rectified page or ROI,
profile, pixel dimensions, finder tolerances, observed payloads and native
decoder errors; ROI attempts additionally record search coordinates, rotation
and rectification density. This is a **local diagnostic**, not learner identity
or handwriting interpretation. The fixed retry ladder runs automatically;
there is no new tolerance CLI option. Work is capped and a reached search
budget produces `qr_retry_limit`/`needs_review`, not an automatic assignment.

No image enhancement is applied to stored source rasters or answer PNGs.
Existing manual decisions remain explicit and all existing evaluation
directories remain unchanged; use a new import directory to get new results.

## Output and limits

- `original.pdf`: exact input PDF bytes. After ordering this is the sorted
  derivative, not the unsorted copier original; retain that original separately.
- `templates/`: exact original print PDFs/sidecars and lazily created reference rasters.
- `pages/`: RGB source rasters and annotated review images.
- `identity/`: separate local name/ID crops.
- `fields/`: response and supplementary assignment crops.
- `batch.json`: versioned identities, original page order, geometry, hashes,
  crop provenance and unresolved states. Import time is **not writing time**.
- `decisions.input.json`: exactly the validated review input used by this run.
- `ordering.input.json`: validated optional ordering provenance, explicitly
  bound to the input PDF and print references.
- `review.html`: private offline review and new-decisions download.

Defaults are 300 dpi and 0.75 mm external safety padding. `--dpi` accepts
72–600, `--padding-mm` accepts 0–3. The safety margin does not expand the
graded area. Colour and faint strokes are retained; thresholding is only a
separate detection step. PNG storage is lossless, but geometric resampling
still interpolates pixels. Each PDF input is limited to 500 pages/1 GB and
40 MP per raster page. Supply at most 16 reference PDFs, with at most 500
reference pages altogether; a batch copy may have at most 64 pages. Sidecars
are limited to 32 MB each. References are rasterized only when used, with at
most four reference images cached in RAM, not one image per printed page.

Page recognition is **not a legibility check**: copier background suppression
can erase faint pencil while leaving QR codes and registration marks intact.
Neither PNG storage nor registration can recover that missing information.
Check source quality before assessment; the synthetic
[quality experiments](docs/SYNTHETIC_SCAN_TESTS.md) demonstrate this distinction.

This first detector supports the pilot's **uncoded solid squares**, including
more than four marks and moderate skew/scale/perspective changes. It checks
mark coverage and residuals and compares print scaffolds outside writable
interiors. Symmetric marks alone never establish orientation. Unsupported or
insufficient geometry remains unresolved, even with a manual page decision.

Without preprocessing, the importer's input order is START, all regular exam pages, then zero or more
generic supplement pages, then the next START. Unknown or contradictory pages
interrupt automatic assignment. No missing image is graded as blank or wrong;
no handwriting OCR or duplicate-person inference occurs. Arbitrarily shuffled
anonymous supplements cannot be reliably assigned by this format. Individually
QR-identified regular pages can first be sorted as described above.

**The whole output directory is private working material, not anonymized.**
Directories use owner-only permissions; identity crops are separate, but names
can also occur within answers. No model-ready payload or external disclosure
is produced. See [architecture and persisted formats](ARCHITECTURE.md) and
[tests/remaining work](DEVELOPMENT.md).

## Python API

Exam-batch formats 1, 2 and 3 are accepted. Format three's private task/solution
evidence does not change the measured scan geometry or crop assignment; this
package neither interprets grading supplements nor owns their storage.

Applications such as Schoolman should use **`muweave_scan.workflow`**, not
decode internal reports or orchestrate image-processing modules themselves:

```python
from pathlib import Path
from pytex5.print_package import read_print_package
from muweave_scan.workflow import ScanRequest, process_scan, image_path

package = read_print_package(Path("1_Druckbestaende/retained-run"))
request = ScanRequest(
    scan=Path("scan.pdf"),
    packages=(package.directory,),
    expected_ids=(package.package_id,),
    # Optional explicitly authorized search and supplement references:
    collections=(Path("1_Druckbestaende"),),
    supplements=(Path("Zusatzblatt.pdf"),),
    dpi=300,
)
result = process_scan(request, Path("new-private-run"))
page_png = image_path(result, result.pages[0].image)
```

The application owns the files, including PNGs and earlier results; this tool
only processes into its explicit output directory. Public `ScanReview`,
`initial_review`, `review_context` and `apply_review` support saved human
confirmations without parsing internal reports. Schoolman stores the revisions
and learner links itself. Processing page/field repairs creates a new run, not
an in-place edit; host-owned identity links can take effect independently.
See the [workflow API](docs/WORKFLOW_API.md#human-confirmations-owned-by-the-application).

`muweave_scan.return_workflow.read_return_layout(result)` separately exposes
the original grading-table and writable task/total/grade rectangles, when the
print has scan-format-two measurements. It preserves current/original/copy
page identities and distinguishes legacy absence from empty continuation pages
and unresolved recognition. No additional PNGs, grades or corrected PDFs are
created. See [return layouts](docs/WORKFLOW_API.md#measured-return-layouts).

For explicitly approved corrections, the same `return_workflow` module provides
`ReturnRequest`, `validate_return_request`, `export_return_pdf` and
`read_return_export`. It writes a new lossless scan-based PDF, adds measured red
grading values, and inserts person-bound feedback sheets with duplex separation.
Return protocol version 2 uses the host's approved current identity assignments
on already processed submission boundaries, without requiring a new scan run.
Retained version-one requests and outputs remain readable with their old contract.
An explicit `feedback_only` mode supports legacy prints without estimating
table coordinates. Approval validity, background jobs and file retention remain
application-owned; Schoolman supplies their native workflow. The renderer uses
local ReportLab, MuPDF and an embedded TrueType font (DejaVu Sans on Debian,
otherwise the bundled Vera fallback; unsupported glyphs fail explicitly).
See the [return API](docs/WORKFLOW_API.md#approved-return-pdfs).

The facade implements exact input copying, collection matching, conservative
ordering and extraction. It returns immutable page/field metadata with
checksummed PNG references; applications own file retention, jobs, personal
assignments and presentation. Run processing outside the GUI thread. See the
[application API contract](docs/WORKFLOW_API.md) for progress, cancellation,
safe retry and integrity-checked lazy browsing. Existing CLI and the following
lower-level APIs remain available for detailed scan-tool integrations.

```python
from pathlib import Path
from muweave_scan.pipeline import import_scan

result = import_scan(
    Path("scan.pdf"), [Path("Druckprobe_A.pdf"), Path("Zusatzblatt.pdf")],
    Path("auswertung-1"), dpi=300, padding_mm=0.75,
)
```

`import_scan(scan, templates, output, *, dpi=300, padding_mm=0.75,
decisions=None, ordering=None, progress=None) -> Path` returns `batch.json`. Paths are
`pathlib.Path`; the optional progress callback receives completed/total pages.
CLI success means that a reviewable import was written, not that every page
was assigned. See `batch.status`, page issues and submission issues.

`muweave_scan.ordering.order_scan(scan, recognition, output, *,
mode="contiguous") -> Path` creates the ordered PDF and returns its `.order.json`.
All three file arguments are `pathlib.Path`. `recognition` is a trusted local
`batch.json` bound to the original scan, never an unverified model proposal.
