# MuWeave Suite

`muweave-suite` is the umbrella distribution for the complete supported
MuWeave document toolchain. It installs the component distributions together
while preserving their independent package boundaries.

MuWeave documents execute unrestricted Python code. Process only trusted
documents and trusted vocabulary or setup modules.

## Components

| Distribution | Responsibility |
| --- | --- |
| `muweave` | Format-neutral parsing, expansion, evaluation, rendering, references, and provenance |
| `mudoc` | Optional immutable document tree and blank-line paragraph parser over typed expansion |
| `muweave-lsp` | Non-evaluating editor diagnostics, semantic tokens, selection formatting, and LSP integration |
| `mucli` | Shared frontend option, configuration-layer, and vocabulary-loading policy |
| `muweb` | Deterministic validation, packaging, and installation of interactive composition modules |
| `mugeometry` | Profile-aware calibrated geometry model and matching Python/JavaScript evaluators |
| `muvocab` | Portable vocabulary, target renderers, and explicit MuDoc adapter |
| `pyai` | Layout-free semantic JSON/Markdown bundle for model consumption |
| `pytex5` | LaTeX/LuaLaTeX frontend and experimental lwarp integration |
| `pymyst` | MyST frontend, project publication, HTML, and experimental PDF integration |
| `pyhtml` | Direct self-contained HTML worksheet with drawing palette, vector canvas, conditional MathJax 4, and embedded semantic context by default |
| `muweave-reader` | Optional PySide6 host that enables explicitly trusted native notebook cells in an unchanged PyHTML file |
| `mucompose` | Thin process-level orchestration of the independent frontends |

The suite does not re-export these packages, define another author namespace,
or add another command-line program. Use each component's documented API and
the `muweave`, `muweb`, `pyai`, `pytex5`, `pymyst`, `pyhtml`,
`muweave-reader`, and `mucompose`
commands directly.

The optional [muweave-scan](../muweave-scan/README.md) component imports copier
PDFs locally, produces measured PNG answer crops and an offline review report.
Install the `scan` extra when needed (`muweave-suite[scan]`); document builds
do not acquire OpenCV or a scan step. This pilot still awaits copier acceptance.

## Installation

For an ordinary published installation:

```console
python -m pip install muweave-suite
```

Inside the `ggpackages` workspace, install the complete local dependency
closure in editable mode with:

```console
python install_ggpackages.py muweave-suite
```

This distribution installs the Python packages and a version-matched ecosystem
documentation snapshot. LuaLaTeX, lwarp, Node.js, and the MyST executable
remain separately managed external tools.

## Documentation

- [AI-agent authoring guide](docs/AGENT_AUTHORING.md): complete system workflow,
  language rules, tool selection, examples, and quick reference.
- [Human Sphinx guide](docs/index.rst): progressive tutorials, recipes,
  troubleshooting, and selected integration APIs.
- [Complete local documentation](docs/local_documentation.rst): one searchable
  HTML portal containing every bundled ecosystem document plus exact example
  and resource downloads.
- [MuVocab authoring reference](../muvocab/docs/AUTHORING.md): exact portable
  author operations, signatures, validation, and target behavior.
- [Structured-document integration](../muvocab/docs/DOCUMENT_MODEL.md):
  renderer-free typed evaluation and MuVocab-to-MuDoc adaptation.
- [Interactive web modules](docs/interactive_modules.rst): author workflow,
  offline HTML behavior, printable fallback, and learner-state identity.
- [Semantic AI context](docs/ai_export.rst): source-derived author content,
  declared learner inputs, current export limits, and the planned separation
  between authoring assistance and a learning coach.

The installed distribution exposes the same entry points without requiring a
source checkout:

```python
from muweave_suite.documentation import agent_guide, documentation_root, human_guide

print(agent_guide())
print(human_guide())
print(documentation_root())
```

These functions return `importlib.resources` traversables. Read the agent guide
directly with `agent_guide().read_text(encoding="utf-8")`. The documentation
root preserves the workspace package layout, so links from the suite guides to
component-owned references remain valid inside the installed snapshot.

From a shell in any directory, locate the installed agent guide with:

```console
python -c "from muweave_suite.documentation import agent_guide; print(agent_guide())"
```

Build the complete persistent local HTML portal from the workspace root:

```console
./pythonvenv1_dbg/bin/python \
  muweave-suite/scripts/build_local_documentation.py
```

The command synchronizes the version-matched source snapshot first, retains a
previous successful site if Sphinx fails, and prints the resulting `file://`
URL. Its stable workspace entry is:

```text
file:///<workspace>/muweave-suite/build/docs/html/index.html
```

The generated `build/` tree is local and disposable. It is not a canonical
documentation source and is not packaged or committed.

Build only the smaller guided manual in a temporary directory with:

```console
./pythonvenv1_dbg/bin/python -m sphinx \
  -W --keep-going -b html muweave-suite/docs /tmp/muweave-sphinx-html
```

## Python package

The deliberately minimal root import exposes only its version:

```python
import muweave_suite

print(muweave_suite.__version__)
```

The separate `muweave_suite.documentation` submodule locates documentation
resources only. It does not mirror component APIs or add a console command.

## Development

Run the focused tests from the workspace root with:

```console
PYTHONPATH=muweave-suite/src \
  ./pythonvenv1_dbg/bin/python -m unittest discover \
  -s muweave-suite/tests -p 'test_*.py'
```

Maintainer synchronization and packaging checks are documented in
[DEVELOPMENT.md](DEVELOPMENT.md).
