# MuWeave Suite

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.

`muweave-suite` is the umbrella distribution for the complete supported
MuWeave document toolchain. It installs the component distributions together
while preserving their independent package boundaries.

MuWeave documents execute unrestricted Python code. Process only trusted
documents and trusted vocabulary or setup modules.

## License

The suite, its optional components and its transitive local Python dependencies
are free software under the GNU General Public License, version 3 only
(`GPL-3.0-only`). Each distribution includes the complete [license](LICENSE)
and its own copyright and scope [notice](NOTICE). The authoritative component
and dependency selection remains in the package manifests.

Third-party dependencies and bundled third-party resources retain their own
licenses and notices. Separately developed packages outside this dependency
closure are not relicensed by the suite's license.

Using the toolchain does not by itself determine the license of an author's
own document text, exercises or images. Software copied into an output,
including worksheet JavaScript, retains its applicable license and source
distribution obligations. The document's content and its embedded software
must therefore be distinguished when redistributing a worksheet.

The µWeave name and logo belong to Georg G. The logo artwork is outside the
software's GPL grant; its permitted identifying use, including the `µweave`
command, is described in [MuVocab's notice](../muvocab/NOTICE).

## Components

| Distribution | Responsibility |
| --- | --- |
| `muweave` | Format-neutral parsing, expansion, evaluation, rendering, references, and provenance |
| `mudoc` | Optional immutable document tree and blank-line paragraph parser over typed expansion |
| `muweave-lsp` | Non-evaluating editor diagnostics, semantic tokens, selection formatting, and LSP integration |
| `mucli` | Shared frontend option, configuration-layer, and vocabulary-loading policy |
| `muweb` | Deterministic validation, packaging, and installation of interactive composition modules |
| `mugeometry` | Profile-aware calibrated geometry model and matching Python/JavaScript evaluators |
| `muvocab` | Portable vocabulary, target renderers, and explicit MuDoc adapter |
| `pyai` | Layout-free semantic JSON/Markdown bundle for model consumption |
| `pytex5` | LaTeX/LuaLaTeX frontend and experimental lwarp integration |
| `pymyst` | MyST frontend, project publication, HTML, and experimental PDF integration |
| `pyhtml` | Direct self-contained HTML worksheet with native MathML through Typst by default, drawing palette, vector canvas, and embedded semantic context |
| `muweave-reader` | Optional PySide6 host that enables explicitly trusted native notebook cells in an unchanged PyHTML file |
| `mucompose` | Thin process-level orchestration of the independent frontends |

The suite does not re-export these packages, define another author namespace,
or add another command-line program. Use each component's documented API and
the `muweave`, `muweave-expand`, `muweb`, `pyai`, `pytex5`, `pymyst`,
`pyhtml`, and `muweave-reader` commands directly. The `mucompose` distribution
provides the canonical `muweave` document-build command and the temporary
`mucompose` alias; the core `muweave` distribution provides `muweave-expand`
for low-level expansion.

The optional [muweave-scan](../muweave-scan/README.md) component imports copier
PDFs locally, produces measured PNG answer crops and an offline review report.
Install the `scan` extra when needed (`muweave-suite[scan]`); document builds
do not acquire OpenCV or a scan step. This pilot still awaits copier acceptance.

The optional [MuWeave Tuning Lab](../angle-label-tuning-lab/README.md) collects
angle, segment and vector label-spacing observations through the actual
document renderers. Install `muweave-suite[tuning]` and launch
`muweave-tuning-lab`. Angle and segment tuning default to MathML via Typst and also
offers MathJax 4 and exact LaTeX/PyTeX5 previews. The independent distribution
and the previous command remain named `angle-label-tuning-lab` during migration.

## Installation

For an ordinary published installation:

```console
python -m pip install muweave-suite
```

Inside the `ggpackages` workspace, install the complete local dependency
closure in editable mode with:

```console
python install_ggpackages.py muweave-suite
```

This distribution installs the Python packages and a version-matched ecosystem
documentation snapshot. LuaLaTeX, lwarp, Node.js, and the MyST executable
remain separately managed external tools.

Third-party Python and native dependencies, including Qt and PySide6 for the
Reader, are installed as separate packages in the user's environment. MuWeave
does not ship a desktop bundle containing these libraries. Package metadata
declares the dependencies so installation tools can resolve them.

Standalone worksheets embed the browser resources they need, including
JavaScript, fonts and, when required, the Typst WASM compiler. These resources
are redistributed with the worksheet under their respective licenses;
required license texts and notices must remain included. See
[PyHTML](../pyhtml/README.md) for the self-contained output contract.

For an existing installation, refresh the changed console entry points through
installman; editable source changes alone do not replace installed launchers.
In this workspace, request that environment update through the normal
installman workflow and keep the mirrored `pythonvenv1` and `pythonvenv1_dbg`
environments untouched by agents. See the
[command migration guide](docs/frontends.rst#command-migration) for option and
configuration changes.

## Documentation

- [AI-agent authoring guide](docs/AGENT_AUTHORING.md): complete system workflow,
  language rules, tool selection, examples, and quick reference.
- [Human Sphinx guide](docs/index.rst): progressive tutorials, recipes,
  troubleshooting, and selected integration APIs.
- [Complete local documentation](docs/local_documentation.rst): one searchable
  HTML portal containing every bundled ecosystem document plus exact example
  and resource downloads.
- [MuVocab authoring reference](../muvocab/docs/AUTHORING.md): exact portable
  author operations, signatures, validation, and target behavior.
- [Structured-document integration](../muvocab/docs/DOCUMENT_MODEL.md):
  renderer-free typed evaluation and MuVocab-to-MuDoc adaptation.
- [Interactive web modules](docs/interactive_modules.rst): author workflow,
  offline HTML behavior, printable fallback, and learner-state identity.
- [Semantic AI context](docs/ai_export.rst): source-derived author content,
  declared learner inputs, current export limits, and the planned separation
  between authoring assistance and a learning coach.

The installed distribution exposes the same entry points without requiring a
source checkout:

```python
from muweave_suite.documentation import agent_guide, documentation_root, human_guide

print(agent_guide())
print(human_guide())
print(documentation_root())
```

These functions return `importlib.resources` traversables. Read the agent guide
directly with `agent_guide().read_text(encoding="utf-8")`. The documentation
root preserves the workspace package layout, so links from the suite guides to
component-owned references remain valid inside the installed snapshot.

From a shell in any directory, locate the installed agent guide with:

```console
python -c "from muweave_suite.documentation import agent_guide; print(agent_guide())"
```

Build the complete persistent local HTML portal from the workspace root:

```console
./pythonvenv1_dbg/bin/python \
  muweave-suite/scripts/build_local_documentation.py
```

The command synchronizes the version-matched source snapshot first, retains a
previous successful site if Sphinx fails, and prints the resulting `file://`
URL. Its stable workspace entry is:

```text
file:///<workspace>/muweave-suite/build/docs/html/index.html
```

The generated `build/` tree is local and disposable. It is not a canonical
documentation source and is not packaged or committed.

Build only the smaller guided manual in a temporary directory with:

```console
./pythonvenv1_dbg/bin/python -m sphinx \
  -W --keep-going -b html muweave-suite/docs /tmp/muweave-sphinx-html
```

## Python package

The deliberately minimal root import exposes only its version:

```python
import muweave_suite

print(muweave_suite.__version__)
```

The separate `muweave_suite.documentation` submodule locates documentation
resources only. It does not mirror component APIs or add a console command.

## Development

Run the focused tests from the workspace root with:

```console
PYTHONPATH=muweave-suite/src \
  ./pythonvenv1_dbg/bin/python -m unittest discover \
  -s muweave-suite/tests -p 'test_*.py'
```

Maintainer synchronization and packaging checks are documented in
[DEVELOPMENT.md](DEVELOPMENT.md).
