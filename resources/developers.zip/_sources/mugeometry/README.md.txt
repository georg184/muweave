# mugeometry

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.

`mugeometry` is the dependency-light shared calibration boundary for generated
geometry in the MuWeave ecosystem. It provides immutable angle-label queries
and results, a machine-readable renderer-profile registry, a deterministic
model artifact, and a Python evaluator numerically matched to the existing
JavaScript calibration. It also provides canonical segment-label placement
and computes Hobby interpolating curves as cubic Bézier segments using only
the Python standard library.

The package does not parse MuWeave, define author vocabulary, render HTML or
LaTeX, or run a browser. MuVocab owns `g.angle(...)`; its direct-HTML and
LuaLaTeX/TikZ adapters and `ggprojects` applications call this same
`mugeometry` predictor.

The calibration's source observations were made with MathJax
3.2.2/CommonHTML. PyHTML's MathJax 4.1.3/SVG profile and PyTeX5's declared
LuaHBTeX 1.24.0, PGF/TikZ 3.1.12, Latin Modern Math 1.959 profile are each
registered as provisional reuse of that calibration. Direct MathJax-4 pilot
observations form a separate target-profile correction over the inherited
source prediction; they neither alter MathJax-3 results nor promote any
binding to exact. Callers must opt in to provisional use explicitly:

```python
from mugeometry import (
    PYHTML_MATHJAX_4_SVG_PROFILE_ID,
    resolve_angle_label_calibration,
)

selection = resolve_angle_label_calibration(
    PYHTML_MATHJAX_4_SVG_PROFILE_ID,
    allow_provisional=True,
)
assert selection.compatibility == "provisional"
```

Direct HTML now selects `PYHTML_MATHJAX_4_SVG_INK_PROFILE_ID`
(`muweave-mathjax-4-svg-ink-v1`). PyHTML's matching adapter fixes the physical
glyph size and centres its visible path bounds independently of surrounding
text fonts. This new environment has no direct observations yet; it explicitly
reuses the original MathJax-3 evidence provisionally. The historical
`PYHTML_MATHJAX_4_SVG_PROFILE_ID` remains unchanged, with its own pilot
corrections. Those measurements are not reassigned to the ink-centred profile.
The [browser contract](../pyhtml/docs/CALIBRATED_MATH_LABELS.md) specifies the
adapter and the separately planned tuning-lab migration.

The default PyHTML native-MathML path selects
`PYHTML_NATIVE_MATHML_PROFILE_ID`
(`muweave-native-mathml-lm-1.959-box-v1`). It uses Latin Modern Math 1.959 and
browser-measured formula boxes, not MathJax SVG ink bounds. This profile is
provisional, has no direct observations and explicitly inherits the original
MathJax-3 source evidence. Registering it generates its model/evaluator entry;
it does not relabel old samples or certify identical placement across browser
engines. It cannot receive new observations. Authentic native angle batches use
`native_mathml_angle_label_profile(compiler_version=..., browser_engine=...,
browser_version=...)`; the exact descriptor hashes the complete Typst/browser,
font and measurement environment. `angle_label_observation_profile(profile)`
provides the browser batch spelling. A first validated real batch registers
that target and retains its measured box dimensions atomically with the new
generation. Its binding remains provisional and its direct correction remains
separate from all other profiles. Native documents select matching exact
evidence in the receiving browser, otherwise retaining the generic fallback.

The public predictor uses typographic points at its boundary and returns
font-relative geometry. It never treats CSS pixels as physical screen pixels:

```python
from decimal import Decimal

from mugeometry import (
    MATHJAX_3_CHTML_PROFILE_ID,
    AngleLabelIdentity,
    AngleLabelQuery,
    infer_angle_label_class,
    predict_angle_label,
)

label_class = infer_angle_label_class("α", r"\alpha")
prediction = predict_angle_label(
    AngleLabelQuery(
        opening_degrees=Decimal(45),
        base_ray_degrees=Decimal(90),
        label=AngleLabelIdentity("α", r"\alpha", label_class),
        font_size_pt=Decimal(12),
        ray_stroke_width_pt=Decimal(1),
        arc_stroke_width_pt=Decimal("0.75"),
        target_profile_id=MATHJAX_3_CHTML_PROFILE_ID,
    )
)
print(prediction.layout.arc_radius_em)
```

`prediction.layout` and all three placement overrides describe ideal
**thin/reference lines**, as do tuning-lab samples. The complete visible
marker also needs clearance for the rays' and arc's actual widths:

```python
from mugeometry import project_angle_label

marker = project_angle_label(prediction)
# Multiply these by the requested font size in the target's physical units.
print(marker.arc_radius_em)
print(marker.label_x_em, marker.label_y_em)
```

`project_angle_label(prediction)` returns an immutable `AngleLabelProjection`.
Its radius is the visible arc's centre-line radius; its label coordinates are
relative to the vertex, rightward/upward positive. A downward-positive SVG
adapter negates y. The operation applies analytical stroke clearance once,
after overrides, using the actual opening even outside the model's lookup
range. It neither changes the input nor evaluates the model again; a projected
value is not accepted as another projection input. Zero widths recover the
thin geometry. The full projection is checked against the tuning lab's
JavaScript marker, separately from model-only conformance.

The generated JavaScript evaluator also exposes
`GGMuGeometryAngleLabel.projectAngleLabel(query, layout)` and
`ANGLE_LABEL_PROJECTION_VERSION` (currently `1`). The numeric `query` uses
`opening_degrees`, `base_ray_degrees`, `font_size_pt`,
`ray_stroke_width_pt`, and `arc_stroke_width_pt`; the thin `layout` uses
`arc_radius_em`, `label_radius_em`, and `label_angle_offset_degrees`.
The frozen result has `arc_radius_em`, `label_x_em`, and `label_y_em`, with
the same upward-positive, vertex-relative em coordinates as Python. It rejects
invalid inputs and projected values as inputs. No prediction or mutation
happens here; manual overrides are applied before this exactly-once step.
The tuning lab's current HTML profile uses this implementation. Historical
consumers keep their own explicitly pinned rendering profiles.

Direct HTML uses this projection. Historical PDF rendering and its collected
evidence are intentionally unchanged until their measurement-profile audit;
the remaining lab integration and profile validation are tracked in
[PLAN-ANGLE-LABEL-PROJECTION.md](docs/PLAN-ANGLE-LABEL-PROJECTION.md).

The generated model is the only known-label class registry. The public
`infer_angle_label_class(text, math_source=None)` helper accepts either visible
or mathematical spelling and returns `"small"`, `"medium"`, or `"large"`;
unknown labels use the deterministic `"medium"` fallback. Consumers may still
construct `AngleLabelIdentity` with an explicit class when an author override
is required.

## Segment and vector label geometry

`segment_label_frame` is the shared side-conversion boundary for segment and
vector labels. Supply the original directed endpoints **after projection and
axis scaling**, in physical display units with positive y upward:

```python
from mugeometry import segment_label_frame, place_segment_label

frame = segment_label_frame((0, 0), (0, 10), side="left", label_at=.5)
assert frame.inclination_degrees == 90
assert frame.side == "above"
assert frame.normal == (-1, 0)

placement = place_segment_label(
    frame,
    label_width_em=.8,
    label_height_em=1.1,  # Entire measured label, including any vector accent.
    clearance_em=.2,
    stroke_width_em=.1,
    font_size=2,         # One em occupies 2 of the endpoint display units.
)
assert placement.label_center == (-1.3, 5)
```

The immutable `SegmentLabelFrame` has `inclination_degrees`, canonical `side`,
`anchor`, `tangent` and `normal`. Inclination is modulo `180°`, in
`-90° < alpha <= 90°`. `above` and `below` do not depend on endpoint order;
for exactly vertical segments they mean left and right respectively.
Near-vertical segments are not snapped to that boundary. Directed `left` and
`right` are accepted at this entry point and interpreted before normalization.
Reversing endpoints and swapping directed side preserves the physical side;
also use `1 - label_at` to preserve an off-centre anchor. The caller keeps its
original vector endpoints and arrowhead.

`place_segment_label` keeps the label horizontal and returns an immutable
`SegmentLabelPlacement` with `frame`, `label_center` in display units, and
`center_distance_em`. It uses the renderer's centred, axis-aligned measured
label boundary. Width, height, free clearance and actual stroke width use
`em`; `font_size` converts one em to the frame units. Scalar and vector labels
use this same operation, with vector accents included in their measurements.
Neither endpoint/arrowhead collisions nor neighbouring objects are resolved.
Invalid, collapsed or numerically unrepresentable geometry raises an error.

The packaged `data/segment-label-geometry.js` exposes
`GGMuGeometrySegmentLabel.segmentLabelFrame(start, end, {side, label_at})` and
`placeSegmentLabel(frame, {label_width_em, label_height_em, clearance_em,
stroke_width_em, font_size})`, with the same result fields and frozen values.
Node can import the same file through CommonJS. Both implementations declare
`SEGMENT_LABEL_GEOMETRY_VERSION = 1` and share committed conformance vectors.

MuVocab's existing segment/vector adapters and PyHTML's live segment layout
use the canonical frame. Existing author `label_offset` retains its historical
centreline-to-label-centre meaning; it is not silently reinterpreted as the
new free clearance.

`predict_segment_label_clearance(SegmentLabelQuery(...))` adds a separate
segment calibration above this numerical placement. Its complete
`SegmentLabelIdentity` includes a Latin, Greek or calligraphic base, optional
index and scalar/vector notation. Evidence also matches canonical side and
the exact renderer/compiler/font/measurement/browser profile before local
interpolation over inclination and actual point size. Profile IDs come from
`segment_label_profile_id(metadata)`, a deterministic hash of that complete
environment. A changed browser or compiler cannot silently use old evidence.

The returned `SegmentLabelPrediction` reports `clearance_em`, `calibrated`,
`source`, `sample_count`, `render_profile_id` and integer `data_version`.
Missing nearby matching observations produce the explicit uncalibrated
fallback, normally `0.2 em`; no angle or other-profile samples are inherited.
Pass the resulting clearance to `place_segment_label` with the renderer's
measured complete label dimensions and actual stroke width. The initial
segment cloud contains no invented training points.

The generated `data/segment-label-evaluator.js` exposes
`GGMuGeometrySegmentLabelCalibration.predictSegmentLabelClearance(query)`
with the same fields and numerical contract. `MODEL` is deeply frozen and
contains `data_version`, exact `profiles` and direct `samples`;
`findRenderProfile(metadata)` returns the exact registered ID or `null`.
Both module and browser forms use the same generated model bytes.

The [segment calibration contract](docs/SEGMENT_LABEL_CALIBRATION.md) describes
batch fields, renderer evidence, idempotent updates and independent release
candidates. The existing angle observation history remains unchanged.

## Hobby curves

```python
from mugeometry import hobby_curve

segments = hobby_curve(((0, 1), (1, .5), (3, 1), (4, 2), (5, 3.5), (7, 4)))
midpoint = segments[0].point(.5)
xmin, ymin, xmax, ymax = segments[-1].bounds()
```

`hobby_curve(points, *, tension=1, closed=False, start_curl=1, end_curl=1)`
returns an immutable tuple of `CubicBezier(start, control1, control2, end)`
values. Inputs accept finite `int`, `float`, and `Decimal` coordinates; the
calculation uses binary floats. `point(t)` evaluates one segment for
`0 <= t <= 1`; `bounds()` includes its interior extrema, rather than just its
knots or the larger control-point hull.

Open curves require at least two 2D knots; closed curves at least three.
Adjacent knots must differ, including the closing pair. Use `closed=True`
without repeating the first point. Uniform `tension` must be at least 0.75;
larger values shorten the handles. Nonnegative endpoint curls set the
mock-curvature ratios: 1 is the normal Hobby boundary, 0 gives a locally
straighter endpoint segment. Closed curves have no endpoints and require the
curl arguments to remain at their defaults. Invalid or numerically
unrepresentable geometry raises `TypeError` or `ValueError` before rendering.

The curve interpolates the knots with continuous tangent direction. It need
not be monotone or stay inside their bounding rectangle. No NumPy, SciPy,
PyX, or Gdstk installation is needed. MuVocab's author-facing operation is
[`g.curve`](../muvocab/docs/AUTHORING.md#hobby-interpolating-curves).

## Observation and generation workflow

MuGeometry owns the canonical observation cloud at
`src/mugeometry/data/angle-label-samples.json`, beside the profile contract,
portable model, and JavaScript evaluator derived from it. The model factory is
`generate_angle_label_model(...)`; `generate_angle_label_javascript(...)`
derives the browser evaluator from those model bytes.

The native tuning lab builds a non-writing calibration plan when its
measurement button is pressed. In the source workspace it hands the complete
candidate to the cross-workspace publisher, which advances MuGeometry and all
static profile consumers as one atomic generation. A package installed without
the adjacent web workspace uses `update_angle_label_calibration(...)` as its
self-contained fallback. Both paths validate and deduplicate the batch,
regenerate every registered profile from the full cloud, validate the complete
successor, and return the active evaluator to the running lab. Exact
resubmission is a verified no-op. Nothing is written to `~/Documents`, and
there is no intermediate export file to copy into a chat. The direct-browser
mode cannot write package data and therefore retains the explicit
JSON-download fallback.

The lower-level release command remains useful for detached review or a
cross-workspace consumer update. Check a downloaded batch without writing:

```bash
mugeometry-angle-observations \
  src/mugeometry/data/angle-label-samples.json \
  /path/to/exported-angle-label-batch.json \
  --check
```

To materialize the reviewed candidate, name a separate output directory:

```bash
mugeometry-angle-observations \
  src/mugeometry/data/angle-label-samples.json \
  /path/to/exported-angle-label-batch.json \
  /tmp/angle-label-release \
  --write
```

The command emits a complete candidate and checksum manifest. The
cross-workspace tool applies that candidate and all independently pinned
consumers as one release after review:

```bash
node shared/angle-label-release-tool.js /tmp/angle-label-release --check
node shared/angle-label-release-tool.js /tmp/angle-label-release --write
```

The compatibility path
`ggprojects/shared/angle-label-samples.json` is a relative symbolic link to the
MuGeometry-owned cloud; it is not another data store.

From the `ggprojects` root, verify that the installed package artifact still
matches the observation cloud:

```bash
mugeometry-angle-model src/mugeometry/data/angle-label-samples.json --check
```

Package maintainers deliberately name the destination when regenerating the
portable model:

```bash
mugeometry-angle-model \
  src/mugeometry/data/angle-label-samples.json \
  src/mugeometry/data/angle-label-model.json \
  --write
```

The same installed command deterministically creates the standalone browser
evaluator from that model. Check the packaged copy, write an explicit
destination, or stream it for a consumer generator:

```bash
mugeometry-angle-model \
  src/mugeometry/data/angle-label-samples.json \
  --artifact javascript --check

mugeometry-angle-model \
  src/mugeometry/data/angle-label-samples.json \
  src/mugeometry/data/angle-label-evaluator.js \
  --artifact javascript --write

mugeometry-angle-model src/mugeometry/data/angle-label-samples.json \
  --artifact javascript --stdout
```

The portable model's integer format version 3 declares every registered
profile, including targets with no direct observations. This lets both
evaluators select provisional inheritance before the first new measurement,
without creating fictitious samples. The JavaScript artifact embeds the same
registry. Its compatibility default remains the authentic
source profile. An explicitly selected target profile applies its own rows only
as a residual over the complete inherited source prediction. The full portable
model additionally retains source history, explicit per-row profile
provenance, and observation timestamps.

The committed conformance fixture is produced by the current JavaScript
helper and checked without a browser or network:

```bash
node tools/angle-label-conformance.js \
  --helper /mnt/data/sync/software/HTML/ggprojects/shared/geometry-angle-layout.js \
  --check
```

The completed parity-gated consumer migration and remaining visual-validation
gates are recorded in
[`../PLAN-PORTABLE-ANGLE-GEOMETRY.md`](../PLAN-PORTABLE-ANGLE-GEOMETRY.md).
