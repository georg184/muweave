# mugeometry

`mugeometry` is the dependency-light shared calibration boundary for generated
geometry in the MuWeave ecosystem. It provides immutable angle-label queries
and results, a machine-readable renderer-profile registry, a deterministic
model artifact, and a Python evaluator numerically matched to the existing
JavaScript calibration. It also computes Hobby interpolating curves as cubic
Bézier segments using only the Python standard library.

The package does not parse MuWeave, define author vocabulary, render HTML or
LaTeX, or run a browser. MuVocab owns `g.angle(...)`; its direct-HTML and
LuaLaTeX/TikZ adapters and `ggprojects` applications call this same
`mugeometry` predictor.

The calibration's source observations were made with MathJax
3.2.2/CommonHTML. PyHTML's MathJax 4.1.3/SVG profile and PyTeX5's declared
LuaHBTeX 1.24.0, PGF/TikZ 3.1.12, Latin Modern Math 1.959 profile are each
registered as provisional reuse of that calibration. Direct MathJax-4 pilot
observations form a separate target-profile correction over the inherited
source prediction; they neither alter MathJax-3 results nor promote any
binding to exact. Callers must opt in to provisional use explicitly:

```python
from mugeometry import (
    PYHTML_MATHJAX_4_SVG_PROFILE_ID,
    resolve_angle_label_calibration,
)

selection = resolve_angle_label_calibration(
    PYHTML_MATHJAX_4_SVG_PROFILE_ID,
    allow_provisional=True,
)
assert selection.compatibility == "provisional"
```

Direct HTML now selects `PYHTML_MATHJAX_4_SVG_INK_PROFILE_ID`
(`muweave-mathjax-4-svg-ink-v1`). PyHTML's matching adapter fixes the physical
glyph size and centres its visible path bounds independently of surrounding
text fonts. This new environment has no direct observations yet; it explicitly
reuses the original MathJax-3 evidence provisionally. The historical
`PYHTML_MATHJAX_4_SVG_PROFILE_ID` remains unchanged, with its own pilot
corrections. Those measurements are not reassigned to the ink-centred profile.
The [browser contract](../pyhtml/docs/CALIBRATED_MATH_LABELS.md) specifies the
adapter and the separately planned tuning-lab migration.

The optional PyHTML native-MathML path instead selects
`PYHTML_NATIVE_MATHML_PROFILE_ID`
(`muweave-native-mathml-lm-1.959-box-v1`). It uses Latin Modern Math 1.959 and
browser-measured formula boxes, not MathJax SVG ink bounds. This profile is
provisional, has no direct observations and explicitly inherits the original
MathJax-3 source evidence. Registering it generates its model/evaluator entry;
it does not relabel old samples or certify identical placement across browser
engines. New native observations and tuning-lab support remain separate work.

The public predictor uses typographic points at its boundary and returns
font-relative geometry. It never treats CSS pixels as physical screen pixels:

```python
from decimal import Decimal

from mugeometry import (
    MATHJAX_3_CHTML_PROFILE_ID,
    AngleLabelIdentity,
    AngleLabelQuery,
    infer_angle_label_class,
    predict_angle_label,
)

label_class = infer_angle_label_class("α", r"\alpha")
prediction = predict_angle_label(
    AngleLabelQuery(
        opening_degrees=Decimal(45),
        base_ray_degrees=Decimal(90),
        label=AngleLabelIdentity("α", r"\alpha", label_class),
        font_size_pt=Decimal(12),
        ray_stroke_width_pt=Decimal(1),
        arc_stroke_width_pt=Decimal("0.75"),
        target_profile_id=MATHJAX_3_CHTML_PROFILE_ID,
    )
)
print(prediction.layout.arc_radius_em)
```

`prediction.layout` and all three placement overrides describe ideal
**thin/reference lines**, as do tuning-lab samples. The complete visible
marker also needs clearance for the rays' and arc's actual widths:

```python
from mugeometry import project_angle_label

marker = project_angle_label(prediction)
# Multiply these by the requested font size in the target's physical units.
print(marker.arc_radius_em)
print(marker.label_x_em, marker.label_y_em)
```

`project_angle_label(prediction)` returns an immutable `AngleLabelProjection`.
Its radius is the visible arc's centre-line radius; its label coordinates are
relative to the vertex, rightward/upward positive. A downward-positive SVG
adapter negates y. The operation applies analytical stroke clearance once,
after overrides, using the actual opening even outside the model's lookup
range. It neither changes the input nor evaluates the model again; a projected
value is not accepted as another projection input. Zero widths recover the
thin geometry. The full projection is checked against the tuning lab's
JavaScript marker, separately from model-only conformance.

The generated JavaScript evaluator also exposes
`GGMuGeometryAngleLabel.projectAngleLabel(query, layout)` and
`ANGLE_LABEL_PROJECTION_VERSION` (currently `1`). The numeric `query` uses
`opening_degrees`, `base_ray_degrees`, `font_size_pt`,
`ray_stroke_width_pt`, and `arc_stroke_width_pt`; the thin `layout` uses
`arc_radius_em`, `label_radius_em`, and `label_angle_offset_degrees`.
The frozen result has `arc_radius_em`, `label_x_em`, and `label_y_em`, with
the same upward-positive, vertex-relative em coordinates as Python. It rejects
invalid inputs and projected values as inputs. No prediction or mutation
happens here; manual overrides are applied before this exactly-once step.
The tuning lab's current HTML profile uses this implementation. Historical
consumers keep their own explicitly pinned rendering profiles.

Direct HTML uses this projection. Historical PDF rendering and its collected
evidence are intentionally unchanged until their measurement-profile audit;
the remaining lab integration and profile validation are tracked in
[PLAN-ANGLE-LABEL-PROJECTION.md](docs/PLAN-ANGLE-LABEL-PROJECTION.md).

The generated model is the only known-label class registry. The public
`infer_angle_label_class(text, math_source=None)` helper accepts either visible
or mathematical spelling and returns `"small"`, `"medium"`, or `"large"`;
unknown labels use the deterministic `"medium"` fallback. Consumers may still
construct `AngleLabelIdentity` with an explicit class when an author override
is required.

## Hobby curves

```python
from mugeometry import hobby_curve

segments = hobby_curve(((0, 1), (1, .5), (3, 1), (4, 2), (5, 3.5), (7, 4)))
midpoint = segments[0].point(.5)
xmin, ymin, xmax, ymax = segments[-1].bounds()
```

`hobby_curve(points, *, tension=1, closed=False, start_curl=1, end_curl=1)`
returns an immutable tuple of `CubicBezier(start, control1, control2, end)`
values. Inputs accept finite `int`, `float`, and `Decimal` coordinates; the
calculation uses binary floats. `point(t)` evaluates one segment for
`0 <= t <= 1`; `bounds()` includes its interior extrema, rather than just its
knots or the larger control-point hull.

Open curves require at least two 2D knots; closed curves at least three.
Adjacent knots must differ, including the closing pair. Use `closed=True`
without repeating the first point. Uniform `tension` must be at least 0.75;
larger values shorten the handles. Nonnegative endpoint curls set the
mock-curvature ratios: 1 is the normal Hobby boundary, 0 gives a locally
straighter endpoint segment. Closed curves have no endpoints and require the
curl arguments to remain at their defaults. Invalid or numerically
unrepresentable geometry raises `TypeError` or `ValueError` before rendering.

The curve interpolates the knots with continuous tangent direction. It need
not be monotone or stay inside their bounding rectangle. No NumPy, SciPy,
PyX, or Gdstk installation is needed. MuVocab's author-facing operation is
[`g.curve`](../muvocab/docs/AUTHORING.md#hobby-interpolating-curves).

## Observation and generation workflow

MuGeometry owns the canonical observation cloud at
`src/mugeometry/data/angle-label-samples.json`, beside the profile contract,
portable model, and JavaScript evaluator derived from it. The model factory is
`generate_angle_label_model(...)`; `generate_angle_label_javascript(...)`
derives the browser evaluator from those model bytes.

The native tuning lab builds a non-writing calibration plan when its
measurement button is pressed. In the source workspace it hands the complete
candidate to the cross-workspace publisher, which advances MuGeometry and all
static profile consumers as one atomic generation. A package installed without
the adjacent web workspace uses `update_angle_label_calibration(...)` as its
self-contained fallback. Both paths validate and deduplicate the batch,
regenerate every registered profile from the full cloud, validate the complete
successor, and return the active evaluator to the running lab. Exact
resubmission is a verified no-op. Nothing is written to `~/Documents`, and
there is no intermediate export file to copy into a chat. The direct-browser
mode cannot write package data and therefore retains the explicit
JSON-download fallback.

The lower-level release command remains useful for detached review or a
cross-workspace consumer update. Check a downloaded batch without writing:

```bash
mugeometry-angle-observations \
  src/mugeometry/data/angle-label-samples.json \
  /path/to/exported-angle-label-batch.json \
  --check
```

To materialize the reviewed candidate, name a separate output directory:

```bash
mugeometry-angle-observations \
  src/mugeometry/data/angle-label-samples.json \
  /path/to/exported-angle-label-batch.json \
  /tmp/angle-label-release \
  --write
```

The command emits a complete candidate and checksum manifest. The
cross-workspace tool applies that candidate and all independently pinned
consumers as one release after review:

```bash
node shared/angle-label-release-tool.js /tmp/angle-label-release --check
node shared/angle-label-release-tool.js /tmp/angle-label-release --write
```

The compatibility path
`ggprojects/shared/angle-label-samples.json` is a relative symbolic link to the
MuGeometry-owned cloud; it is not another data store.

From the `ggprojects` root, verify that the installed package artifact still
matches the observation cloud:

```bash
mugeometry-angle-model src/mugeometry/data/angle-label-samples.json --check
```

Package maintainers deliberately name the destination when regenerating the
portable model:

```bash
mugeometry-angle-model \
  src/mugeometry/data/angle-label-samples.json \
  src/mugeometry/data/angle-label-model.json \
  --write
```

The same installed command deterministically creates the standalone browser
evaluator from that model. Check the packaged copy, write an explicit
destination, or stream it for a consumer generator:

```bash
mugeometry-angle-model \
  src/mugeometry/data/angle-label-samples.json \
  --artifact javascript --check

mugeometry-angle-model \
  src/mugeometry/data/angle-label-samples.json \
  src/mugeometry/data/angle-label-evaluator.js \
  --artifact javascript --write

mugeometry-angle-model src/mugeometry/data/angle-label-samples.json \
  --artifact javascript --stdout
```

The portable model's integer format version 3 declares every registered
profile, including targets with no direct observations. This lets both
evaluators select provisional inheritance before the first new measurement,
without creating fictitious samples. The JavaScript artifact embeds the same
registry. Its compatibility default remains the authentic
source profile. An explicitly selected target profile applies its own rows only
as a residual over the complete inherited source prediction. The full portable
model additionally retains source history, explicit per-row profile
provenance, and observation timestamps.

The committed conformance fixture is produced by the current JavaScript
helper and checked without a browser or network:

```bash
node tools/angle-label-conformance.js \
  --helper /mnt/data/sync/software/HTML/ggprojects/shared/geometry-angle-layout.js \
  --check
```

The completed parity-gated consumer migration and remaining visual-validation
gates are recorded in
[`../PLAN-PORTABLE-ANGLE-GEOMETRY.md`](../PLAN-PORTABLE-ANGLE-GEOMETRY.md).
