# MuWeave

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.

Build tools can opt into `muweave.build_capture.BuildCapture` to retain inputs
read through `muweave.files.read_utf8_text` / `read_input_bytes`. This preserves
physical bytes (including CRLF) and rejects changed declared inputs on `verify()`.
`record_input(path)` declares files passed to another reader; arbitrary Python,
native and network I/O is not intercepted. Producer-owned JSON may be recorded
with `record_build_metadata(kind, data)` into a **private, non-rendered** channel.
Only the calling frontend owns publication, permissions and schema validation.
Outside an explicit capture scope, no inputs or metadata are retained. These
are developer APIs, not new document commands or semantic context state.

MuWeave is a format-neutral Python macro processor for trusted text. Ordinary
text is copied; an active `µ` introduces a Python expression. MuWeave evaluates
each accepted occurrence exactly once, renders the final Python value, and
transitively expands commands returned as generated strings.

```python
import muweave

result = muweave.expand_string("The answer is µexpr(6 * 7).")
assert result == "The answer is 42."
```

The Python import package is `muweave`; its generic text-expansion command is
`muweave-expand`. `python -m muweave` exposes the same low-level processor.
The document-build command `muweave` is supplied by
[MuCompose](../mucompose/README.md). Python 3.13 or newer is required.

> **Security warning:** MuWeave documents and setup scripts execute
> unrestricted Python code with the current user's permissions. Process only
> trusted inputs.

## Scope

MuWeave owns:

- Python-backed `µ` scanning, extraction, parsing, and exactly-once evaluation;
- a persistent context namespace with `expr`, context-bound `eval`/`exec`,
  normal builtins, and one source-ordered state for configuration plus
  vocabulary-owned parameter sections;
- opt-in singular/plural brace commands and command-specific modifiers;
- transitive expansion, `lit` protection, deferred work, and references;
- immediate `SourceScope` controls for temporary namespaced expansion metadata;
- the generic rendering protocol and per-context renderer registry;
- source spans, phase-specific diagnostics, provenance, and source maps,
  including precise syntax locations inside directly embedded Python literals;
- recoverable non-evaluating source analysis, reusable parsed sources, and
  retained parsed-source insertion;
- an explicit typed parsed-source expansion that retains semantic objects for
  optional downstream document layers, including explicitly opted-in nested
  semantic children and content strings, without changing string expansion;
- a strict UTF-8 generic CLI for files and streams.

It does not define LaTeX, MyST, HTML, or another target vocabulary, and it does
not run external document builders. `muvocab` supplies portable author
semantics; `pytex5` and `pymyst` are target frontends.

## Quick use

An ordinary namespace can contain any Python object:

```python
from muweave import MuWeaveContext, expand_string

context = MuWeaveContext({"name": "Ada", "values": [10, 20, 30]})
output = expand_string(
    "Hello, µname. The middle value is µvalues[1].",
    context,
    source_name="example.muweave",
)
assert output == "Hello, Ada. The middle value is 20."
```

Parse once and expand in independent contexts:

```python
from muweave import MuWeaveContext, expand_parsed, parse_string

parsed = parse_string("Value: µvalue", source_name="part.muweave")
first = expand_parsed(parsed, MuWeaveContext({"value": "one"}))
second = expand_parsed(parsed, MuWeaveContext({"value": "two"}))
```

Editor and other read-only tooling can call `analyze_string()` first and pass
the exact valid result to `parse_analysis()` without rescanning or extracting
commands again. See [Reusable parsed source](docs/PARSED_SOURCE.md).

The generic CLI defaults to stdout unless an output is explicit or a frontend
injects a suffix convention:

```console
muweave-expand source.txt
muweave-expand source.txt --output expanded.txt
printf 'Value: µexpr(6 * 7)\n' | muweave-expand -
```

Existing selected output files are atomically replaced. Use `--source-map` for
an adjacent `.muweave-map.json` provenance sidecar.

## Documentation

- [Syntax](docs/SYNTAX.md)
- [Registered text commands](docs/COMMANDS.md)
- [Expansion configuration](docs/CONFIGURATION.md)
- [Dynamic execution](docs/DYNAMIC.md)
- [Deferred computations](docs/DEFERRED.md)
- [References](docs/REFERENCES.md)
- [Rendering](docs/RENDERING.md)
- [Reusable parsed source](docs/PARSED_SOURCE.md)
- [Typed expansion](docs/TYPED_EXPANSION.md)
- [CLI contract](docs/CLI.md)
- [Diagnostics](docs/DIAGNOSTICS.md)
- [Source maps](docs/SOURCE_MAPS.md)
- [Architecture](ARCHITECTURE.md) and [performance](docs/PERFORMANCE.md)

The complete portable author guide begins in
[`muweave-suite/docs/AGENT_AUTHORING.md`](../muweave-suite/docs/AGENT_AUTHORING.md).

## Development

From the workspace root:

```console
python install_ggpackages.py muweave
PYTHONPATH=muweave/src:muweave \
  ./pythonvenv1_dbg/bin/python -m unittest discover \
  -s muweave/tests -p 'test_muweave_*.py' -v
```

Run the deterministic benchmark separately:

```console
PYTHONPATH=muweave/src ./pythonvenv1_dbg/bin/python \
  muweave/benchmarks/benchmark_realistic.py
```

Selected durable conditions are in [REQUIREMENTS.md](REQUIREMENTS.md), and
unresolved design choices are in [OPEN_QUESTIONS.md](OPEN_QUESTIONS.md).
