# PyAI TODO
Audience: developers

## First milestone: complete static author context

Concentrate on the source-derived document, not a model connection or learner
state import. The same static context serves authoring/style assistance and
provides the immutable basis for later learning-coach requests. Input locations
and their authored context belong to this milestone; actual attempts do not.
Contracts: PAI-SEM-01, PAI-FORMAT-01, PAI-ORIGIN-01, PAI-INPUT-01.

### Content completeness — highest priority

- [x] Project response-area children into the reading view: retain given
  diagrams, scaffolds, and enabled model solutions, not only an area caption.
- [x] Include the retained coordinate-system/scene subtree in the reading view:
  axis meanings and units, geometry, labels, and symbolic functions. Omit
  repeated source coordinates and renderer-only sampling, not supplied task data.
- [x] Complete reading metadata for interactive controls and activity inputs,
  including parameter contracts surrounding the retained symbolic geometry.
- [x] Coordinate with MuVocab's AI adapter to preserve explanations attached
  to mathematical subexpressions and distinguish given terms, intentional
  blanks, and model-solution fragments without losing scope in TeX flattening.
  Respect the explicit solution-visibility policy; do not recover prohibited
  answers by reevaluating author source or bypassing nested visibility rules.
- [x] Include whole-equation, equation-cell, and segment explanations in the
  reading projection, with exact subexpression ranges and explicit cell scope.
- [x] Retain resolved reference captions and keys in Markdown, with explicit
  section/block/figure/equation/list-entry/inline anchors and equation-row
  mappings. Include QR URLs, canonical activity URLs, and companion-owner
  relations; cover nested content and exactly-once HTML embedding.
- [x] Complete explicit emphasis, underlining, definition conventions, and
  question-block explanations in Markdown. Protect literal prose and verbatim
  whitespace, including adjacent/nested spans, code in containers, and showcase
  source. Preserve source-order visibility and exactly-once HTML embedding.
- [x] Complete MuVocab's deferred symbol/index collection from retained AI
  occurrences. Preserve hierarchical paths, supplied symbol meanings/groups,
  roles, and linked locations in both semantic views, including early listings
  and nested content. Do not restore omitted private/solution markers.
- [x] Retain explicit foreground scopes and graphic paint colors, even without
  an author-written color reference. Keep text/math scope, exact RGB, and
  separate fill, stroke, label, and approximation roles. Omit non-content theme
  accents rather than guessing whether an explicit color matters; do not
  infer importance or correctness from a hue. Protect nested/source-ordered
  colors, hidden content, canvases, reactive geometry, and shared HTML expansion.
- [x] Audit mathematical alphabet/font distinctions beyond ordinary text
  emphasis. Exact TeX and Unicode notation already survive; regression cases
  now cover alphabets, accents, vectors/points, indices, single-bar lengths,
  matrices, nested fractions, math lists, graphic labels, and authored symbol
  meanings. Outer size changes remain inert and shared HTML expansion stays
  exactly once. No additional notation normalization or inferred types needed.
- [x] Make asset fallback names collision-safe even when another authored file
  already occupies the digest-suffixed candidate.
- [x] Retain the occurrence-local background colors of named educational
  blocks so a model can resolve references such as "the text in the green box".
  Keep the block kind, title, identity, and exact resolved color together in
  canonical and reading views; do not infer semantics from the hue or include
  margins and border dimensions. Regression coverage distinguishes identifying
  main backgrounds from side-tab/border accents and protects nested scope,
  item/part context, disclosure, source-order themes, and shared HTML/AI expansion.

### Declared input opportunities — still author content

- [x] Audit text/graphic responses, local handwriting canvases, interactive
  modules, reactive graphics, editable notebooks, and pedagogical blanks for
  their applicable identity, type, and owner/context relationships. Reuse
  existing qualified response names and interactive instance IDs; do not
  introduce a parallel AI-only numbering system.
  One committed synthetic lesson combines all families, nested items, keyed
  parts, list entries, and document-global fields. Reading and canonical views
  retain their actual names and context. Duplicate notebook sessions now share
  the vocabulary's target-neutral validation; independent input namespaces and
  blanks without standalone persistence IDs remain explicit boundaries.
- [x] Complete static/editable showcase reading with the existing document-local
  `session`, authored source, original result, and bounded nested scope. Protect
  exact code, empty declarations, explanations/colors, item/companion context,
  renumbering, source-order state, hidden/private cells, sidecar independence,
  and exactly-once HTML embedding. Do not import notebook edits or runtime output.
- [x] Keep empty response areas as declarations, never as evidence of a learner's
  missing or incorrect answer. Distinguish immutable scaffold, optional model
  solution, and future learner contribution. A canvas inside a solution does
  not turn its authored solution into learner work.
- [x] Make item/part/appearance and enclosing-section context recoverable by
  containment or references rather than copying whole task statements into
  every input node. Include authored prompts and meaningful axis/coordinate
  semantics, not viewport dimensions, toolbar state, or zoom.
  Finite reading scopes distinguish nested tasks/entries from following global
  fields; source items and keyed parts survive custom occurrence labels.
  Repeated item-local input keys remain explicit errors rather than silently
  acquiring appearance-specific state identities.
- [x] Preserve source-known activity objectives and input intent even without
  a running quiz. Do not invent future randomized questions or copy application
  JavaScript as their description. Missing module-provided semantics are an
  explicit boundary, not a reason to fetch a runtime question during export.

### Compactness and verification

- [x] Separate useful citation identities from repetitive absolute source
  paths and offsets, keeping detailed provenance available to tools without
  requiring it in every model-facing fragment.
  Canonical and reading content keep existing semantic keys; a separate,
  deduplicated `provenance.json` maps export-local JSON Pointers to retained
  ranges and is bound to the exact canonical artifact hash. It is included
  in published/embedded bundles as tool data, not normal model context.
  Regression checks cover nested item/part inputs, missing/generated origins,
  Unicode offsets, unchanged mathematical ranges, disclosure, and exactly-once
  embedding. No persistent identity is derived from source coordinates.
- [x] Remove slider-track visibility, slider display precision, and curve
  rendering sample counts from canonical data; retain mathematical Riemann
  partition counts and sampling rules.
- [x] Omit question centering from canonical AI data and verify that alignment
  changes preserve meaning while changes to the question alter both views.
- [x] Audit remaining presentation fields in current MuVocab projections.
  Typed quantifiers no longer retain their occurrence-local kerns. Physical
  typography, optical fraction/matrix/fence tuning, layout/list arrangement,
  equation-column alignment, axis/angle placement, and response-paper styling
  are inert in both semantic artifacts. Keep axis data/tick/grid increments,
  camera-view semantics, colors, and mathematical notation. Literal authored
  TeX or code about layout remains content, not a target for string filtering.
- [x] Remove reserved text-response line counts from canonical data as well
  as reading output; explicit answer-length instructions remain author content.
- [x] Add semantic completeness tests per node type and nested combination,
  including graph-only tasks and canvas model solutions. Protect reading-view
  coverage when a new semantic kind or attribute is added.
  The reviewed MuVocab corpus/field contract covers current classified values,
  math/graphics families, reader kinds and observed nested attributes. Text and
  scalar-field mutations must affect reading; redundant-field exceptions have
  explicit rationales. New conditional branches still need authored fixtures.
- [x] Add paired tests: presentation-only changes preserve semantic content;
  subject-matter changes appear in both required semantic views. Exclude
  diagnostic provenance from presentation-invariance comparisons.
  Full canonical/reading artifacts are now compared without filtering fields.
  Coverage extends native/module activities and item inputs with nested text
  roles, footnotes, blanks, mathematical fences/quantifiers, equation rows and
  references, text/math lists, columns/wrap, spacing, headings, axes/angles,
  and source-code boundaries. Both standalone and shared HTML builds are covered.
- [x] Retain nested semantic arguments of direct Python layout/list calls.
  `layout.columns(block.theorem(...), ...)`,
  `layout.wrap(..., block.equation(...))`, and flow lists containing an annotated
  semantic entry now use MuWeave's explicitly opted-in typed inputs. Direct
  strings in content fields become retained parsed bodies; annotations delegate
  to the underlying materializer. Registered bodies are not expanded again.
  Regression pairs cover equivalent spellings, nested item/entry/input identity,
  source-order state, omission, and exactly-once HTML/AI evaluation. The direct
  `solution`/`private` namespace bindings no longer expose brace-only controls.
- [x] Verify an unchanged author source/configuration exports identically
  regardless of whether a sibling `.work` exists or contains answers. Test
  item-owned canvas declarations with no runtime and their owner relationships.
- [x] Protect two distinct canvases in one item, unchanged input keys under
  renumbering, hidden answers with retained scaffolds, and exactly-once embedded
  HTML/AI input identities using isolated synthetic item fixtures.
- [x] Cover working/published and solutions-visible/hidden variants; preserve
  source-order configuration and exactly-once HTML/AI expansion.
  A full matrix also crosses private-note settings and direct/brace composition;
  source phases switch settings during expansion. Hidden reserve parents,
  canvas scaffolds, notebook IDs, blank expectations and backend gates have
  positive/negative checks and evaluation traces.
- [x] Use committed small fixtures independent of evolving lesson files;
  supplement them with fresh Kinematik, Vektorgeometrie, and showcase exports.
  The isolated `muvocab/tests/fixtures/ai_inputs` lesson and inert local module
  need no real item library, deployed quiz, learner state, or runtime service.

## Optional normalization and ongoing release checks

- [ ] Consider canonical coalescing of adjacent unannotated prose leaves.
  Adding/removing a transparent `size` wrapper can change text segmentation
  without changing reading content; changing its step already leaves both
  semantic artifacts byte-identical. Any coalescing must retain every source
  origin in the separate map and must not cross mathematical, annotation, or
  verbatim boundaries. This is optional normalization, not missing author
  content. Do not mistake canonical hashes for general semantic equivalence
  or weaken the existing presentation-parameter comparisons.
- [ ] For each semantic format change, update its integer version and remove
  a documented limitation only after regression coverage and export checks
  pass. This is ongoing release work, not an unimplemented export feature;
  test-only changes leave the format versions unchanged.

The later cross-component join with `.work`, visual learner snapshots, and a
learning-coach UI is tracked in [the Suite TODO](../muweave-suite/TODO.md).
No learner-state protocol, timestamp schema, model request, or runtime UI is
part of this first milestone.
