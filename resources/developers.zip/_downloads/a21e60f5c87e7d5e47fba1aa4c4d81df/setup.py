"""Trusted shared setup for the focused executable examples."""

from dataclasses import dataclass
from typing import cast

from muweave import MuWeaveContext
from pytex5 import PytexContext

context: PytexContext = cast(PytexContext, globals()["context"])
core_ref = context.ref


@dataclass(frozen=True, slots=True)
class Person:
    """Store one name for attribute-access examples."""

    name: str


def make_items() -> tuple[str, ...]:
    """Return objects that remain indexable before final rendering.

    Returns:
        Stable tuple of example strings.
    """

    return ("alpha", "beta", "gamma")


@context.commands.command(brace_argument="text")
def emph(text: str) -> str:
    """Wrap one processed body in LaTeX emphasis.

    Args:
        text: Exact recursively processed body.

    Returns:
        LaTeX emphasis source.
    """

    return rf"\emph{{{text}}}"


@context.commands.command(
    brace_argument="text",
    bracket_argument="color",
)
def styled(text: str, *, color: str | None = None) -> str:
    """Wrap one body in a project-defined LaTeX color.

    Args:
        text: Exact recursively processed body.
        color: Exact raw modifier, or ``None`` for plain brace syntax.

    Returns:
        LaTeX color source.
    """

    selected_color = "black" if color is None else color
    return rf"\textcolor{{{selected_color}}}{{{text}}}"


@dataclass(frozen=True, slots=True)
class Badge:
    """Own a direct pytex5 rendering implementation."""

    label: str

    def __pytex__(self, context: PytexContext) -> str:
        """Render this badge through the object-owned protocol.

        Args:
            context: Active document context.

        Returns:
            Boxed LaTeX label.
        """

        return rf"\fbox{{{self.label}}}"


@dataclass(frozen=True, slots=True)
class ForeignLabel:
    """Represent an unmodifiable type adapted by the registry example."""

    latex: str


@context.renderers.renderer(ForeignLabel)
def render_foreign_label(
    value: ForeignLabel,
    context: MuWeaveContext,
) -> str:
    """Render a foreign value without changing its class.

    Args:
        value: Foreign value carrying final LaTeX source.
        context: Active document context.

    Returns:
        Stored final LaTeX source.
    """

    return value.latex


def returns_none() -> None:
    """Return no text for the rendering-policy example."""

    return None


person: Person = Person("Ada")
a: int = 6
b: int = 7
badge: Badge = Badge("Ready")
foreign_label: ForeignLabel = ForeignLabel(r"\underline{adapted}")
