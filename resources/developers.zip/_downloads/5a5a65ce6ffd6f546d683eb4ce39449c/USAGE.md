# PyTeX5 usage reference
Audience: document authors, consumer developers, and AI authoring agents

PyTeX5 is the LaTeX frontend for MuWeave. It turns trusted MuWeave source into
either a LaTeX fragment or a complete LaTeX document, publishes the resulting
source, and can optionally run LuaLaTeX or the experimental lwarp pipeline.
Parsing, Python evaluation, transitive expansion, references, literal
protection, provenance, and source maps remain owned by `muweave`. Portable
author commands such as `section`, `m`, `block.problem`, and `File` remain
owned by `muvocab`.

Trusted print templates can opt into an automatic `name.scan.json` sidecar
with final PDF field geometry. This uses no new author command or CLI switch;
see [scan-template export](SCAN_MANIFEST.md) for setup, validation and limits.

> **Security:** source files, templates, setup scripts, and expressions execute
> unrestricted Python with the current user's permissions. Process only trusted
> inputs.

## Backend context versus MuVocab

`PytexContext()` is the bare LaTeX backend context. It contains MuWeave's core
builtins plus PyTeX5's `verb`, `verb_block`, and legacy `showcase` commands. It
does **not** install MuVocab. When the supplied vocabulary schema already
declares `showcase`, PyTeX5 leaves that name to the vocabulary.

The CLI defaults to `--vocabulary muvocab`. It imports that trusted provider,
asks it for a text-command schema, and creates a fresh MuVocab-configured
`PytexContext`. For the equivalent Python workflow, construct the schema and
context explicitly:

```python
from muweave import parse_string
from muvocab import create_latex_context, create_text_command_schema
from pytex5 import expand_parsed

schema = create_text_command_schema()
body = parse_string(
    'µsection(title="Kinematics")\nThe answer is µm{v = a t}.',
    source_name="chapter.muweave",
    text_command_schema=schema,
)
context = create_latex_context(schema)
latex = expand_parsed(body, context, output_name="chapter.tex")
```

A custom provider selected by `--vocabulary MODULE` must expose compatible
`create_text_command_schema()` and `create_latex_context(...)` operations. The
provider module and every setup script are trusted executable code.

### Bare-context LaTeX author commands

Every `PytexContext` installs three raw-brace commands in addition to their
canonical Python forms:

```text
µverb{one physical source line}
µverb_block{possibly multiline source}
µshowcase{µexpr(6 * 7)}
```

Their signatures are `verb(text)`, `verb_block(text)`, and `showcase(text)`.
`verb` chooses a LaTeX `\verb` delimiter absent from the exact content and
rejects physical line breaks. `verb_block` emits the core `verbatim`
environment and rejects a literal `\end{verbatim}` in its content. `showcase`
emits one protected verbatim source copy followed by a separately expanded
result copy; that result is evaluated exactly once. All three raw brace bodies
retain nested-looking MuWeave source without pre-expanding it.

These bare-context operations are intentionally LaTeX-specific. Portable
`.muweave` source should use MuVocab's `verbatim.inline`, `verbatim.block`, and
semantic `showcase`; the latter replaces PyTeX5's legacy declaration when the
MuVocab schema is installed and provides direct HTML, semantic AI, LaTeX, and
MyST projections.

## Processing modes

### Low-level preprocessing

Low-level mode is the default. The input is treated as the complete output
source, apart from MuWeave expansion. PyTeX5 neither adds a preamble nor runs a
compiler:

```bash
pytex5 fragment.pytex
```

This creates or replaces `fragment.tex`. Low-level mode is useful for existing
LaTeX documents that already contain their own preamble, for generated
fragments, and for pipelines that invoke the compiler separately.

### Complete-document mode

`--document` treats the input as the authorial body and inserts its retained
parse into PyTeX5's complete template:

```bash
pytex5 chapter.pytex --document --title "Kinematics" --author "Ada"
```

The complete ordinary mode publishes `chapter.tex` and builds `chapter.pdf`
with LuaLaTeX by default. Add `--no-pdf` when only LaTeX source is wanted.

When the selected vocabulary provides PyTeX5's structured-document adapter,
complete mode resolves semantic block spacing before LaTeX serialization.
MuVocab's `spacing(...)` and ordered `gap.set(...)`, `.add(...)`, and
`.factor(...)` operations therefore use the same boundary calculation as
direct PyHTML and become explicit `em`-based LaTeX vertical space. Low-level
preprocessing has no enclosing document flow and rejects these structured
operations rather than dropping them.

A display equation on the physical line immediately after prose keeps LaTeX's
native upper display clearance without an additional paragraph gap. A physical
blank line before the equation instead selects the vocabulary's explicit
larger display boundary. This target-specific serialization is derived from
the structured flow; it requires no author option.

The planner suppresses vocabulary defaults at the real beginning and end of a
root or nested flow. Explicit `spacing` values and leading or trailing `gap`
operations remain effective. Complete structured documents use the same
initial typography configuration as direct HTML: `typography.font_size_pt`
(default `10`), `typography.line_height` (`1.35`),
`typography.scale_factor` (`1.25`), `typography.paragraph_gap` (`0.5`), and
`section.line_height` (`1.2`). MuVocab's `µsize[n]{...}` uses signed absolute
finite real steps of that common factor and rounds the shared result to
`0.001 pt`; headings use the common factor too unless the exceptional setting
`section.scale_factor` explicitly overrides headings alone. Normally leave
that override unset. MuVocab additionally accepts
`section.gap_before` and `section.gap_after` for the level-3 clearance bases.
PyTeX5 serializes these values as explicit LaTeX font, baseline, and vertical
space declarations rather than adding class-dependent spacing.

Document mode is also selected by any of these current options:

- `--template`;
- `--body-width-ratio` or `--body-height-ratio`;
- any of `--title`, `--subtitle`, `--author`, `--language`, or `--date`;
- either `--pdf` or `--no-pdf`;
- `--pdf-output`;
- `--groups`;
- positive `--html`;
- `--html-project`.

Vocabulary selection, `--config`, and `--setup` alone do not select document
mode.

### PDF series builds

`--groups=A,B` opts into independent complete-document builds, even without
`--document`. It is inherited from `.mu/pytex5.arguments` or a scoped source
directive. No exam-specific vocabulary import or source evaluation is needed
to select the batch:

```muweave
µ! --config group=A
µ! pytex5 --groups=A,B
```

```console
pytex5 exam.muweave
pytex5 exam.muweave --config group=B
pytex5 exam.muweave --groups=A,B,N2
pytex5 exam.muweave --no-groups --document --output exact.tex
```

The first command creates `exam_A.tex` / `exam_A.pdf` and `exam_B.tex` /
`exam_B.pdf`. An **explicit process-level** `--config group=NAME` selects just
that one group, even if it is not in the inherited list. The shared source
default `group=A` does not narrow a batch. Authors must supply valid content
for each requested group; no missing alternative is replaced implicitly.
Identical A/B tasks are allowed and still produce two separately labelled PDFs.

Names are case-sensitive, ordered, unique and filename-safe: ASCII letters,
digits, `_` and `-`, starting with a letter or digit. Empty names, padding
whitespace and repeated names fail. The reusable validator is owned by MuCLI.
Both `--output` and `--pdf-output` serve as **bases** in batch mode; `_NAME` is
inserted before the final extension. A previously present suffix is not
deduplicated: `--output exam_A.tex --config group=A` yields `exam_A_A.tex`.
Use `--no-groups` for exact paths. This switch can override inherited batches
and does not change the selected `config["group"]`.

Each group runs the ordinary frontend in a new process using the same Python
interpreter. Source maps and compiler intermediates have separate bases.
Inherited configuration is read independently, not forwarded a second time.
`--no-pdf` publishes only the separate complete LaTeX sources. Standard input,
standard output and experimental lwarp are not supported for batches. All
planned input/output/map collisions are checked before starting any group.
A failing group does not suppress later groups or roll back successful
artifacts; the command returns its first nonzero child status (a terminated
child maps to processing failure `1`). Failure to start a child is I/O status `3`.

MuCompose may retain its own batch orchestration. It passes `--no-groups` to
each already selected/suffixed PyTeX5 child, preventing recursive batches when
the source contains defaults for both entry points.

### Combined exam copies

```console
pytex5 exam.muweave --exam-copies 24
pytex5 exam.muweave --exam-copies 3 --exam-seed lesson-9
```

`--exam-copies N` is an explicit invocation option with a positive integer
**total**. It implies complete-document PDF mode. The default cycle is A/B:
3 copies are A, B, A, not 3 copies of each group. An explicit or inherited
`--groups` changes that ordered cycle; an explicit `--config group=N2` repeats
only N2. Without `--exam-copies`, existing plain `--groups=A,B` still produces
the two separate named series described above.

Each copy is expanded and compiled sequentially in a fresh frontend process,
with private temporary LaTeX, PDF, log and source-map paths. The parent does
not evaluate author or setup code. MuPDF's installed `mutool run` reads actual
page counts and `mutool merge` joins the complete copies in order. This reuses
the tool used by measured scan export; no Python PDF-merging library is needed.
The final PDF is named `exam_gesamt.pdf`. `--output custom.tex` chooses
`custom_gesamt.pdf`; `--pdf-output print.pdf` chooses `print_gesamt.pdf`.
These options are bases, not individual-copy destinations. No persistent
combined LaTeX source or source map is produced. The actual PDF, manifest and
source archive live in a fresh `<base>_Druckbestände/<timestamp>_<build-id>/`
directory; the CLI prints that exact path. No loose output is replaced.
Standard input/output,
`--no-pdf` and lwarp mode are invalid for combined copies.

`--exam-seed SEED` supplies a master replay seed in copy mode. Omit it for
fresh entropy, which is reported on stderr and retained in the manifest.
Per-copy seeds depend only on the master seed, one-based copy index and
duplicate-layout retry attempt, so increasing N leaves earlier copies unchanged.
Use each copy's recorded accepted `shuffle_seed` together with its group for
teacher replay. With the same source, dependencies and other configuration,
this gives the same shuffled question/option order as the learner copy. PDF bytes and print
publication IDs intentionally need not be identical. Outside copy mode,
`--exam-seed SEED` directly sets `exam.shuffle_seed` in the selected vocabulary
context, overriding a `--config exam.shuffle_seed=...` assignment. This lets
one copy be replayed from its recorded `shuffle_seed` together with its group.
Seed flags are explicit invocation controls, not inherited source directives.

A fresh teacher batch specified only by the master seed is **not** a promised
answer-key replay if the learner batch needed uniqueness retries. Teacher
outputs without measured scan regions cannot verify those retry decisions;
replay each copy with its retained accepted individual seed instead.

Progress on stderr includes completed/total and group. A failed copy stops the
batch with a clear failure diagnostic; failed compilation, merge, validation
or publication does not publish an incomplete combined PDF. Existing combined
outputs and earlier print packages are preserved on both failure and success.
On success the complete, checked, synchronized **three-file directory** is
published by one rename. Consumers still validate recorded hashes before use.

For scan-enabled multiple-choice exams, the batch fingerprints measured
question/item order and option-key order. Group labels, seeds and fresh print
IDs do not make an otherwise identical arrangement distinct. A duplicate is
recompiled at the same copy index/group with a deterministic replacement seed,
up to 16 attempts per copy. Exhaustion fails explicitly; small question pools
may provide fewer distinct arrangements than requested. Ordinary PDFs and
copies without measured choice regions remain supported, but have no verified
choice-arrangement uniqueness claim.

The durable sibling `exam_gesamt.exam-batch.json` is a versioned
`muweave-exam-batch` manifest. It retains the master seed, source basename/hash,
combined PDF basename/hash, total pages, ordered group cycle and a `copies`
list. Every copy has its index, group, accepted `shuffle_seed`, one-based
`shuffle_attempt`, `choice_fingerprint` (or `null` without measured choices), inclusive one-based
`page_start`/`page_end`, `page_count`, historical `individual_pdf` basename/hash,
and the complete measured `scan_manifest` if that copy enabled scan export
(`null` otherwise). Local page p maps to combined page `page_start + p - 1`.
Copy publication IDs must be unique. Batch format **two** adds a hash-bound
source archive, original exam metadata, per-copy input/generated-LaTeX records
and a separate private `answer_key`. The learner PDF and its embedded scan data
remain free of hidden correct-option IDs. Do not distribute the manifest or
source archive to learners. The [package contract](PRINT_PACKAGES.md) describes
source-capture scope, original-key coverage and legacy compatibility.

Temporary individual PDFs are removed only after the batch JSON is durable.
Their retained hashes describe the historical individual PDFs, **not** the
merged bytes. Their basenames are identifiers, not existing file paths. The
combined artifact is not a standalone ordinary `.scan.json` template: a
consumer must use each embedded manifest's page range and the outer combined
PDF hash, rather than passing an embedded manifest and the merged PDF to the
single-print `validate_scan_manifest` API. Keep this JSON beside the merged PDF
for scan identification and later teacher replay.

### Experimental lwarp mode

Positive `--html` selects PyTeX5's lwarp template, publishes a dedicated
project, and invokes the lwarp HTML pipeline:

```bash
pytex5 chapter.pytex --html
```

For file input, the default project appends `_lwarp` to the input stem:
`chapter.pytex` produces `chapter_lwarp/` with fixed source
`chapter_lwarp/document.tex`. The marker is appended on every derivation, so
`chapter_lwarp.pytex` produces `chapter_lwarp_lwarp/`. Choose an exact project
with `--html-project DIRECTORY`. Standard input requires an explicit project.
`--output` belongs to ordinary one-file mode and is rejected in lwarp mode.

PDF and HTML controls are independent. Because PDF is normally enabled for a
complete PyTeX5 document, use both negative switches for a project-source-only
operation:

```bash
pytex5 chapter.pytex \
    --html-project chapter_lwarp \
    --no-html \
    --no-pdf
```

Useful combinations are:

| Goal | Options |
| --- | --- |
| Complete LaTeX and PDF | `--document` |
| Complete LaTeX only | `--document --no-pdf` |
| lwarp HTML and its default PDF result | `--html` |
| lwarp HTML without publishing the PDF result | `--html --no-pdf` |
| lwarp project source only | `--html-project DIR --no-html --no-pdf` |

lwarp still runs LuaLaTeX internally when producing HTML. `--no-pdf` controls
whether the resulting print PDF is retained as the selected PyTeX5 PDF output;
it does not remove lwarp's own need for TeX.

## Input and output paths

- Every input is strict UTF-8.
- `.pytex` is the recommended LaTeX-only author-source suffix, not a parser
  restriction. Any readable filename is accepted.
- For file input without `-o`, the final suffix is replaced with `.tex`; a
  suffixless name receives `.tex`.
- In ordinary mode, `-o PATH` means exactly `PATH`. PyTeX5 does not modify an
  explicit output spelling. lwarp mode instead uses `--html-project` and
  rejects `--output` because a project has multiple artifacts.
- `-o -` sends file input to standard output. Input `-` reads standard input
  and also defaults to standard output.
- Input and output paths must differ. A source already named `document.tex`
  therefore needs another `-o` path or `-o -`.
- Existing output files are replaced. Publication uses an atomic replacement
  after successful expansion.
- Parent directories for ordinary output are not created automatically.

In ordinary complete-document mode the PDF defaults to the LaTeX source path
with suffix `.pdf`. `--pdf-output PATH` selects an exact `.pdf` destination.
In lwarp mode the primary source is always `PROJECT/document.tex`, so the
default retained PDF is `PROJECT/document.pdf` unless `--pdf-output` is used.

## Complete CLI reference

Run `pytex5 --help` for the installed version. The current processing options
are:

| Option | Meaning |
| --- | --- |
| `INPUT` | UTF-8 file with any suffix, or `-` for standard input |
| `-o PATH`, `--output PATH` | Exact ordinary source output, or `-`; invalid in lwarp mode |
| `--source-map` | Publish `OUTPUT.muweave-map.json`; requires file output |
| `--setup PATH` | Execute trusted UTF-8 Python in the context; repeatable |
| `--debug` | Append complete chained Python tracebacks to diagnostics |
| `--version` | Print the package version |
| `--document` | Select the built-in complete-document template |
| `--template PATH` | Read a trusted custom MuWeave template; implies document mode |
| `--groups A,B[,N,...]` | Build complete PDF series with `_NAME` output suffixes; inheritable |
| `--no-groups` | Disable inherited batching and use exact ordinary output paths; inheritable |
| `--exam-copies N` | Compile N total independent copies and merge them into `_gesamt.pdf`; explicit only |
| `--exam-seed SEED` | Shuffle replay seed, or master seed with `--exam-copies`; explicit only |
| `--body-width-ratio RATIO` | Authorial body width divided by paper width; `(0, 1]`, default `0.76` |
| `--body-height-ratio RATIO` | Authorial body height divided by paper height; `(0, 1]`, default `0.85`; the MuVocab exam style includes the complete header/footer in this frame |
| `--pdf`, `--no-pdf` | Enable or disable PDF generation in document mode |
| `--pdf-output PATH` | Exact `.pdf` destination; incompatible with `--no-pdf` |
| `--html`, `--no-html` | Enable or disable experimental lwarp HTML |
| `--html-project DIRECTORY` | Select an exact dedicated lwarp project directory |
| `--tex-bin DIRECTORY` | Prepend a TeX binary directory to child-process `PATH` only |
| `--title TITLE` | Plain document title |
| `--subtitle SUBTITLE` | Plain document subtitle |
| `--author AUTHOR` | Plain author; repeat to preserve author order |
| `--language TAG` | Hyphen-separated language tag such as `de` or `de-AT` |
| `--date YYYY-MM-DD` | Publication date |
| `--vocabulary MODULE` | Trusted vocabulary provider; default `muvocab` |
| `--config VALUE` | Context setting; repeatable |
| `--items-dir PATH` | Canonical reusable-item directory; defaults from `MUWEAVE_ITEMS_DIR` |
| `--images-dir PATH` | Canonical shared-image directory; defaults from `MUWEAVE_IMAGES_DIR` |
| `--interactive-dir PATH` | Canonical installed `.muweb` module directory; defaults from `MUWEAVE_INTERACTIVE_DIR` |
| `--persons-dir PATH` | Canonical person-library directory; defaults from `MUWEAVE_PERSONS_DIR`. |
| `--publish`, `--no-publish` | Suppress or restore working-only vocabulary presentation; default is working mode |

`--config name` stores `True`, `--config ~name` stores `False`, and
`--config name=value` stores the exact text after `=`. These values initialize
the context's reserved `config` object before setup scripts and document
expansion.

For MuVocab exams, the height ratio includes header height, header separation,
text height, footer baseline separation and footer depth on **every page**.
The text area is what remains after subtracting that page chrome. An optional
`exam.first_page_body_height_ratio` changes the first page's ratio, not this
inclusion rule. Grading/name overlays above the header and private topic notes
do not consume text space. See [exam authoring](../../muvocab/docs/AUTHORING.md#exams-and-occurrence-specific-points).

With MuVocab, working complete documents place `µprivate{...}` notes and
structured-item IDs in the outer margin and add a small `Arbeitsfassung`
marker without consuming body width or height. These working aids therefore
do not change heading positions, inter-block spacing, or body page breaks when
publication removes them. An inline note also preserves ordinary word spacing:
source whitespace on both sides does not become two spaces when the invisible
anchor is present, including consecutive notes after an inline solution heading.
Private notes use the same portable
orange foreground, white background, and orange accent as direct HTML. Item markers
contain only the bare ID, identically for every part.
The status foreground comes from the same initial
`theme.author.note.foreground` setting as the private-note text.
`--config ~author.private` and
`--config ~author.item_ids` hide the respective working aids. For
learner-facing output, `--publish` is the stronger immutable safety switch: it
removes every working marker and skips private brace bodies before nested
evaluation, so source cannot re-enable them with `config.set`.

`--pdf-output` must end in `.pdf`. A PDF build requires file-based LaTeX
source, so standard-output document mode needs `--no-pdf`. `--tex-bin` changes
only engine child processes and does not change the current process environment.

The generic command exits with status `0` for success/help/version, `1` for a
processing or build failure, `2` for invalid usage, `3` for input/output or
UTF-8 failure, and `4` for setup read/compile/runtime failure.

## Layered arguments and source directives

For file input, arguments are applied from lowest to highest precedence:

1. ancestor `.mu/arguments` files, from the shallowest ancestor downwards;
2. matching ancestor `.mu/pytex5.arguments` files in the same order;
3. consecutive `µ!` lines at the beginning of the source;
4. explicit process arguments.

Initial directives may be unqualified or scoped:

```text
µ! --config school=fms
µ! pytex5 --language de-AT
µ! pymyst --language de
```

The first two apply to PyTeX5. A directive scoped to another known frontend is
consumed but ignored. All initial directive lines are omitted from expansion,
while diagnostics and source maps retain their original physical line and
column coordinates.

The inheritable allowlist consists of the shared metadata options,
`--vocabulary`, `--config`, `--items-dir`, `--images-dir`,
`--interactive-dir`, `--persons-dir`, the publication
switch, `--template`, `--body-width-ratio`,
`--body-height-ratio`, `--groups`, `--no-groups`, `--pdf`, `--no-pdf`,
`--html`, and `--no-html`.
Input/output paths, setup scripts, `--document`, build destination paths,
`--tex-bin`, help, and version remain explicit process controls.

### Setup scripts

Each repeatable `--setup PATH` is executed in order after the vocabulary has
created the fresh context and before source expansion. Ordinary definitions
become available to later expressions:

```python
# project.py
school_name = "Example School"
```

```bash
printf 'School: µschool_name\n' | pytex5 - --setup project.py
```

The setup execution namespace also contains `context`, allowing deliberate
command and renderer registration. Reusable project functionality is better
kept in importable Python modules and invoked by a small setup file.

## Templates and metadata

The built-in template uses the A4 `article` class at an explicit 10 pt base
size. It selects Latin Modern Sans for text and Latin Modern Math for formulas,
and loads `graphicx`, `array`, `wrapfig`, `amsmath`, `fontspec`, `unicode-math`,
`esvect`, `caption`, `fontawesome5`, `xcolor`, `tikz`, `tcolorbox`, and
`hyperref`. Structured documents use `zref-savepos` and `zref-abspage` for
working annotations. They retain only position anchors in the text and paint
the notes at page shipout; even an empty margin float could affect layout.
The automatic LuaLaTeX passes resolve these anchors alongside references.
It also loads `geometry` with centered horizontal and vertical scales. The
default body occupies 76% of the A4 paper width and 85% of its height; the two
ratio options can change those dimensions independently.
MuVocab uses `array` and full-width `tabular*` layouts for structured horizontal
content, `wrapfig` for a bounded side object around which paragraphs resume
full width, TikZ for generated coordinate systems, and `tcolorbox` for theorem
presentation. lwarp provides adapters for these packages. When `language` is
supplied it also
loads Babel and imports that hyphenated locale. Paragraph indentation is set to
zero.

MuVocab's named and connecting vectors use `esvect`'s `\vv` notation in the
LaTeX target. A custom template that renders these semantic values must load
`esvect`; the built-in ordinary and lwarp templates select style `a`.
Custom templates that retain working `µprivate{...}` notes, structured-item
IDs, or the working-status marker must call
`µ__pytex5_document__.margin_setup()` in their preamble. It loads the position
packages and defines the shared out-of-flow painter; loading `marginnote`
alone is not sufficient. Publication mode emits none of these markers.

Scan templates can reserve physical margin bands without changing body flow:

```muweave
µ__pytex5_document__.margin_setup(
    exclusion_bands={"left": ((118, 134),), "right": ((146.9, 150.1),)},
    note_gap_mm=1,
)
```

Each pair is a top/bottom Y coordinate in millimetres measured downward from
the physical paper top. Only `left` and `right` are accepted; omitted sides
have no reserved bands. Supply every template-owned mark or QR band that notes
on that side must avoid. Bounds must be finite numbers with `0 <= top < bottom`;
overlapping or unsorted bands are normalized. The gap is a finite nonnegative
number of millimetres.

Enabling bands measures each complete note box at shipout and moves it down
past any overlapping reservation, with the requested gap. Body notes stack
independently on each side and physical page; subsequent notes cannot overwrite
an earlier displaced body note. No boxes enter body flow and body geometry does
not change. If a note cannot fit before the physical page bottom, compilation
fails explicitly instead of clipping it or painting over a reserved region.
`margin_setup()` without exclusions preserves the original unstacked behavior;
an explicit empty mapping enables stacking without reserved bands. Template
authors should derive coordinates from their own mark/QR definitions.

The fixed working-status badge stays at its header-adjacent position rather
than joining the anchored body-note stack. Native template-owned fixed labels
can similarly put `\pytexnotestackfalse` in a local group around a
`\pytexpaintouternote` call. Reserved bands still apply; these fixed labels do
not read or advance the body-note stack. Templates own their fixed-label
placement and should reserve its band too if body notes could reach it.

Shared metadata has this Python contract:

```text
title: str | None = None
subtitle: str | None = None
authors: tuple[str, ...] = ()
language: str | None = None
date: datetime.date | None = None
```

Authors must be nonempty strings without edge whitespace. Language tags contain
alphanumeric subtags separated by `-`. PyTeX5 escapes LaTeX-sensitive
characters in metadata and protects the serialization from MuWeave expansion;
metadata is data, not trusted template source.

A custom `--template` file is trusted MuWeave source. Its supported template
runtime offers these expressions:

```text
µ__pytex5_document__.layout_setup()
µ__pytex5_document__.font_setup()
µ__pytex5_document__.margin_setup()
µ__pytex5_document__.spacing_setup()
µ__pytex5_document__.language_setup()
µ__pytex5_document__.title_setup()
µ__pytex5_document__.title_block()
µ__pytex5_document__.body()
```

`layout_setup()` emits the configured `geometry` declaration. `font_setup()`
selects the same Latin Modern text/math families as the built-in document and
includes its inner-math and native layout-box primitives. Custom templates
using structured columns, isolated drawings or measured equation trimming
need this setup (or an equivalent implementation) as well. A
custom template must itself declare a 10 pt class option if it also wants the
built-in base size. A custom
template must call it to apply `body_width_ratio` and `body_height_ratio`; it
may omit it when it deliberately owns page geometry itself. The lwarp template
additionally uses
`µ__pytex5_document__.lwarp_language_setup()`. `body()` inserts the original
`ParsedSource` at that exact point. Template prefix, body, and suffix therefore
share one context, evaluation order, reference phase, and finalization boundary
without reparsing the body.

`spacing_setup()` suppresses the document class's native outer paragraph,
section, proof, quote, display, and float skips so a vocabulary adapter's single
resolved boundary is authoritative. The quote's internal native paragraph
skip is also zero; semantic paragraph boundaries supply their own spacing.
It retains the original upper and lower
display skips only for a display edge that directly adjoins prose without a
blank line. The built-in ordinary and lwarp templates call it.
It emits nothing when the context has no structured document adapter, so bare
PyTeX5 contexts retain native LaTeX spacing. A custom structured template that
omits it deliberately retains its own native spacing in addition to any
vocabulary gaps.

For a semantic block with a right-hand designation, this setup also defines
`\pytexrightdesignation{inset}{designation}{content}`. `inset` is the existing
unnumbered inset on each side. The designation stays at the right text edge;
the content shares the remaining horizontal space equally on its left and
right. Short prose uses its natural width; longer prose wraps at the ordinary
content width, reduced for a wide designation to keep `.5em` on each side.
`designation` is already
formatted target text, including any parentheses. `content` is typeset once
and remains breakable; the designation appears once on the first fragment.
Native first/last line spacing is preserved. Custom structured templates using
such vocabulary blocks must include this helper or provide an equivalent.

### Exam print template hooks

MuVocab provides two native LaTeX presentation hooks for trusted templates.
Define them before inserting the body; neither introduces a portable command
or a scan manifest:

```latex
\newcommand\muweaveexamnamefield{%
  \fbox{\rule{0pt}{7mm}\hspace{45mm}}}
\tikzset{muweave response canvas frame/.style={color=black,line width=1.2pt}}
```

`\muweaveexamnamefield` replaces the default `Name:` plus underline. Include
your own caption if needed. `block.exam_header` measures the complete box and
uses it in the zero-flow odd-page overlay. Both the horizontal fit with the
grading table and the available vertical top margin remain checked; an
oversized field fails instead of silently overlapping the header. `grading=False`
still suppresses the whole grading/name overlay.

The optional TikZ style overrides only the frame paint of `response.canvas`
when `frame=True`, with or without authored underlay/model solution. It does
not turn an unframed surface into a framed one or change its geometry, padding,
identity or page-breaking policy. Without the style, the existing 0.4pt gray
stroke is unchanged. The canvas clips at its boundary, so only the inward
half of the centred stroke is visible: 1.2pt gives a 0.6pt inward border.
Restrict the style to paint attributes; do not introduce transformations or
extra geometry into this hook.

MuVocab automatically omits solution headings and completion markers for an
`exam_problem` owner, irrespective of `attached`. Keep `block.solution` and
its item-owned `response.canvas` in the source: their semantic relationships
remain available to HTML/AI and future scan geometry. `--config ~solutions`
hides the model content inside the canvas, not the writable canvas itself.

### Table of contents and PDF outline

Complete documents using MuVocab receive a front **Inhaltsverzeichnis** and
matching PDF outline bookmarks by default. Title and page number are both
clickable and use the native heading's destination, also for unnumbered
headings. The list appears after optional document-title metadata and ends
with a page break before the original body. Physical page numbers run through
the contents and body; no page offsets are guessed or counters reset.

```console
pytex5 chapter.muweave --document --config ~toc
pytex5 chapter.muweave --document --config toc.max_level=1
```

The first command omits the list and outline bookmarks without changing
section content or references. The second includes only logical levels 0–1.
The default depth is 2. These are initial publication settings; they also work
in ancestor argument files and backend-qualified initial directives:

```text
µ! pytex5 --config ~toc
µ! pyhtml --config toc
```

Late `config.set(...)` calls do not retroactively alter the navigation shell.
See [MuVocab's authoring guide](../../muvocab/docs/AUTHORING.md#table-of-contents-configuration)
for the shared option contract. Empty documents without headings add no
contents page; low-level preprocessing remains shell-free.

Native `.toc` and bookmark files and forward references are resolved by the
automatic PDF builder. When compiling the generated `.tex` independently,
likewise rerun LuaLaTeX until references stabilize; a long contents list can
need more than two passes. Custom structured templates must provide native
`tableofcontents` and `hyperref`, as the default template does.

### Structured vocabulary-provider boundary

A vocabulary provider may pass a `pytex5.protocol.LatexVocabularyAdapter` to
`PytexContext(document_adapter=...)`. Complete-document mode then retains
semantic values, asks the adapter to prepare one MuDoc tree, resolves vertical
flow through the adapter's `classify_layout()` policy, and delegates each
semantic occurrence to `render_semantic()`. Adapter output uses
`LatexFragment` so generated LaTeX and nested author text keep their MuWeave
provenance. MuVocab installs this adapter in `create_latex_context()`; ordinary
authors do not construct it themselves. The provider protocol stays in the
explicit `pytex5.protocol` module and is intentionally not mirrored by the
small package-root API.

`LatexRenderServices.whole_paragraph` (strict bool, default `False`) is true
only for a sole non-whitespace semantic occurrence in an ordinary closed
paragraph. It is false for mixed prose, certified inline boxes, inline-body
rendering and paragraphs kept open for adjoining content. A provider's font
wrapper can close that paragraph before restoring its font and baseline skip;
it must retain all content and remain breakable. This is layout context, not
an additional expansion, vocabulary lookup, or AI annotation.

`LatexPreparedDocument.navigation` is an immutable tuple of validated
`LatexNavigationEntry(title, level, number, anchor, parent_anchor=None)` values.
Empty navigation omits the front directory. Providers retain native heading
labels, suppress their automatic contents writes locally, and use
`pytex5.navigation.heading_navigation(anchor, entries)` immediately afterward
to write selected entries and bookmarks. This protocol carries already
evaluated text/numbers; the frontend does not import a vocabulary or evaluate
heading source again.
An optional validated `navigation_foreground="#RRGGBB"` on the prepared
document supplies the contents-link color. MuVocab resolves it from the initial
`Theme.link_foreground`, so the frontend does not invent a second content-link
palette. Title and page-number links use that same role.

MuDoc retains blank-line separators and whitespace-only flow edges as exact
source-mapped boundaries. Structured PyTeX5 copies those leaves directly into
the LaTeX body before applying the independently generated portable gap. It
does not infer missing whitespace by scanning the source span of the next
node. Consequently same-line text, one physical newline, a blank line, and a
separator produced by a trusted command remain distinct. Vocabulary renderers
must make control words self-delimiting (for example `\newpage{}`), so lexical
correctness never depends on the following source character.

## Local assets

PyTeX5 owns only target-path handling; a vocabulary command such as MuVocab's
`File(...).image()` decides that an image is required.

- In ordinary direct-LaTeX mode the context returns a correctly serialized
  canonical absolute source path. LuaLaTeX reads the original and embeds it in
  the PDF; no staging copy is needed.
- In lwarp mode the context instead allocates a safe relative path directly
  below `PROJECT/assets/`. PyTeX5 copies every registered source file there
  before replacing `document.tex`.
- Repeated registration of one canonical file is deduplicated. Basename
  collisions receive deterministic suffixes.

The lwarp project publisher replaces its owned source and assets per file and
retains unrelated project files. The whole collection is not one filesystem
transaction.

## Interactive-module print fallback

With MuVocab, `µblock.interactive(...)` never puts executable web application
bytes in LaTeX or PDF. It renders the selected activity as a referenceable
block with a clickable localized title and places a linked vector QR code for
the manifest's canonical HTTPS page in the outer margin:

```text
µblock.interactive(
    "motion",
    instance="kinematics-uniform-motion-1",
    activity="piecewise_uniform",
    height="11cm",
)
```

The artifact is still resolved and validated through `--interactive-dir` or
`MUWEAVE_INTERACTIVE_DIR`; a missing or malformed module is an author error.
`mode="embed"` and `mode="link"` deliberately have the same printable
fallback. Activity changes the linked metadata; compact/full presentation,
HTML-only height, and tab opening do not affect print. Optional
`numbered=True` and references use the common block machinery. See the
[MuVocab interactive-module guide](../../muvocab/docs/INTERACTIVE.md) for the
complete target contract.

## Printable response fields

With the default MuVocab provider, portable worksheet fields also have a
static printable presentation:

```text
µresponse.text("reason", lines=4, label="Begründung")
µresponse.graphic("diagram", height=7, width=12, label="Skizze")

µresponse.canvas[
    name="calculation",
    height="6cm",
    background="squared",
]{
Erwarteter Rechenweg.
}
```

The text field becomes a fixed-height blank box measured in writing lines.
The graphic field becomes a fixed-size blank box measured in centimetres;
omitting its width uses the available line width. Stable names are retained in
the semantic document for validation but do not print. Browser interaction and
student state remain PyHTML responsibilities. An item-owned canvas prints its
paper, optional immutable underlay, and—by default—its model-solution body.
Its height is the greatest of the authored minimum, complete underlay, and
measured solution. `--config ~solutions` still evaluates and measures that
body at its exact source position but does not ship its box, text, links, or
annotations into the PDF. A visible solution uses MuVocab's occurrence-local
`theme.solution.foreground` color, default `#800000`. This setting is
independent of `--publish`.

## Source maps and LuaLaTeX diagnostics

`--source-map` publishes a versioned provenance sidecar named
`OUTPUT.muweave-map.json`. It contains source/output identities, Unicode
coordinates, hashes, and provenance, but not the source or output contents.
Output and sidecar are separately atomic, so consumers must validate the
stored hash. The option cannot target standard output.

The separate diagnostic subcommand reads existing artifacts and never runs
LuaLaTeX or document Python:

```bash
pytex5 diagnose-lualatex worksheet.log
```

Its options are `--tex PATH`, `--source-map PATH`, `--source PATH`, and
`--compiler-directory DIR`. With `worksheet.log`, defaults are
`worksheet.tex`, `worksheet.tex.muweave-map.json`, and the primary source
recorded in the map. Only reliable Web2C `file:line: message` records are
mapped. See [LuaLaTeX diagnostic mapping](LUALATEX_DIAGNOSTICS.md) for its
validation and precision limits.

## Public Python API

The root package deliberately exposes only PyTeX5-owned operations. Import
generic parse, trace, renderer, reference, and source-map types from `muweave`.

### Expansion and documents

```python
expand_fragment(text, context, *, source_name="<string>",
                output_name="<string>", render_value=render_pytex,
                trace=None) -> str

expand_string(text, context=None, *, source_name="<string>",
              output_name="<string>", render_value=render_pytex,
              trace=None, start_offset=0) -> str

expand_parsed(parsed, context=None, *, output_name="<string>",
              render_value=render_pytex, trace=None) -> str

build_document(body, context=None, *, title=None, subtitle=None, authors=(),
               language=None, date=None, body_width_ratio=0.76,
               body_height_ratio=0.85, template=None,
               template_name="<pytex5 default template>",
               output_name="<string>", trace=None) -> str
```

`expand_fragment` is an intermediate operation and requires the same context
to be passed to a later complete `expand_string`. Ordinary callers use
`expand_string` directly. `build_document` requires an unexpanded
`muweave.ParsedSource`, not a plain string.

The LaTeX renderer is public as
`render_pytex(value, context) -> str`. Its precedence is:

1. `None` becomes `""` and `str` passes through unchanged;
2. a renderer registered on the active context;
3. PyTeX5's standard LaTeX reference/target renderers;
4. `value.__pytex__(context)`;
5. MuWeave's generic rendering policy.

An explicit renderer or protocol must return `str`. PyTeX5 performs no
automatic escaping of ordinary command results.

### Direct PDF operation

```python
build_pdf(latex_path, output_path=None, *, executable="lualatex",
          tex_bin=None, passes=None) -> LatexPdfBuild
```

The source must be an existing `.tex` file and the destination an existing
parent plus `.pdf` filename. LuaLaTeX runs from the source directory. All
intermediate files are staged, the PDF signature and final log are validated,
and then the PDF and source-sibling `.log` are replaced. `LatexPdfBuild`
contains `latex_path`, `pdf_path`, `log_path`, combined `stdout`, combined
`stderr`, and `passes`.

With `passes=None` (the default, also used by the CLI), LuaLaTeX runs at least
twice and at most six times until its auxiliary reference/navigation files
stabilize. This covers contents pages that themselves change pagination. If
they still change after six passes, the build fails without replacing the
previous PDF or log. Passing an explicit positive integer preserves an exact
fixed-pass build, deliberately without a convergence guarantee. The returned
`passes` field reports the actual number of completed runs.

### Experimental lwarp module

The isolated `pytex5.lwarp` module exposes the lwarp-specific template,
`publish_project(...)`, `build_html(...)`, and `LwarpHtmlBuild`. These are not
mirrored at the package root. Programmatic asset-aware use must select
`context.assets.use_lwarp_project_paths()` before expansion, build with
`LWARP_DOCUMENT_TEMPLATE`, publish the returned asset mappings, and only then
call `build_html`.

### Diagnostic API

The root exports:

```python
parse_lualatex_log(log_text) -> tuple[LuaLatexDiagnostic, ...]

analyze_lualatex_log(log_text, output_text, source_map, *, source_text=None,
                     output_path=None, working_directory=None)
    -> LuaLatexAnalysis

format_lualatex_analysis(analysis, *, source_text=None,
                         source_name=None) -> str
```

It also exports the immutable diagnostic records and
`LuaLatexMappingError`. MuWeave continues to own the source-map model and
generic downstream mapping errors.

The complete root surface is listed by `pytex5.__all__`; private helpers and
asset implementation classes are not public authoring APIs.

```text
LatexPdfBuild, LuaLatexAnalysis, LuaLatexDiagnostic, LuaLatexMappingError,
MappedLuaLatexDiagnostic, PytexBuildError, PytexContext, __version__,
analyze_lualatex_log, build_document, build_pdf, expand_fragment,
expand_parsed, expand_string, format_lualatex_analysis,
parse_lualatex_log, render_pytex
```

## Common recipes

```bash
# Low-level preprocessing only
pytex5 existing-document.pytex

# Complete source without invoking LuaLaTeX
pytex5 chapter.pytex --document --no-pdf

# Complete source and PDF
pytex5 chapter.pytex --document --title "Mechanics"

# Exact source and PDF destinations
pytex5 chapter.pytex --document -o build/chapter.tex \
    --pdf-output build/handout.pdf

# Experimental lwarp project without any downstream build
pytex5 chapter.pytex --html-project build/chapter_lwarp \
    --no-html --no-pdf
```
