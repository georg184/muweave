# MuWeave LSP protocol

Audience: editor-extension developers and MuWeave maintainers

## Transport and lifecycle

`muweave-lsp` uses standard LSP framing over binary standard input/output.
Each UTF-8 JSON object has a byte-counted `Content-Length` header. The supported
lifecycle methods are:

- `initialize` and `initialized`;
- `shutdown` and `exit`;
- `textDocument/didOpen`;
- `textDocument/didChange` with complete replacement text;
- `textDocument/didClose`;
- harmless receipt of `didSave`, configuration, trace, and cancellation
  notifications needed during normal client operation.

The initialization result advertises:

```json
{
  "positionEncoding": "utf-16",
  "textDocumentSync": {
    "openClose": true,
    "change": 1,
    "save": false
  },
  "documentFormattingProvider": true,
  "documentRangeFormattingProvider": true
}
```

Change kind `1` means full synchronization. A client must send the complete
current document as the unranged `contentChanges[].text` value. Document
versions must increase strictly.

## Positions

Files remain ordinary Unicode text. MuWeave parser spans count Python Unicode
code points. At the LSP boundary, line and character values are zero-based and
the character value counts UTF-16 code units. For example, in:

```text
😀 µexpr(1 + )
```

the emoji occupies two UTF-16 units, while the following space and `µ` occupy
one each. A parser diagnostic on the closing `)` therefore begins at LSP
character 13 although its Python source offset is 12.

CRLF is one logical line ending. Positions on either terminator map to the
preceding visible line end; the offset following LF is line zero of the next
line.

## Live diagnostics

Open and changed documents are passed to `muweave.analyze_string()` with the
complete installed MuVocab `TextCommandSchema`. Every recoverable analysis
diagnostic becomes an LSP error with:

- its exact end-exclusive converted range;
- severity `Error` (`1`);
- code `parse`;
- source `muweave`;
- MuWeave's concise parser message.

A syntactically valid unknown Python name produces no live error because the
namespace is dynamic and the language server never evaluates it. The same
rule applies to a balanced qualified brace or modifier form: name and
form-existence checks belong to semantic expansion, not parser diagnostics.
Likewise, rendering, references, LuaLaTeX, MyST, and external-build failures
are not live parser diagnostics.

Each publication replaces all diagnostics for the URI and carries the analyzed
document version. A newer version or close makes an older analysis stale, even
if that analysis was already running. Close publishes an empty unversioned set.

## Semantic highlighting

The server advertises `textDocument/semanticTokens/full` with the following
stable standard-token legend, in order:

```text
macro, function, method, variable, property, parameter,
keyword, comment, string, number, operator,
muweaveSeparator, muweaveHeading, muweaveStyledText
```

The custom modifiers `muweaveHeadingLevel0` through
`muweaveHeadingLevel3` preserve the portable heading hierarchy at the editor
boundary; the common `muweaveHeading` modifier lets clients add weight without
discarding the original token-specific colors. `muweaveBold` and
`muweaveEmphasis` carry target-neutral typography for author-visible argument
text. `muweavePageBreak` marks only the bare `µnewpage` value so clients can
make physical document boundaries conspicuous. Existing token and modifier
positions in these legends are stable; new entries may only be appended.

The result is projected from `SourceAnalysis`; it does not re-extract command
boundaries. MuWeave markers, text-command targets and delimiters, modifiers,
plural separators, retained Python tokens, post-body trailers, and opaque raw
bodies are classified. Ordinary author prose remains unstyled. Invalid syntax
does not hide valid tokens recovered on later lines.

A balanced qualified text-command candidate is normal structural syntax even
when the installed vocabulary does not know its target or modifier form.
MuWeave's shared analysis retains its marker, qualified target, modifier,
delimiters, potential top-level `,,` separators, bodies, and valid trailers
without producing a diagnostic. Semantic highlighting projects that exact
structure and recursively highlights nested commands. Consequently, a newly
introduced brace command does not collapse visually to a lone `µ` when a
running language server still holds an older vocabulary schema. Unclosed or
otherwise malformed commands continue to use conservative error-range
recovery and remain parser diagnostics.

A bare root name immediately following `µ` is classified as a MuWeave macro so
that value commands such as `µnoin` remain visibly distinct from prose. A root
followed by `(` remains a function; names in arguments, attributes, and methods
retain their normal Python roles. Python keyword names followed by `=` use the
standard `parameter` role, while their values retain their own string, number,
variable, or other Python roles.

A text command's raw `[...]` modifier is first checked syntactically, without
evaluation, as a complete keyword-only Python argument list. If that succeeds,
forms such as `µlayout.wrap[side="right", width=0.45]{...}` receive exactly the
same token roles as `µlayout.wrap(..., side="right", width=0.45)`: `side` and
`width` are parameters, `=` is an operator, and the values keep their ordinary
roles. A free-form command-specific modifier such as `[red]` remains one raw
`parameter` token.

Plural-body `,,` separators use the dedicated `muweaveSeparator` type instead
of the general Python `operator` type. A direct `µsection(...)` call whose
marker is the first non-whitespace content on its physical line is covered by
a heading modifier. An omitted `level` means zero; a literal integer level is
clamped at editor level three, while a dynamic or invalid level expression
uses level three. This inspection reads the validated Python AST and never
evaluates the call or its arguments. Zed's extension styles these tokens as
bold headings while repeating Zed's normal style mapping for each underlying
token type. Current Zed semantic-token styling has no per-token font-size
property, so the emitted level distinction cannot yet change source font size.
The Zed extension renders `muweavePageBreak` in bold red without changing how
other bare value commands are classified.

Expanded bodies of `µbold{...}` and `µemph{...}` use
`muweaveStyledText` with the corresponding typography modifier. Nested bodies
combine both modifiers, while embedded MuWeave markers, targets, delimiters,
and Python syntax keep their normal token roles. The same styling applies to a
direct canonical call such as `µbold("Text")` when its first argument is a
literal Python string. Dynamic Python arguments are not styled because doing
so would require evaluation.

For ordinary Python string literals, only the opening and closing quote
delimiters receive the `string` color. Their content keeps the same prose color
as an expanded brace body, so a long quoted argument does not become one solid
green region. If that content contains a `µ` marker, the server runs MuWeave's
same non-evaluating analyzer over the isolated string body with the installed
text-command schema and highlights any nested command syntax. This nested pass
publishes neither diagnostics nor evaluation results. F-string text is not
reinterpreted as MuWeave source because its braces already belong to Python
interpolation; its quote delimiters and embedded Python expressions are still
highlighted normally. Opaque raw command bodies remain `string` tokens.

Tokens are sorted, non-overlapping, and split into single-line pieces. Lengths
and relative columns count UTF-16 code units. The server currently supplies a
complete result without deltas or a range-token endpoint.

## Prose formatting

The server implements both `textDocument/formatting` and
`textDocument/rangeFormatting`. Both operations use the same non-evaluating
`SourceAnalysis` as diagnostics and semantic tokens.

The formatter is deliberately a prose reflow operation:

- ordinary single line breaks become spaces before wrapping;
- blank lines remain paragraph boundaries;
- a complete inline `µ` command is an indivisible atom and may move only as a
  whole;
- a complete multiline command or a command alone on its physical line remains
  a structural boundary;
- prose inside analyzed brace bodies is formatted independently, including
  either side of a plural `,,` separator;
- Python expressions, raw/protected bodies, and command spelling are never
  rewritten;
- a protected atom longer than the preferred width remains intact rather than
  being split.

Whole-document formatting recursively visits root prose and every analyzed
body of a structural command. Inline commands remain atomic in their
surrounding paragraph instead of becoming multiline blocks. Raw commands such
as `lit`, `comment`, and verbatim forms remain byte-exact. Recovered syntax
errors are retained as structural barriers, so valid independent prose after
an error can still be formatted safely. The server returns one full-document
edit, or no edit when the source is already formatted.

Range formatting returns either one edit whose range exactly equals the
requested nonempty range or no edit. Text outside the selection is never part
of the replacement. A selection intersecting only part of command syntax,
multiple plural bodies, a raw body, or a recovered syntax-error range is
refused.

For example, selecting the complete prose range below retains `µnoin` on its
own line and preserves every inline command exactly while rewrapping the
sentences:

```muweave
µnoin
Die µmetadef{Kinematik} ist ein Teilgebiet der µbold{Mechanik}, welche sich mit
der Beschreibung der Bewegung von Körpern befasst.
```

The preferred width defaults to 100 code-point columns and accepts values from
40 through 240. It can be supplied with the server's `--line-length` option or
overridden during initialization:

```json
{
  "initializationOptions": {
    "formatting": {
      "lineLength": 88
    }
  }
}
```

The standard LSP `FormattingOptions` object is validated but its indentation
options do not change this prose-only formatter. Leading whitespace inside a
brace body is real MuWeave source data and may be significant to a target such
as Markdown/MyST. Whole-document formatting therefore preserves existing edge
whitespace and never inserts cosmetic body indentation.

## Current omissions

The server does not yet advertise hover, completion, document symbols,
navigation, or build commands. Clients should not infer those capabilities
from diagnostics, semantic tokens, or formatting.
