# LuaLaTeX diagnostic mapping
Audience: document authors, consumer developers, and build-tool integrators

pytex5 can translate reliable line locations in an existing LuaLaTeX log back
through a persisted MuWeave expansion map. It does not invoke LuaLaTeX, manage
compiler reruns, or claim that provenance alone proves the cause of a TeX
failure.

## Recommended workflow

```bash
pytex5 worksheet.pytex --source-map
lualatex --file-line-error worksheet.tex
pytex5 diagnose-lualatex worksheet.log
```

The first command creates `worksheet.tex` and
`worksheet.tex.muweave-map.json`. The second is external to pytex5. The third
reads those two artifacts, the log, and the original source path recorded as
source `0` in the map.

The diagnostic subcommand accepts:

```text
pytex5 diagnose-lualatex LOG
    [--tex PATH]
    [--source-map PATH]
    [--source PATH]
    [--compiler-directory DIR]
```

`LOG` with final suffix `.log` defaults to the same path with `.tex`.
The map defaults to `TEX.muweave-map.json`. `--source` overrides the primary
source name stored in the map. `--compiler-directory` is the directory from
which LuaLaTeX interpreted relative filenames in its log; it defaults to the
generated `.tex` parent. Every explicit path is used exactly as written.
Current pytex5 builds store file-backed source and output identities as absolute
normalized paths. Older or programmatic maps may retain relative names; pass
`--source` and `--tex` explicitly when consuming those maps from elsewhere.

The command returns `0` when analysis completes, including when no reliable
main-output location exists. Invalid or mismatched map data returns `1`,
invalid command usage returns `2`, and artifact or report-stream I/O/UTF-8
failures return `3`. A `LOG` spelling such as `.` from which the default `.tex`
path cannot be derived is invalid command usage rather than a runtime traceback.

## Accepted log records

The parser accepts physical lines shaped like:

```text
./worksheet.tex:17: Undefined control sequence.
```

This is the editor-friendly Web2C format enabled by `--file-line-error`.
Filenames may contain spaces or platform path separators. Fatal-summary lines
beginning with `==>` are ignored so they do not duplicate the primary error.
Message continuation text is not needed for mapping and is not interpreted.

Default Web2C output may hard-wrap a logical line after 79 characters without
an explicit continuation marker. A continuation tail can itself resemble
`file:line: message`. pytex5 therefore discards physical runs beginning at
that default width rather than invent a boundary. Configure Web2C's
`max_print_line` high enough to keep explicit diagnostic records on a single
physical line when paths or messages are long. Complete unwrapped lines wider
than 79 characters parse normally.

Classic TeX blocks are not accepted as located diagnostics:

```text
! Undefined control sequence.
l.17 \unknown
```

The `l.17` record has a line but no explicit file. Inferring the active file
would require reconstructing TeX's parenthesized file stack, whose log wrapping
and arbitrary terminal text make false certainty too easy. pytex5 recommends
rerunning with `--file-line-error` instead.

## Validation boundary

`ExpansionSourceMap.from_json` first validates the sidecar schema. Analysis
converts accepted LuaLaTeX records to MuWeave `DownstreamLocation` values and
delegates the entire batch to `map_downstream_locations(...)`. MuWeave then
validates the exact generated `.tex` UTF-8 SHA-256, code-point length, byte
length, and line starts once. When primary source text is supplied—and the CLI
supplies it for ordinary file-backed maps—its corresponding identity is also
validated once. No coordinate is reported after either identity fails.

A diagnostic explicitly naming the generated output but reporting a line
beyond its validated line count makes MuWeave raise a structured
`DownstreamMappingError`. pytex5 translates that into its public
`LuaLatexMappingError` and retains the MuWeave exception as `__cause__`.
Explicit diagnostics for other files are retained as unmatched entries rather
than being forced through the main-output map.

The log itself has no content identity tied to the sidecar. Consequently pytex5
cannot prove that an older log with a still-valid filename and line belongs to
the current compiler run. Build tooling should pass the log produced from the
validated `.tex` artifact in the same run.

## Provenance and precision

LuaLaTeX's file-line record supplies no reliable source column. pytex5 asks
MuWeave to map the normalized line and reports every output segment returned
for that raw line:

- direct source text is clipped exactly to the relevant line interval;
- arbitrary command output points conservatively to the complete command;
- commands parsed from generated output retain inner-to-outer producer chains;
- deferred, reference, and literal phases retain their distinct provenance;
- explicit diagnostics for included files remain separate and unmatched.

Several candidates on one generated line are expected. TeX can also detect an
error after the command that introduced malformed state. MuWeave's
`format_provenance_candidates(...)` therefore labels the reusable candidate
block as possible provenance origins, not proof of cause. pytex5 adds only
LuaLaTeX-specific diagnostic headings, foreign-file wording, and rerun advice.

## Python API

```python
from muweave import ExpansionSourceMap
from pytex5 import analyze_lualatex_log
from pytex5 import format_lualatex_analysis
from pytex5 import parse_lualatex_log

source_map = ExpansionSourceMap.from_json(serialized_map)
diagnostics = parse_lualatex_log(log_text)
analysis = analyze_lualatex_log(
    log_text,
    generated_latex,
    source_map,
    source_text=original_pytex,
    output_path="worksheet.tex",
    working_directory=".",
)
report = format_lualatex_analysis(analysis)
```

For a human report with validated original command excerpts and carets, call:

```python
report = format_lualatex_analysis(
    analysis,
    source_text=original_pytex,
    source_name=source_map.sources[0].name,
)
```

`LuaLatexDiagnostic` stores the explicit filename, generated line, first-line
message, and physical log line; its `location` property exposes only filename
and line as a MuWeave `DownstreamLocation`. `MappedLuaLatexDiagnostic` stores
every clipped or conservative `SourceMapSegment` candidate.
`LuaLatexAnalysis` contains all parsed diagnostics, mapped and unmatched
partitions, and the validated `source_map` used for generic candidate
formatting. All records are immutable.

The ownership boundary is deliberate:

- MuWeave owns content validation, path matching, line validation, clipping,
  candidate ordering, producer-chain formatting, and validated-source excerpts.
- pytex5 owns Web2C parsing, messages and physical log lines, `.log`/`.tex`
  defaults, LuaLaTeX wording, CLI artifact reads, and exit behavior.
