# Shared asset store

Audience: authors, integrators, and package maintainers

PyHTML stores every author-supplied local payload once in the generated HTML.
Visible document elements and the embedded PyAI context refer to the same
content-addressed object. A repeated image therefore does not repeat its
Base64 bytes, and adding the AI context does not add a second copy.

## Identity and deduplication

`HtmlAssetRegistry.register(path)` captures the file on first registration and
returns an `HtmlAssetReference`. Its object ID is
`sha256-<lowercase digest>`. The SHA-256 digest and exact byte size describe
the captured snapshot.

The adapter-facing byte-registration service accepts already validated
immutable bytes plus an explicit MIME type. Interactive integrations use it
for a captured `.muweb` entry document, avoiding a temporary file and retaining
the same byte identity and deduplication rules as path-backed assets.

Identity depends on bytes, not on a source pathname. Consequently:

- repeated uses of one canonical file share its first immutable snapshot;
- two different source files with identical bytes share one stored object;
- MIME type belongs to a use or logical path, not to byte identity;
- no absolute source path is written to the HTML artifact.

The registry accepts arbitrary regular files and falls back to
`application/octet-stream` when no MIME type can be inferred. Individual
vocabulary operations impose their own restrictions. For example, MuVocab's
current `File(...).image()` projection requires an `image/*` MIME type.

## Embedded format

The optional inert element has ID `muweave-asset-store` and format
`muweave-html-asset-store`, currently at integer format version 1. Its JSON has
two collections:

```json
{
  "format": "muweave-html-asset-store",
  "format_version": 1,
  "objects": [
    {
      "id": "sha256-...",
      "sha256": "...",
      "size": 123,
      "encoding": "base64",
      "data": "..."
    }
  ],
  "paths": [
    {
      "path": "assets/diagram.svg",
      "id": "sha256-...",
      "media_type": "image/svg+xml"
    }
  ]
}
```

`objects` owns bytes exactly once. `paths` provides portable semantic aliases,
currently the relative paths used by the embedded PyAI manifest. Visible HTML
uses the same object ID through `data-muweave-asset`, plus an explicit MIME type
and target attribute. An interactive occurrence instead carries the same
object ID in its module metadata; the package-owned host resolves it directly
to a sandboxed frame. This separation permits many visible uses, module
occurrences, and logical paths to share one object.

The PyAI envelope declares `asset_storage: "references"` and maps each AI path
to an `object_id`. Its manifest still carries the path, MIME type, byte size,
and digest needed by an AI consumer; the envelope does not repeat the payload.
An independently published `.ai/` bundle continues to copy its own referenced
files because it is a separate artifact.

## Browser and save behavior

The offline worksheet runtime validates the store shape, decodes each object
once, creates MIME-specific `blob:` URLs, and hydrates the declared target
attributes. Interactive entry documents receive occurrence-specific Blob URLs
that are revoked when their frame or tab host is replaced or disabled. The
content-security policy permits local Blob images, media, and child frames but
still permits no network access.

Blob URLs exist only for the current browser session. **Vollständige
HTML-Kopie** removes those runtime attributes from the cloned DOM before
serialization. The persistent `data-muweave-asset` references and the inert
store remain, so reopening the saved copy hydrates the same bytes again. A
`.work` sidecar contains learner state only and does not duplicate these
authored asset bytes.

Author assets belong to this build-time store. Learner-inserted response
graphics currently remain in the separately versioned worksheet state. No
asset-store extraction or AI-bundle export UI is implemented.

The object/reference split is deliberately independent of the current
single-file Base64 encoding. A later multi-file publisher can map the same
content IDs to side files without changing vocabulary semantics; incompatible
stored interpretations require a new integer store format version.
