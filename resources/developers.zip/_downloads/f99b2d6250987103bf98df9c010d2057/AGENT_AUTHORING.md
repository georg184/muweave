# MuWeave authoring guide for AI agents

Audience: AI agents that write MuWeave sources or automate MuWeave builds

This is the entry point for generating documents with the MuWeave ecosystem.
Read it before writing a `.muweave` source. The companion
[MuVocab authoring reference](../../muvocab/docs/AUTHORING.md) is the canonical, exhaustive
reference for individual author operations and their validation rules. Its
[generated API inventory](../../muvocab/docs/AUTHOR_API.md) supplies the tested
exact names and call shapes. The package-specific links near the end provide
exact CLI and Python API contracts.

MuWeave documents execute unrestricted Python code. Process only trusted
documents and trusted vocabulary or setup modules.

## 1. System model

Keep these roles separate:

| Layer | Owner | Responsibility |
| --- | --- | --- |
| source language | `muweave` | Find `µ` commands, parse Python, evaluate once, expand returned source, resolve references, render final values, and retain provenance |
| optional document model | `mudoc` | Retain typed text and semantic values in immutable backend-neutral nodes and parse blank-line paragraphs for structured frontends |
| editor analysis | `muweave-lsp` | Project the same non-evaluating parser analysis into versioned diagnostics, semantic tokens, and safe document/selection prose formatting; never build or evaluate while typing |
| portable vocabulary | `muvocab` | Define author operations and semantic values, target renderers, and the explicit adapter from those values to MuDoc |
| LaTeX frontend | `pytex5` | Create a LaTeX context, wrap a body in a complete document, publish lwarp assets, and optionally run LuaLaTeX or lwarp |
| MyST frontend | `pymyst` | Create a MyST context, wrap a body or project, publish assets, and optionally run MyST HTML or experimental PDF builds |
| direct HTML frontend | `pyhtml` | Serialize the prepared document directly to a self-contained offline worksheet with local images, conditional MathJax, drawing palette, and vector state; require no external builder |
| semantic AI frontend | `pyai` | Publish concise Markdown plus canonical layout-free JSON and referenced assets; never contact a model or decide tutoring behavior |
| orchestrator | `mucompose` | Invoke selected independent `pytex5`, `pyhtml`, and `pyai` command-line programs with consistent options |
| CLI policy helper | `mucli` | Share metadata/configuration arguments, layered `.mu` settings, and vocabulary loading between document frontends |

An author writes one target-neutral body. A target frontend supplies a fresh
MuVocab context, so the expression

```text
µsection(title="Kinematik")
```

first creates a target-neutral `muvocab.Section`. Only final rendering turns it
into `\section{Kinematik}`, `# Kinematik`, or an HTML heading. Prefer this
semantic path. When content is genuinely target-specific, isolate it with
MuVocab's explicit lazy `backend` source gate rather than adding target checks
to semantic constructors.

The normal flow is:

```text
.muweave source
    -> parse with MuVocab's text-command schema
    -> evaluate in one fresh target context
    -> render semantic values and expand generated source
    -> complete .tex, MyST project, direct .html, or semantic .ai bundle
    -> optional external PDF/HTML builder for the presentation targets
```

`mucompose` deliberately starts separate frontend processes. Their evaluation
state, references, assets, source maps, successes, and failures are independent.
It is not a transaction and does not roll back one successful target when the
other fails.

## 2. First portable document

Save this as `lesson.muweave`:

```text
µsection(title="Kinematik", label="sec:kinematik")

Die Funktion µm{s(t)=\frac12 at^2} beschreibt den Weg.

µblock.problem[label="problem:fall"]{
Berechne den Weg nach µm{t=3\,\mathrm{s}}.
}

Siehe µref("problem:fall").
```

Create both normal targets:

```console
mucompose lesson.muweave --title "Mechanik" --author "Ada Beispiel"
```

The default targets are:

- a complete `lesson.tex` plus `lesson.pdf` through `pytex5`;
- a self-contained interactive `lesson.html` through `pyhtml`.

PyMyST remains an independent frontend, but is currently not a MuCompose
target. Experimental lwarp HTML remains disabled by default. Generate only one
MuCompose target with:

```console
mucompose lesson.muweave --backends latex
mucompose lesson.muweave --backends html
mucompose lesson.muweave --backends ai
```

Invoke `pymyst` directly when its independent output is deliberately required.

Create model input without presentation markup:

```console
pyai lesson.muweave --title "Mechanik" --language de-CH
```

Give `lesson.ai/document.md` to a model first. Add `document.json` when it needs
exact labels, reference targets, equation rows/cells, task-solution ownership,
response IDs, or graphics geometry. Detailed source locations belong to the
separate `provenance.json` tool map, not ordinary model input. Its filenames
may contain local author paths; existing labels and input identities stay in
the content. Do not feed PDF/HTML
layout metadata as a substitute: PyAI deliberately omits margins, fonts, gaps,
page breaks, and other design noise. Explicit content colors and identifying
panel backgrounds remain, so a model can recognize a red curve or green box.
Mathematical notation, emphasis, and tooltip explanations remain content.
The bundle makes no model request and
contains no tutoring policy or provider credentials.

The normal `pyhtml lesson.muweave` and
`mucompose lesson.muweave --backends=html` commands carry matching model
context inside the offline worksheet. PyHTML parses and evaluates the source
once, then projects the resulting immutable typed expansion into visible HTML
and inert semantic JSON. It does not create a separate `.ai/` directory or
contact a model. Learner state remains separate. Use `--no-embed-ai` or
`--no-html-embed-ai` only to omit the semantic payload deliberately.
In this mode `µbackend[include="html"]{...}` contributes to both projections,
whereas `µbackend[include="ai"]{...}` contributes to neither: backend selection
already occurred in the shared HTML expansion. A separate `pyai` target is an
independent process and evaluation. See the [semantic export guide](ai_export.rst)
for the complete comparison and example.

Create the same self-contained interactive worksheet directly when no
orchestration is needed:

```console
pyhtml lesson.muweave --title "Mechanik" --author "Ada Beispiel"
```

The resulting `lesson.html` opens through `file://`. Local authored assets are
stored once in a content-addressed store shared by visible HTML and embedded AI
metadata, a pinned MathJax 4 runtime is embedded only when semantic mathematics
occurs, and the fixed palette can save vector annotations into a new standalone
HTML copy.

The executable examples in [`muvocab/examples/`](../../muvocab/examples/) contain a minimal
document, a larger course fragment, a structured reusable problem, a local
asset-path expansion example, and a parse-once Python example. Read the
[example README](../../muvocab/examples/README.md) before choosing one physical image
format for both external builders.

For example, the complete body in `examples/minimal.muweave` is:

```text
µsection(title="Kinematik", numbered=False)

Die Funktion µm{f(t)=3t^2} beschreibt den Weg.
Das ist µemph{ein portabler MuWeave-Text}.
```

Its complete LaTeX body expansion is:

```latex
\section*{Kinematik}

Die Funktion \(f(t)=3t^2\) beschreibt den Weg.
Das ist \emph{ein portabler MuWeave-Text}.
```

Its complete MyST body expansion is:

```markdown
{.unnumbered}
# Kinematik

Die Funktion $f(t)=3t^2$ beschreibt den Weg.
Das ist *ein portabler MuWeave-Text*.
```

Document mode adds the frontend's trusted complete template around these body
expansions; it does not require an author to write a preamble or project file.

## 3. MuWeave source rules

### 3.1 Active markers and escapes

An active `µ` must touch the following expression or registered text-command
name. Count consecutive backslashes immediately before it:

- an even count leaves `µ` active;
- an odd count makes it literal and consumes exactly the final escaping
  backslash.

Thus `\µname` produces literal `µname`, while `\\µname` retains two
backslashes and evaluates `name`. A lone marker and impossible starts such as
`µ.`, `µ,`, `µ!`, `µ;`, `µ:`, and `µ(` remain literal. There is no
anonymous `µ(...)` form.

### 3.2 Compact Python expressions

The compact form accepts a Python atom followed by any adjacent chain of
attributes, calls, and subscriptions:

```text
µconstant
µperson.name
µmake_items()[5].title.upper()
µmake_items()[1:5]
µfactory()().value[2:7].strip()
```

Calls and subscriptions may contain complete Python expressions, containers,
comprehensions, lambdas, slices, strings, f-strings, and multiline arguments.
Python's tokenizer and parser are authoritative. Extraction is syntactic and
never executes candidates; the accepted expression is evaluated exactly once.

At the outer compact boundary, trailers must be adjacent. `µvalue. Next`
extracts `value`, and `µfactory (note)` extracts `factory`. Sentence punctuation
normally remains text, although `µ1.` is the valid floating literal `1.`.

Use the installed identity callable `expr` for root-level operators,
comparisons, conditional expressions, lambdas, or a parenthesized root:

```text
µexpr(2 * a + b)
µexpr(x if condition else y)
µexpr(a is b)
µexpr([f(x) for x in values if x > limit])[2]
```

`µname` and `µname()` are intentionally different. The former retrieves and
renders an object; the latter calls it first. Any namespace object is usable,
not only a registered command or callable.

### 3.3 Dynamic execution and persistent state

Each context uses one mutable dictionary as Python globals and locals. Source
order is evaluation order:

```text
µexec("answer = 6 * 7")
Die Antwort lautet µanswer.
µeval("answer + 1")
```

`expr(value)` returns an already evaluated value. `eval(source)` evaluates the
contents of a string, bytes object, or code object. `exec(source)` executes
statements and normally renders nothing because it returns `None`. The wrappers
accept only their single positional source argument and always use the current
context namespace.

Inside an `exec` string, nested strings still obey Python quotation rules.
For example, a quoted mathematical label can use
`label="µv.v[interval('t_A', 't_E')]"`. An unescaped inner double quote would
end that label string. Syntax errors in directly embedded, unchanged Python
literals point to the affected document line and may suggest a quotation
conflict. Computed or differently escaped strings retain the call location
and show the failing Python line separately. See the
[dynamic-source diagnostic contract](../../muweave/docs/DYNAMIC.md#error-boundary).


### 3.4 Registered text syntax

Ordinary Python forms need no registration. A `TextCommandSchema` authorizes
only optional text-oriented forms:

```text
µemph{expanded body}
µblock.problem[label="problem:one"]{deferred structured body}
µSet{x \in \mathbb{R},,x^2<2}
```

A singular brace form supplies exactly one string. A plural form supplies no
arguments for an exactly empty body and otherwise splits only at top-level
`,,`. It never trims, dedents, normalizes, coerces, or target-escapes text.
Use the canonical Python call when a plural argument itself contains top-level
`,,`.

The schema also fixes whether each selected body is expanded before the
handler (`expanded`), passed exactly to a semantic handler and evaluated as
retained structure afterward (`deferred`), or kept unparsed and opaque (`raw`).
MuVocab block bodies are deferred; verbatim bodies are raw. Modifier brackets
are command-specific; their contents are ordinary Python keyword source for
MuVocab blocks. There is no global repeated-brace or mixed call/brace grammar.

### 3.5 Recursive expansion and literal protection

Python string arguments are not automatically pre-expanded. A function first
receives the exact string Python evaluated. A normal string returned by a
command is treated as generated MuWeave source and expanded transitively:

```python
def wrapper(text: str) -> str:
    return f"Before {text} after"
```

A vocabulary operation may explicitly declare selected content-bearing string
parameters as typed MuWeave source. MuVocab currently does this for quoted
`length` values, composed `g.axis` labels, and point or vector subscripts
containing an active `µ`, including such subscripts in semantic axis labels and
vector names retained by an `Axis` or `Scene3D`. Those strings remain named
parsed children at the owning occurrence; this is not recursive preprocessing
of arbitrary Python objects or strings.

Use `lit` to protect text through all intermediate expansion passes:

```text
µlit{µemph{shown as source}}
µlit('µemph("also shown as source")')
```

MuWeave stores an opaque context-owned capsule inside an ordinary string.
Concatenation, joining, formatting, and f-string interpolation preserve it.
The complete `expand_string` operation releases the exact payload only after
ordinary expansion, deferred work, and references, and never scans the
released payload again. `expand_fragment` is the staging API that deliberately
leaves capsules protected for a surrounding expansion.

`lit` protects only MuWeave expansion; it does not typeset code. Use
`verbatim.inline` or `verbatim.block` for visible literal source. The namespace
name `empty` is the exact empty string. A physical line containing `µempty`
can also act as a deliberate nonblank trim barrier in a structured block file.

Use the raw brace form `µcomment{...}` to retain source physically while
discarding it from every target. Its body is opaque: nested MuWeave commands
and malformed-looking expressions are neither parsed nor evaluated, although
braces must remain balanced. The canonical `comment(text)` call also returns
the empty string, but evaluates its ordinary Python argument first.

### 3.6 Explicit target source

Use exactly one `include` or `exclude` filter when a source fragment has no
useful portable semantic form:

```text
µbackend[include="html"]{
<span class="special">Direct HTML with µbold{nested MuVocab}.</span>
}

µbackend[exclude="latex"]{
Content for every supported target except LaTeX.
}

µbackend[include=("html", "myst")]{Shared selected source.}
```

The only stable names are `ai`, `html`, `latex`, and `myst`. They name the
expansion target, so lwarp still uses `latex`. A filter is one string or a
nonempty sequence of unique strings. Both modes, neither mode, unknown names,
duplicate names, and non-string entries are errors; do not invent aliases such
as `pyhtml` or `pytex`.

The brace body remains normal parsed MuWeave source. Syntax analysis and editor
highlighting see nested commands even when the runtime target omits it. A
selected body is inserted transparently with its original provenance and
expands normally. An omitted body executes nothing and consequently creates no
labels, references, assets, configuration mutations, or other runtime effects.
The canonical Python spelling is
`µbackend("generated source", include="html")`; its selected string follows
ordinary recursive expansion. Its body argument expression is ordinary Python
and therefore runs before the selector is called even when that target is
excluded. Use the brace form when the body itself must remain unevaluated.

`create_document_context` has no target identity and rejects this operation.
Use a concrete MuVocab target context. Target-only automatically numbered
blocks can make target builds consume different counters, so keep them
unnumbered or provide corresponding target-neutral numbered occurrences when
numbers must match.

### 3.7 Private working source and publication

`µprivate{...}` is parsed normally but selected lazily. In working HTML and
LaTeX it becomes an out-of-flow author-margin note; AI always omits it. With
`--config ~author.private`, or unconditionally with `--publish`, its retained
body is not evaluated at all:

```text
µprivate{
Check the wording and remove this note before publication.
µconfig.set("draft.seen", True)
}
```

The mutation above occurs only in a working presentation that shows the note.
`--publish` is immutable invocation policy and a later source
`µconfig.set("author.private", True)` cannot override it. Use this switch for
learner-facing artifacts. Working output also shows structured item identities
as bare IDs by default; every part of an item displays the same ID without an
`Item` prefix or part suffix. `--config ~author.item_ids` hides only those
visual badges. AI retains item identity as semantic data but never receives
private-note bodies.

Private notes use one semantic orange-on-white palette in HTML and LaTeX. Override
its three portable sRGB roles with `theme.author.note.foreground`,
`theme.author.note.background`, and `theme.author.note.accent`; each accepts a
`Color`, `#RRGGBB`, or supported readable color name.

The direct `private("source")` form evaluates its normal Python argument before
selection. Use the deferred brace form when hidden source must have no effects.

### 3.8 Deferred work and references

`µdefer(lambda: expression)` postpones a computation until ordinary source
expansion has completed. It is intended for results that depend on later
source state. It is not a general retry loop.

MuWeave's core `target(key, value)` and `ref(key)` support forward references;
`external_ref(key)` deliberately skips local-target validation. MuVocab's
author-facing `ref` adds portable display choices and should be preferred for
sections, blocks, equations, figures, and companions. Duplicate local targets
and unresolved local references are errors.

### 3.9 Rendering

MuWeave completes all Python operations before rendering the final value. Its
general order is:

1. `None` becomes `""`;
2. `str` is used unchanged;
3. the nearest explicitly registered renderer is used;
4. `__muweave__(context)` is used;
5. an unhandled declared `SemanticValue` is an error;
6. any other value falls back to `str(value)`.

Explicit renderers and protocols must return `str`. PyTeX5 adds its native
reference handling and `__pytex__(context)` protocol before the general
fallback. No layer automatically escapes ordinary LaTeX or MyST text.

## 4. Installed author namespace

All default MuVocab target contexts expose these author names. Core names are
installed by MuWeave; all others are supplied or configured by MuVocab.
Prefer portable semantic operations; the table explicitly identifies the one
target-source gate and other target restrictions.
PyTeX5 additionally installs three target-specific source-presentation
commands described after the portable signatures below.

The [generated author API inventory](../../muvocab/docs/AUTHOR_API.md) is the
mechanically complete and tested ledger for exact names, signatures, target
availability, composable result operations, and registered brace forms. The
table and examples here explain intent and common use; they may abbreviate
shared keyword arguments and must not be used to infer an omitted default.

| Name | Canonical use | Text convenience | Purpose |
| --- | --- | --- | --- |
| `expr` | `expr(value)` | none | delimit a general Python expression |
| `eval` | `eval(source)` | none | dynamically evaluate source in the persistent namespace |
| `exec` | `exec(source)` | none | dynamically execute statements |
| `config` | `config.set(name, value)` | none | mutate expansion configuration in source order |
| `defer` | `defer(lambda: value)` | none | postpone computation |
| `target` | `target(key, value)` | none | register a generic local target |
| `external_ref` | `external_ref(key)` | none | emit an unvalidated external reference |
| `comment` | `comment(text)` | `µcomment{raw}` | discard retained source without parsing or evaluating the raw body |
| `lit` | `lit(text)` | `µlit{raw}` | protect MuWeave source until final release |
| `empty` | bare `µempty` | none | emit the exact empty string |
| `backend` | `backend(body, include=...)` or `backend(body, exclude=...)` | `µbackend[include=...]{deferred body}` or `exclude=...` | lazily select source for `ai`, `html`, `latex`, or `myst`; unavailable in a target-neutral document context |
| `group` | `group(*alternatives, groups=None, **named)` | `µgroup{A body,,B body,,N body,,N2 body}` or `µgroup[groups=(...)]{...,,...}` | select `config["group"]`; only the selected brace branch executes |
| `private` | `private(body)` | `µprivate{deferred body}` | working-only author note; AI and publication skip the body before nested evaluation |
| `Color` | `Color(...)`, `.from_hex(...)`, or `.from_name(...)` | none | immutable opaque sRGB color |
| `Theme` | `Theme(theorem_background=..., link_foreground=..., ...)` | none | semantic document color palette |
| `color` | `color(value, COLOR)` | `µcolor[COLOR]{deferred body}` | exact portable foreground annotation |
| `section` | `section(title=..., level=0, numbered=True, label=None, counter=None, center=False)` | none | logical heading at level 0 through 5; optional positive counter override |
| `ref` | `ref(target, display="auto", text=None, kind_name=None, link=True, preview=False)` | none | portable reference with optional local kind name; direct HTML can preview equations |
| `tooltip` | `tooltip(value, description)` | `µtooltip[description]{deferred body}` | portable plain-text explanation over visible content |
| `spacing` | `spacing(value, before=None, after=None)` | none | replace a block's external spacing request |
| `gap` | `.set(value, unit="body")`, `.add(value, unit="body")`, `.factor(value)` | none | transform one vertical block boundary; `unit="cm"` is physical and methods chain in order |
| `m` | `m(text)` | `µm{expanded}` | inline TeX-style mathematics |
| `allowbreak` | bare value | none | optional safe line-break boundary inside `µm{...}` |
| `forall`, `exists` | bare value or `forall(space=...)` / `exists(space=...)` | none | logical quantifier with a following mathematical space; default `"thin"` equals 3 mu / LaTeX `\,` |
| `qty` | `qty(value, unit_value, per_mode=None)` | `µqty{value,,unit}` | magnitude with an atomic semantic physical unit |
| `unit` | `unit(value, per_mode=None)` | `µunit{unit}` | standalone semantic physical unit |
| `units` | Python attributes and algebra | none | validated unit namespace such as `units.kg * units.m / units.s**2` |
| `Term` | `Term(value)` | none | stable symbolic scalar with arithmetic, substitution, and explicit decimal evaluation |
| `Matrix` | `Matrix(rows)` | none | nonempty rectangular symbolic matrix |
| `p` | `p(*coordinates)` or symbolic attributes | plural brace | affine coordinate point or named point such as `p.A[1]` |
| `v` | `v(*coordinates)` or symbolic attributes | plural brace | coordinate column vector, named vector/component, or connecting vector |
| `length` | `length(value)` | `µlength{expanded mathematics}` | visible vector length with single vertical bars; never shadows Python `len` |
| `ol` | `ol(value)` | `µol{expanded mathematics}` | fixed mathematical overline over a string or mathematical object, not a length |
| `para`, `equi` | bare value; optionally `para[-sp]` / `equi[-sp]` | none | parallelism / equivalence with occurrence-local automatic spacing control |
| `d` | bare `µd` or Python value `d` | none | upright mathematical differential symbol, as in `µfrac{µd x,,µd t}` |
| `sp` | bare value or `sp(factor=1)` | none | thin math space, or a finite signed multiple; `-sp` is the separate relation modifier |
| `fence` | `fence(*parts, left="(", right=")", middle="|", ...)` | plural brace | mathematical delimiters |
| `Set` | `Set(*parts, ...)` | plural brace | set or set-builder notation |
| `interval` | `interval(start, end, *, o=False, lo=False, ro=False)` | plural brace with optional `o`, `lo`, or `ro` bracket modifier | complete inline-math closed, open, or half-open interval |
| `emph` | `emph(text)` | `µemph{expanded}` | semantic emphasis |
| `bold` | `bold(text)` | `µbold{expanded}` | bold inline font weight |
| `size` | `size(text, step=0)` | `µsize[STEP]{expanded}` | absolute signed document font-size step |
| `ab` | `ab(text, periods="final")` | `µab{expanded}` | controlled abbreviation periods and following-space semantics |
| `resp` | bare value | none | current German respectively abbreviation `bzw.` |
| `footnote` | `footnote(text)` | `µfootnote{deferred body}` | portable inline note |
| `person` | `person(key, *, text=None, footnote=False)` or `person.Newton` | none | canonical person mention, HTML information card and optional PDF biography footnote |
| `uline` | `uline(text)` | `µuline{expanded}` | underlined inline content |
| `solution` | `solution(body, hidden="omit")` | `µsolution[hidden="omit"|"reserve"]{deferred body}` | conditional model solution controlled by strict source-ordered `solutions` configuration |
| `blank` | `blank(text, underline=False, padding=0, padding_left=None, padding_right=None)` | `µblank[u, padding=1]{expanded}` or `µblank[-u]{expanded}` | inline reserve-style solution with optional rule and padding |
| `phantom` | `phantom(text)` | `µphantom{expanded}` | invisible layout box omitted from semantic AI output |
| `metadef` | `metadef(text)` | `µmetadef{expanded}` | bold metalinguistic definition term |
| `zfcdef` | `zfcdef(text)` | `µzfcdef{expanded}` | bold ZFC definition term with a subtle red tint |
| `lists` | `.enumerated(*entries, ...)` | plural brace/modifier form | ordered semantic sequence with vertical or grid presentation and owner-derived entry targets |
| `layout` | `.rows(*parts, gap=0, trim=True)`, `.columns(*parts, ...)`, `.wrap(body, aside, ...)`, `.trim(value, ...)` | brace/modifier forms for columns/wrap | vertical rows, horizontal partition, flowing side object, or certified automatic edge trimming |
| `qrcode` | `qrcode(url, anchor=None, size="1.5cm", placement="margin")` | none | clickable QR-coded HTTP(S) link in the margin by default; optional concise link anchor |
| `block.interactive` | `block.interactive(module_id, *, instance, activity=None, presentation=None, mode="embed", open="inline", height=None, title=None, numbered=False, tag=None)` | none | sole external MuWeb-application API; referenceable block with independent activity and compact/full presentation selection |
| `ui` | `.slider(...)`, `.select(...)`, `.output(expression, ...)` | none | portable controls and read-only computed displays in a shared reactive scope |
| `g` | `.interactive(id=..., **sliders)`, `.axis_layout(...)`, `.axis(...)`, `.line(...)`, `.arc(...)`, `.point(...)`, `.camera.*(...)`, `.scene3d(...)` | none | retained 2D/3D graphics; circular arcs use signed degree sweeps, while reusable layouts share data scales and local anchors |
| `response` | `.text(name, ...)`, `.graphic(name, ...)`, `.canvas(name, ...)` | deferred `µresponse.canvas[...]{...}` only for canvas solutions | stable worksheet responses, including item-owned local handwriting surfaces and an optional model-solution layer |
| `newpage` | bare `µnewpage` | none | start following block content on a new PyTeX5 page; direct HTML omits the marker transparently |
| `noin` | bare `µnoin` | none | suppress a LaTeX paragraph indent; empty in MyST |
| `qedsymbol` | bare `µqedsymbol` | none | portable Yin–Yang completion marker |
| `block` | methods below | deferred brace/modifier forms | semantic block namespace |
| `block.quote` | `block.quote(body="", *, file=None, item=None, trim=None, title=None, label=None, numbered=None, tag=None)` | `µblock.quote[...]{...}` | indented quotation; compose boldness separately inside its body |
| `block.applet` | `block.applet(body="", description=None, *, file=None, item=None, url=None, trim=None, title=None, label=None, numbered=None, tag=None)` | `µblock.applet[...]{body,,description}` | full HTML applet, print description with a clickable margin QR and no additional text link, both bodies in AI |
| `File` | `File(path)` | none | resolve, insert, or represent a local file |
| `figure` | `figure(image, caption=None, label=None, width=None, align="center")` | none | single-image figure |
| `verbatim` | `.inline(text)`, `.block(text)` | raw brace forms | literal visual presentation |
| `showcase` | `showcase(source, editable=False, session=None)` | deferred brace form with `editable=` and `session=` options | exactly-once source/result example; optional native notebook intent |
| `index` | `.term`, `.mark`, `.path`, `.pair`, `.part`, `.show` | none | selected-location keyword index |
| `symbols` | `.define`, `.term`, `.mark`, `.show` | none | selected-location symbol directory |

### Common portable author call shapes

The generated inventory linked above supplies the exact current signatures.
The following compact forms are an orientation aid and intentionally omit
annotations and, in a few long families, less commonly changed keywords.

The context-installed core controls and MuVocab's target selector are:

```python
expr(value)
eval(source, /)
exec(source, /)
config.set(name, value, /)
config.set(**settings)
config.set(name, value, /, **settings)
defer(thunk, /)
target(key, value=None, /)
external_ref(key, /, *, request=None)
lit(text, /)
backend(body, *, include=None, exclude=None)  # exactly one filter is required
```

`empty`, `noin`, `qedsymbol`, and `resp` are values used bare, not callables.
The portable constructors are:

```python
section(*, title, level=0, numbered=True, label=None, counter=None, center=False)
ref(target, *, display="auto", text=None, kind_name=None, link=True, preview=False)
tooltip(value, description)
color(value, foreground)
spacing(value, *, before=None, after=None)
gap.set(value, unit=None).add(value, unit=None).factor(value)
m(text)
allowbreak  # bare value; valid only inside µm{...}
qty(value, unit_value, *, per_mode=None)
unit(value, *, per_mode=None)
units.m
units.kg * units.m / units.s**2
emph(text)
bold(text)
ab(text, *, periods="final")
footnote(text)
person(key, *, text=None, footnote=False)
person.Newton(text=None, footnote=False)  # explicit configured catalogue alias
block.person(person.Newton, *, title=None, label=None, numbered=None, tag=None)
uline(text)
solution(body, *, hidden="omit")
blank(text, *, underline=False, padding=0, padding_left=None, padding_right=None)
phantom(text)
metadef(text)
zfcdef(text)
lists.enumerated(
    *entries,
    layout="vertical",
    columns=None,
    content="flow",
    keys=None,
    style="lower-alpha",
    start=1,
    prefix="",
    suffix=")",
    trim=True,
)
layout.columns(
    *parts,
    widths=None,
    valign="top",
    halign="natural",
    gap=0.02,
    trim=True,
    names=None,
    height_from=None,
)
layout.wrap(
    body,
    aside,
    *,
    side="right",
    width=0.4,
    gap=0.02,
    halign="natural",
    trim=True,
)
qrcode(
    url,
    anchor=None,
    *,
    size="1.5cm",
    placement="margin",
)
g.axis(
    xmin,
    xmax,
    ymin,
    ymax,
    *,
    x="x",
    y="y",
    xstep=1,
    ystep=1,
    xgridstep=None,
    ygridstep=None,
    grid=False,
    width=None,
    height=None,
    aspect="free",
    axes="both",
    ticks=True,
    numbers=True,
    align="center",
    scale=1,
)
math_label(text, *, latex=None, label_class=None)
g.angle(
    vertex,
    first,
    second,
    label,
    *,
    mode="minor",
    color="black",
    arc_radius=None,
    label_percent=None,
    label_angle_offset=None,
    font_size=None,
    ray_stroke_width=1.2,
    arc_stroke_width=1,
)
g.scale(factor)
g.reset()
g.line(
    start,
    end,
    *,
    color="black",
    stroke_width=1.2,
    cap="round",
    name=None,
    label_at=0.5,
    label_side="left",
    label_offset=4,
)
g.arc(
    center,
    radius,
    *,
    start_angle=0,
    sweep=90,
    color="black",
    stroke_width=1.2,
    cap="round",
    name=None,
    label_at=0.5,
    label_side="left",
    label_offset=4,
)
g.arrow(
    start,
    end,
    *,
    color="black",
    stroke_width=1.2,
    cap="round",
    head_length=7,
    head_width=5,
)
g.vector(
    vector,
    *,
    start=None,
    name=None,
    color="black",
    stroke_width=1.2,
    cap="round",
    head_length=7,
    head_width=5,
    label_at=0.5,
    label_side="left",
    label_offset=4,
    label_min_length=0,
    when=None,
)
g.point(position, *, color="black", radius=1,
        label=None, label_angle=45, label_radius=8, draggable=False, when=None)
g.curve(
    *points,
    tension=1,
    closed=False,
    start_curl=1,
    end_curl=1,
    color="black",
    stroke_width=1.2,
    cap="round",
)
g.plot(
    expression,
    *,
    variable="x",
    xmin,
    xmax,
    samples=160,
    color="black",
    stroke_width=1.2,
    cap="round",
)
g.riemann_sum(
    expression,
    *,
    variable="x",
    xmin,
    xmax,
    partitions,
    sample="midpoint",
    baseline=0,
    fill="lightblue",
    fill_opacity=0.45,
    stroke="steelblue",
    stroke_width=0.7,
    approximation_color=None,
    approximation_stroke_width=2,
)
axis.add(*elements)
fence(
    *parts,
    left="(",
    right=")",
    middle="|",
    size="auto",
    min_size=None,
    size_factor=1.0,
)
Set(*parts, size="auto", min_size=None, size_factor=1.0)
Term(value)
Matrix(rows)
p(*coordinates)
v(*coordinates)
p.symbol(name)
v.symbol(name)
v.from_to(start, end)
figure(
    image,
    *,
    caption=None,
    label=None,
    width=None,
    align="center",
)
response.text(name, *, lines=4, label=None, frame=True)
response.graphic(name, *, height=7, width=None, label=None)
response.canvas(
    name,
    *,
    height=7,
    width=None,
    background="blank",
    underlay=None,
    label=None,
    frame=True,
    solution=None,
)
```

`qty` keeps magnitude and unit atomic and separates them with a fixed,
nonbreaking `1.5mu` mathematical kern, half the standard `\,` thin space.

`solution` is conditional pedagogical content, distinct from the separately
placeable companion `block.solution`. Its strict boolean configuration is
`solutions`, defaults to true, changes in source order, and is independent of
`--publish`. Use `--config ~solutions` for a learner artifact without model
solutions. `µconfig.set("solutions", False)` may change later occurrences.

The registered `µsolution{...}` form is deferred. With solutions disabled,
the default `hidden="omit"` rejects its body before nested evaluation, so the
body creates no errors, state changes, counters, references, or assets.
`µsolution[hidden="reserve"]{...}` evaluates the body at that exact source
position and preserves its rendered dimensions, but paints no content and
ships no PDF links or annotations. Prefer the brace form when omission must be
inert: Python evaluates the argument to `solution(expression)` first. Generic
AI output includes a solution only while `solutions` is true.

Visible model solutions use the occurrence-local semantic
`theme.solution.foreground` color, default `#800000`. The role covers ordinary
inline and block `µsolution`, mathematical solution segments, and a local
canvas's model-solution layer. PyAI omits this presentation-only color.

The same operation composes inside `µm{...}` and
`µblock.equation{...}` when its body contains mathematics only, for example
`µblock.equation{a=µsolution[hidden="reserve"]{b}}`. Disabled direct HTML
retains that mathematical width through a MathJax phantom; semantic AI omits
the conditional segment.

`blank` is the inline reserve presentation of a solution, whereas `phantom` is
layout only. With solutions enabled, `blank` paints its expected content; with
solutions disabled, it retains the complete hidden box and optional rule. Only
the visible expected content uses `theme.solution.foreground`; padding and the
optional rule keep the surrounding text color. Use
`µblank[u]{expected}` for an underlined learner response slot and
`µblank[-u]{expected}` when the default absence of a rule should be explicit.
The modifier may continue with keyword options, for example
`µblank[u, padding=1]{expected}`. A unitless padding value must be a
nonnegative integer count of real interword spaces per side; `padding=1`
therefore contributes one space on the left and one on the right. Strings such
as `"0.4em"`, `"0.4body"`, and `"0.2cm"` use the shared length parser.
`padding_left` and `padding_right` override the symmetric value independently.
Negative values and unitless floats are invalid.

Blank and phantom brace bodies expand nested commands. Direct HTML and LaTeX
support them in ordinary prose and in mathematics, including
`µblank[u, padding=1]{µv.x (t_E) - µv.x (t_A)}`. Semantic AI always retains a
blank's expected answer but removes its rule and padding; `phantom` disappears
as layout noise. Reserved HTML is inspectable and is not secret. The legacy
MyST projection supports blank and phantom in prose only; raw inline HTML is
not valid inside MyST math.

The context-bound file factory and its methods are:

```python
File(path)
File(path).resolve()
File(path).insert(*, lit=False, level_offset=0)
File(path).image(*, alt="", width=None)
```

The portable literal and directory namespaces are:

```python
verbatim.inline(text)
verbatim.block(text)

index.part(text, *, sort_key=None)
index.path(*parts)
index.pair(first, second)
index.term(text, *, paths, role="definition")
index.mark(paths, *, role="definition")
index.show(*, title="Index", level=0)

symbols.define(
    key,
    *,
    notation,
    description,
    sort_key=None,
    group=None,
)
symbols.term(
    target,
    *,
    role="definition",
    notation=None,
    description=None,
    sort_key=None,
    group=None,
)
symbols.mark(
    target,
    *,
    role="definition",
    notation=None,
    description=None,
    sort_key=None,
    group=None,
)
symbols.show(*, title="Symbols", level=0)
```

`block` provides:

```python
block.text(body="", *, file=None, trim=None, title=None, label=None,
           numbered=None, tag=None)
block.quote(body="", *, file=None, item=None, trim=None, title=None, label=None,
            numbered=None, tag=None)
block.applet(body="", description=None, *, file=None, item=None, url=None,
             trim=None, title=None, label=None, numbered=None, tag=None)
block.equation(body="", *, rows=None, row_gap=None, columns=None, numbering="system",
               file=None, item=None, trim=None, title=None, label=None, numbered=None,
               tag=None)
block.equation.row(*cells, numbered=None, label=None, tag=None)
block.theorem(body="", *, file=None, trim=None, title=None, label=None,
              numbered=None, tag=None)
block.definition(body="", *, file=None, trim=None, title=None, label=None,
                 numbered=None, tag=None)
block.remark(body="", *, file=None, trim=None, title=None, label=None,
             numbered=None, tag=None)
block.attention(body="", *, file=None, item=None, trim=None, title=None,
                label=None, numbered=None, tag=None)
block.proof(body="", *, file=None, trim=None, title=None, label=None,
            numbered=None, tag=None)
block.problem(body="", *, file=None, trim=None, title=None, label=None,
              numbered=None, tag=None)
block.exercise(body="", *, file=None, trim=None, title=None, label=None,
               numbered=None, tag=None)
block.sample_problem(body="", *, file=None, trim=None, title=None, label=None,
                     numbered=None, tag=None)
block.solution(body="", *, owner=None, file=None, key=None, trim=None,
               label=None, attached=False)
block.from_file(path, *, part=None, key=None, trim=None, title=None,
                label=None, numbered=None, tag=None)
problems_and_solutions(*items, level=1)
```

`block.source(default_kind=None, trim=True)` and
`block.part(kind, key=None)` are static full-line declarations used only inside
structured reusable `.muweave` files. All exact semantics, configuration keys,
target output, validation rules, and examples are in
[AUTHORING.md](../../muvocab/docs/AUTHORING.md). Consult its relevant section before generating a
less familiar operation.

MuVocab also provides the portable `showcase(source)` operation and deferred
raw-looking brace form. It displays an exact, inert source branch beside a
result branch evaluated exactly once at the same source occurrence:

```text
µshowcase{µemph{source displayed beside its expanded result}}
```

This is suitable for shared `.muweave` examples and has direct HTML, semantic
AI, LaTeX, and MyST projections. Prefer it over manually duplicating source and
result, which would evaluate state changes twice. The direct-HTML source panel
uses MuWeave's structural syntax tokens.

In the multiline brace form, visual source panels omit the one structural line
ending immediately after `{`; the retained expansion body and semantic-AI
source remain exact. A leading line ending explicitly supplied by the quoted
Python form remains visible.

For a document opened in the optional native reader, explicitly opt one
showcase into manual execution with a unique stable session:

```text
µshowcase[editable=True, session="lesson:experiment"]{
µexec("value = 6 * 7")
Das Ergebnis ist µexpr(value).
}
```

The normal browser, LaTeX, AI, and MyST projections remain static. The reader
enables source editing and Shift+Enter only after load, asks before granting
current-user Python execution, and lets the source field grow without an inner
scrollbar. During editing, MuWeave's non-evaluating structural analyzer keeps
the underlying coloured source layer current; highlighting does not execute
the cell and does not use a separate browser grammar. The authored result is
the initial output; the first successful run replaces it, and every later run
replaces the preceding runtime output rather than accumulating an output
history. This is a separate post-publication execution: it neither repeats nor
mutates the author build or its embedded AI bundle. `.work` stores edited
source but not generated result HTML. Use `muweave-reader lesson.html`; do not
embed a Python interpreter or invent browser-side Python execution in the
document.

The bare LaTeX-only `PytexContext` additionally provides `verb(text)` and
`verb_block(text)` with raw brace forms:

```text
µverb{µemph{shown as one physical source line}}
µverb_block{possibly multiline source}
```

`verb` selects a safe LaTeX `\verb` delimiter and rejects line breaks.
`verb_block` uses the core `verbatim` environment and rejects its literal end
marker in content. These two operations belong only in intentionally
target-specific `.pytex` source. Prefer portable `verbatim.inline` and
`verbatim.block` in shared source. A bare PyTeX5 context retains a legacy
LaTeX showcase only when no vocabulary schema declares the portable command.
PyMyST adds no target-only author command.

Not currently implemented as author operations: a standalone `code`
specialization, multi-image figures, remote-image download, resource
attachments/links, and automatic index collection from ordinary word
occurrences. Do not invent these names.

## 5. Essential MuVocab recipes

### Sections and references

Levels are logical integers `0` through `5`; do not write `chapter`,
`subsection`, or other target names. Multiple level-0 sections are valid.
Section numbering is target-native. A jump that skips a parent level warns.

```text
µsection(title="Mechanik", label="sec:mechanics")
µsection(title="Kinematik", level=1, label="sec:kinematics")
Siehe µref("sec:kinematics", display="name").
```

Use `File(...).insert(level_offset=1)` when a standalone source whose local
top level is 0 is inserted below a parent section.

### Portable annotations, colors, and tooltips

Use `tooltip` around an existing visible value; do not create a second
reference or math command merely for its presentation:

```text
µtooltip[Bei gleichem Exponenten werden die Basen multipliziert.]{µref("eq:power")}
```

The modifier/body form is deferred, so nested commands remain semantic. The
canonical Python form can wrap a reference, inline math, block, or another
currently placeable value. Direct HTML shows an escaped plain-text tooltip on
hover and keyboard focus; LaTeX and MyST currently preserve only the complete
visible value.

When a reference should show the equation itself instead of a separately
written explanation, derive the preview from its target:

```text
µref("eq:power", preview=True)
```

Direct HTML obtains the ordinary formula or complete labeled equation row from
the resolved semantic target. Do not duplicate that formula in `tooltip`.
LaTeX and MyST retain the ordinary reference without preview UI. Other target
kinds are not yet previewable in direct HTML.

The wrapper is deliberately not a `str` subclass or universal proxy. Annotate
after an ordinary transformation, use `transform_annotated` in controlled
MuVocab composition, or explicitly unwrap `.value` when discarding metadata is
intended. For direct-HTML mathematics, supported boundaries are a complete
formula, a structured equation cell, or one aligned cell segment. A tooltip
inside an undivided TeX-style string is a located error.

Use `color` for one exact portable foreground. The concise form accepts the
same six-digit sRGB notation as `Color.from_hex` or a human-readable portable
name and retains nested semantic values:

```text
µcolor[#B3261E]{Achtung: µbold{Definitionsbereich prüfen}.}
µcolor[dark-green]{Backendübergreifend eindeutig benannt.}
µcolor(ref("eq:power"), Color.from_name("Royal Blue"))
```

`color(...)` / `µcolor[COLOR]{...}` is the only portable author operation
for an explicit local foreground. Semantic roles such as links, solutions,
units, and block backgrounds use `Theme`, which resolves through the same
opaque sRGB `Color` model. Do not place CSS or LaTeX color commands in portable
source.

Named colors use the standardized opaque CSS palette plus
`rebeccapurple`. Names are case-insensitive; spaces, hyphens, and underscores
are optional separators (`darkgreen`, `dark-green`, and `Dark Green` are
equal). `Color.names()` returns the canonical accepted names. `transparent`
is unavailable because portable `Color` values are opaque.

The annotation changes presentation, not the wrapped Python value. It can
surround text, mathematics, references, tooltips, and complete semantic
blocks. In mathematics, annotate a complete formula, structured cell, or
aligned segment; an annotation embedded inside one opaque TeX-style string is
a located error. Direct HTML uses exact CSS sRGB, LaTeX uses xcolor's `HTML`
model, and MyST uses inline HTML for this concrete foreground.

### Vertical spacing

Direct HTML uses explicit block boundaries rather than browser margin
collapsing. Each visible block requests spacing before and after itself in
normal body-font units. Both direct HTML and LaTeX render one such unit as
`1em`, relative to the configured normal body font. The default between two
blocks is `max(previous.after, following.before)`.

Automatic requests are zero at the real beginning and end of a root or nested
flow. Explicit `spacing` values and leading or trailing `gap` operations remain
effective at those edges.

A physical blank line immediately before `block.equation` normally gives that
display a `1.25`-unit before request. With no blank line, the preceding
paragraph's ordinary `0.5`-unit after request controls the direct-HTML
boundary. Complete structured PyTeX5 instead retains LaTeX's native upper
display clearance without adding a paragraph gap. The physical source chooses
between the two forms directly:

```text
Text introducing the formula
µblock.equation{E=mc^2}
```

Insert a physical blank line before the equation when the larger display
boundary is intended. Use `spacing(...)` or a standalone `gap` operation for
an explicit override.

Wrap one semantic block with `spacing(...)` to replace either request:

```text
µspacing(block.theorem("Result."), before=2, after=0.5)
```

Place `gap` on its own line between block content to transform that boundary.
Operations are immutable, may be chained, and execute in final expanded source
order:

```text
First paragraph.

µgap.factor(1.3).add(0.5)
µgap.add(-0.25)

Second paragraph.
```

`set` replaces the intermediate value, `add` adds a signed difference, and
`factor` multiplies it. `set` and `add` default to body-font units; use
`gap.set("2cm")` (or `gap.set(2, unit="cm")`) for a physical 2 cm boundary.
`gap.add("0.25em")` explicitly selects the body-relative unit. Unit-bearing
strings and a separate `unit=` argument must not be combined. Mixed components
remain distinct and a later factor scales both. Negative operands and results are
valid; use `gap.set(-0.25)` for deliberate overlap. Adjacent operations
contributed by an inserted file and its caller compose if no visible block
separates them. A real nested block body owns its own flow, so an internal gap
does not escape to the surrounding document.

Sections use baseline requests `before=1.25` and `after=0.75` at level 3 and
deeper. Both are multiplied by
`effective_scale_factor ** max(0, 3 - level)`. The common
`typography.scale_factor` defaults to `1.25`, is captured per occurrence, and
also controls `µsize[STEP]{...}`. Leave `section.scale_factor` unset for this
unified policy. Set it explicitly only when headings deliberately require an
exceptional geometric scale.
Complete PyTeX5 uses the identical spacing values and explicit matching
heading sizes.

Use a signed finite real step, not a target size or nested relative markup:

```text
Normal, µsize[1]{one step larger}, µsize[-1]{one step smaller},
µsize[1.57]{an intermediate step}.
```

`size(text, step=n)` is the canonical Python form and accepts a finite `int`,
`float`, or `Decimal`. Its absolute point size is
`typography.font_size_pt * typography.scale_factor ** n`; nesting does not add
the surrounding step. MuVocab rounds the resulting common size to the nearest
`0.001 pt` before direct HTML, complete PyTeX5, and MyST project it. The brace
body expands normally. Semantic AI keeps the visible content without its
purely visual size.

When `µsize[-1]{...}` fills a complete paragraph, PDF and direct HTML also
apply its retained `typography.line_height` to the whole paragraph. For a
local override, save `config["typography.line_height"]`, use `config.set`,
then restore the saved value after a blank line. Mixed inline size changes
do not replace the surrounding paragraph's baseline policy; see the
[typography recipe](../../muvocab/docs/AUTHORING.md#vertical-spacing-and-block-boundaries).

Initial document typography is configured through the existing argument
layers, for example:

```text
µ! --config typography.font_size_pt=10
µ! --config typography.line_height=1.35
µ! --config typography.scale_factor=1.25
µ! --config typography.paragraph_gap=0.5
µ! --config section.line_height=1.2
µ! --config 'theme.theorem.background=#B8E2B5'
µ! --config 'theme.theorem.rail=#83E58A'
µ! --config 'theme.definition.background=#E0B3B3'
µ! --config 'theme.definition.rail=#E78F8F'
µ! --config 'theme.remark.background=#FFFA99'
µ! --config 'theme.remark.rail=#E8D650'
µ! --config 'theme.attention.background=#FFBF80'
µ! --config 'theme.link.foreground=#315CA8'
µ! --config 'theme.solution.foreground=#800000'
µ! --config 'theme.author.note.foreground=#FF8000'
µ! --config 'theme.author.note.background=#FFFFFF'
µ! --config 'theme.author.note.accent=#FF8000'
```

Other semantic color roles are `theme.definition.zfc.foreground`,
`theme.tooltip.foreground`, `theme.tooltip.background`, and
`theme.focus.outline`. Values are `Color`
instances, exact `#RRGGBB` strings, or readable names. Hex values must be
quoted in argument layers because `#` begins a comment; a name such as
`theme.link.foreground=royal-blue` needs no quoting.

The additional section clearance names are `section.gap_before` (default
`1.25`) and `section.gap_after` (default `0.75`). PyHTML and complete PyTeX5
consume these same settings; low-level expansion has no document typography.

This feature renders through PyHTML and complete PyTeX5 document mode. PyTeX5
low-level preprocessing and PyMyST raise a located error instead of silently
dropping it. A portable MuCompose source may therefore use `gap` across its
current LaTeX and direct-HTML targets.

### Semantic enumerated lists

Use `lists.enumerated` for general ordered entries, including but not limited
to subproblems. The vertical form is:

```text
µlists.enumerated[
    keys=("meeting", "position"),
]{
Find the meeting time.
,,
Find the meeting position.
}
```

The `,,` separators belong to this registered plural-body form; every body is
expanded recursively. Use the canonical Python call when a body must contain a
literal `,,`. A grid changes only presentation:

```text
µlists.enumerated[
    layout="grid",
    columns=3,
    content="math",
]{
a^m a^n = a^{m+n}
,,
\frac{a^m}{a^n} = a^{m-n}
,,
(a^m)^n = a^{mn}
}
```

`layout` is `vertical` or `grid`. Vertical layout forbids `columns`; grid
layout requires an integer of at least two and fills entries row by row.
`content` is `flow` for ordinary structured content or `math` for
display-style mathematical cells. Presentation never changes semantic order,
markers, keys, references, or AI output. PyAI emits the ordered entries and
intentionally drops grid layout and column count.

The default marker style is `lower-alpha`, beginning at `start=1`, with empty
`prefix` and `suffix=")"`. Other styles are `upper-alpha`, `decimal`,
`lower-roman`, and `upper-roman`. Prefix and suffix affect only visible
punctuation. `trim=True` removes complete blank boundary lines, not interior
content.

Inside a referenceable block, an entry target is
`OWNER/entry/KEY`. A canonical item supplies `OWNER` automatically from its
identity, so a list in `11.muweave` can declare:

```text
µlists.enumerated[
    keys=("meeting", "position"),
]{Find the time.,,Find the position.}
```

Then `µref("11/entry/meeting")` renders the full owner-qualified form, such
as `Übungsaufgabe 2.7 a)`, while
`µref("11/entry/meeting", display="number")` renders only `a)`. A direct
block must supply a label to act as `OWNER`. Without explicit keys, the bare
generated designations (`a`, `b`, and so on) are used, independent of marker
punctuation. Multiple lists under one owner share this target namespace; use
unique explicit keys whenever their automatic designations would collide.

### Horizontal layout

Use `layout.columns` to divide available width without target-specific
minipages or HTML:

```text
µlayout.columns[
    widths=(0.4, 0.6),
    valign="top",
    halign=("justify", "center"),
]{
Explanatory text with µemph{normal nested expansion}.
,,
µFile("images/diagram.png").image(alt="Diagram", width=1)
}
```

At least two parts are required. `widths` are positive relative weights;
`gap=0.02` reserves two percent of the full width between adjacent parts and
the remaining width keeps the requested ratio. The tallest natural part sets
the row height. `valign` is `top`, `center`, or `bottom`; `halign` is
`natural`, `left`, `center`, `right`, or `justify`. `right` means right-aligned
lines; `justify` means a paragraph aligned to both edges. Either alignment may
be one scalar or one value per part. The default top alignment prevents a
short text or image from being unexpectedly centered beside a tall neighbor.
Boundary blank lines are removed by default; `trim=False` preserves them. Use
canonical Python arguments if a body itself contains literal `,,`. HTML
hyphenation for justified text is most reliable when frontend language
metadata is supplied.

In direct HTML and complete PyTeX5, column alignment uses actual box edges or
centres. A sole `g.canvas` or `g.triangle` needs no trimming; it reserves its
native box without incidental text-line height. Use `.trim()` on a neighbouring
equation to remove certified automatic display-edge reserves. Explicit bounds,
padding and external gaps remain; mixed prose retains normal inline baselines.
See [measured trimming](../../muvocab/docs/AUTHORING.md#measured-outer-edge-trimming).
Structured equations also accept `row_gap` for their internal clearance.
For a graphic that should follow the formulas' measured height, write
`gap="evenly"` distributes remaining width equally before, between and after
the resulting column boxes. Isolated drawings/equations use certified natural
widths; ordinary text keeps its wrapping allocation. This combines with
`height_from` without scaling letters or changing inner formula gaps. Numeric
`gap` keeps its existing fixed inter-column-fraction meaning.

`names=("grafik", "formeln"), height_from={"grafik": "formeln"}` in
`layout.columns`. The first dependent adapter accepts one isolated `g.canvas`
or `g.triangle` (optionally trimmed). Only geometry scales: fonts, strokes,
physical padding and label offsets stay fixed. References must be unique local
names and acyclic. HTML reports an unsatisfiable fit visibly; LuaLaTeX fails
explicitly. AI retains original graphic/formula semantics, not layout keys or
fitted dimensions. See the complete
[height-matching contract](../../muvocab/docs/AUTHORING.md#dependent-graphic-height)
for bounded search limits, width constraints and unsupported wrappers.

Use `layout.wrap` when ordinary body text should use the space beside a compact
object and then return to full width below it:

```text
µlayout.wrap[side="right", width=0.4, halign="justify"]{
Text that first flows beside the image and then spans the complete width.
,,
µFile("images/diagram.png").image(alt="Diagram", width=1)
}
```

The first part is the flowing body; the second is the side object. `side` is
`"left"` or `"right"`, `width` and `gap` are fractions of the complete width,
and their sum must be below one. `halign` uses the column alignment vocabulary.
LaTeX renders a non-floating `wrapfigure`; MyST renders a CSS float. Avoid this
construct at page boundaries, in lists, or around headings and large display
blocks. Use `layout.columns` when both parts must keep their assigned width for
the full construct height.

### QR-coded external links

Margin placement is the default. The optional second argument is a concise
plain-text link anchor at the exact source occurrence; following source remains
ordinary structured MuWeave text:

```text
Open the µqrcode("https://www.geogebra.org/m/rs6djser", "graph") and vary the
µbold{slider}.
```

The QR visual consumes no main-text width. LaTeX puts it in the outer margin
(right on odd pages, left on even pages) and aligns it towards the text body;
continuous HTML keeps it in the right margin. Use `placement="inline"` only
when an explicit `layout.wrap` or `layout.columns` value should own its
position:

```text
µlayout.columns[widths=(0.9, 0.1), valign="center"]{
Open the link and vary the µbold{slider}.
,,
µqrcode("https://www.geogebra.org/m/rs6djser", placement="inline")
}
```

`size` defaults to `"1.5cm"`; bare numbers also mean centimetres. Only
absolute HTTP and HTTPS URLs without whitespace are accepted.

Direct HTML embeds a clickable white-backed inline SVG and no QR image asset,
remote service, or browser script; both the QR graphic and optional anchor open
the URL in a new tab. LaTeX emits a clickable TikZ vector matrix as a margin
note. HTML measures centimetres against the same logical 21 cm A4 width as
generated graphics, so document zoom scales them together. MyST retains
equivalent SVG for its HTML path. AI export records the visible anchor, external
URL, and `visual_encoding="qr_code"`, but neither margin nor matrix geometry.

### Native applet items

Use `µblock.applet(item=88)` for portable applet content whose PDF occurrence
should show only a link, QR code and print description. The item declares
`µblock.source(default_kind="applet")`, keeps its complete web content in the
implicit body and supplies `µblock.part("description")` followed by ordinary
MuWeave prose. Configure the publication root with an initial
`µ! --config applet.base_url=https://example.org/items/` or the equivalent
inherited arguments. The item identity supplies the final `88/` URL segment;
an explicit `url=` overrides the address. No site is hardcoded in MuVocab.

HTML displays the full applet; AI retains full content, description and URL
from the same expansion. Keep teaching definitions required in print in their
own items outside the applet and include them separately in standalone wrappers
when needed. Labels, optional numbering and references use the common block
contract. Complete PyTeX5, direct HTML and AI support this form; legacy MyST
and low-level LaTeX string expansion reject it. See the
[full applet contract](../../muvocab/docs/AUTHORING.md#native-applet-items)
for direct two-body syntax, validation and nested references.

### Interactive web modules

Use the sole author command `block.interactive` for a versioned application
that must work offline inside a PyHTML worksheet:

```text
µblock.interactive(
    "motion",
    instance="kinematics-uniform-motion-1",
    activity="piecewise_uniform",
    presentation="compact",
    height="11cm",
)
```

`instance` is mandatory, unique in the complete document, and stable across
harmless document extensions. It—not the source position or block number—is
the learner-state key. The module ID resolves exactly to `<id>.muweb` below
`--interactive-dir` / `MUWEAVE_INTERACTIVE_DIR`; there is no checkout search
or network fallback. `activity` selects one manifest-declared logical activity
inside the artifact. `presentation` independently selects compact application
content or the full application chrome inside the host; inline defaults to
compact and tab to full. Both presentations share one artifact, state schema,
and instance. The `.muweb` archive is a composition input rather than an
independent offline page; the finished PyHTML document is the learner-facing
offline unit.
`mode="embed"` with `open="inline"` is the default. Choose `open="tab"` for
the same host-composed payload in a dedicated tab, or
`mode="link", open="tab"` for only the canonical HTTPS site.
Format-three manifests may name closed host-runtime profiles. PyHTML must
provide those profiles from its pinned local registry and store each unique
payload only once in the final HTML. Current PyHTML implements
`math: muweave-mathjax-4-svg-v1`; a requesting format-three module must omit
its own MathJax copy. Unknown profiles fail publication explicitly and never
fall back to a network resource.

PyTeX5 emits a linked title and QR code without executable bytes. PyAI emits
an `interactive_activity` node without JavaScript, CSS, or layout height.
PyMyST emits a linked block. Preserve an instance when its activity and
state schema remain compatible; change it deliberately for a genuinely new
learner-state identity. When a module raises its state schema, its bridge must
register a complete adjacent migration chain. The HTML host migrates before
initialization and quarantines the exact old record without deletion when a
module identity, future schema, missing step, or failed migration is
incompatible. See the
[canonical MuVocab module guide](../../muvocab/docs/INTERACTIVE.md) and
[MuWeb format guide](../../muweb/docs/MODULE_FORMAT.md).

### Generated coordinate systems

Use the ordinary Python namespace `g` for generated graphics. The initial
operation is a Cartesian coordinate system:

```text
µg.axis(
    xmin=-4,
    xmax=6,
    ymin=-3,
    ymax=5,
    x=r"t",
    y=r"v",
    xstep=2,
    ystep=1,
    grid=True,
    width=12,
    height=8,
).add(
    g.line((-3, -2), (5, 3), color="royal-blue"),
)
```

The `g` installed in every MuVocab context also owns source-ordered ambient
graphic settings:

```text
µg.scale(1.5)
µg.axis(0, 4, 0, 3)
µg.scale(1.2)
µg.axis(0, 8, 0, 5, scale=0.5)
µg.reset()
```

`g.scale(factor)` replaces the ambient positive geometry factor and
`g.reset()` restores one. A local `g.axis(..., scale=factor)` multiplies the
ambient factor. Both affect physical plot geometry, not labels, tick numbers,
strokes, points, or arrowheads. The setting is captured where each graphic
becomes visible, so a graphic stored in a Python variable uses the state at its
later `µname` occurrence. Separate frontend contexts have independent state.

When multiple axes must have the same data scale or align one data coordinate,
reuse one immutable layout instead of copying calculated widths or compensating
for container offsets:

```text
µexec("""
time_axes = g.axis_layout(
    scale=0.9,
    x_unit_length="1.2cm",
    anchor_x=0,
    anchor_at_x="1.05cm",
)
""")

µg.axis(0, 9, 0, 16, height="3.8cm", layout=time_axes)

µresponse.canvas(
    "velocity-diagram",
    height="3.6cm",
    frame=False,
    underlay=g.axis(0, 9, -2, 3, height="3cm", layout=time_axes),
)
```

The exact constructor is
`g.axis_layout(*, scale=1, x_unit_length=None, y_unit_length=None,
anchor_x=None, anchor_at_x=None)`. Unit lengths are unscaled centimetres per
data unit. The reusable `scale`, the axis-local `scale`, and the active
source-ordered `g.scale` factor multiply only physical geometry. For example,
`1.2cm` and `scale=0.9` produce `1.08cm` per unit while typography and stroke
weights stay unchanged.

`anchor_x` and `anchor_at_x` form an inseparable pair. The former is a data
coordinate inside the visible x range. The latter is either a bare/cm distance
from the current local frame's left edge or a percentage string such as `"7%"`.
An anchored layout supersedes `align=`. Ordinary flow uses the available
document row as its frame; a response-canvas underlay uses its local paper,
whose visual outline and controls do not inset authored coordinates. Never
calculate a global browser or page position. Do not prescribe the same axis
twice with both `x_unit_length` and a conflicting `width`, or both
`y_unit_length` and a conflicting `height`. `g.grid(...)` accepts the same
`layout=` object.

Ranges must normally be increasing. The exact pair `0, 0` disables that
coordinate dimension, including its axis, ticks, numbers, label, and plot
extent; at least one dimension must remain active, and the corresponding
`width` or `height` must remain omitted. Steps and active dimensions must be
positive and finite.
Tick positions are zero-relative step multiples clipped to each range. With a
grid, its lines replace redundant short tick marks and the numbers remain
outside the plot frame. Without a grid, short ticks and numbers attach directly
to visible zero axes and otherwise fall back to the undrawn plot boundary. The
rectangular frame is drawn only with the grid. Zero axes appear only when zero
is in range. `x` and `y` accept TeX-style mathematical labels without
delimiters; an empty string suppresses one. A semantic unit selects the
conventional variable plus its bracketed unit: `x=unit("m")` renders `x [m]`
with the standard green upright unit. A pair such as
`x=("t", unit("s"))` supplies a different variable without flattening the
unit to target markup. A semantic vector label is equally portable:
`y=(v.x, unit("m"))` preserves the target-specific vector arrow. If omitted,
`width` is `xmax - xmin`
centimetres and `height` is `ymax - ymin` centimetres, giving one centimetre
per coordinate unit. Explicit dimensions override that physical plot size;
bare numbers default to centimetres, so `width=12` and `width="12cm"` are
equivalent. Labels and tick annotations receive additional outer margins and
do not shorten either axis. In direct HTML, centimetres are fractions of the
logical 21 cm A4 surface; in LaTeX they are TikZ centimetres. `aspect="free"`
uses the requested plot dimensions independently, whereas `aspect="equal"`
preserves equal coordinate-unit scales inside the requested plot rectangle.
Use `align="left"`, `align="center"`, or `align="right"` to place the complete
graphic in the available document width; the default is centered. `scale` is
a positive uniform factor for the physical plot geometry: `scale=0.6` renders
both coordinate directions at 60 percent without changing ranges or step
sizes. Labels, tick numbers, line weights, points, and arrowheads keep their
normal typographic sizes. Whole-object scaling belongs to a separate outer
transformation and is not part of `g.axis`.

For an arbitrary composed label, `g.axis` explicitly accepts MuWeave source
in its `x` and `y` strings when they contain an active `µ`:

```text
µg.axis(
    0,
    8,
    0,
    5,
    x="µm{t [µunit{s}]}",
    y="µm{µv.x [µunit{m}]}",
)
```

Direct HTML, complete PyTeX5, and PyAI retain these as named structured
children of the axis. Nested vectors, units, emphasis, references, state, and
provenance are not converted through an intermediate target string. This is a
declared exception for selected content-bearing parameters—currently axis
labels, complete point or vector subscripts, semantic vector labels, and names
of vector arrows contained by an `Axis` or `Scene3D`—not a rule that
recursively evaluates every Python string in MuWeave.

Use `axes="x"`, `axes="y"`, or `axes="none"` to retain only the selected
zero axes (`"both"` is the default). `ticks=False` suppresses short gridless
tick marks and `numbers=False` suppresses their numeric labels independently.
A blank x-axis intended for handwriting is therefore:

```text
µg.axis(0, 10, 0, 0, ticks=False, numbers=False)
```

This zero-range form removes the y dimension and its spacing. `axes="x"`
instead hides only the y-axis presentation while retaining a 2D viewport and
its authored height.

Use `g.curve(*points, ...)` for a smooth Hobby interpolant through fixed numeric
2D knots. It is an element for `g.axis(...).add(...)` or `g.canvas(...).add(...)`,
with no brace shorthand. Open curves need two knots; `closed=True` needs at
least three and adds the closing interval without repeating the first point.
Adjacent points must differ. Uniform `tension >= 0.75` and nonnegative
`start_curl`/`end_curl` control the shape; closed curves leave both curls at 1.
MuGeometry computes cubic controls once using the standard library. HTML and
PDF draw those controls and AI retains them with knots and parameters. The
curve can overshoot: choose axis ranges accordingly. For example:

```text
µg.axis(0, 7, 0, 4.5, x="t", y=v.x).add(
    g.curve((0, 1), (1, .5), (3, 1), (4, 2), (5, 3.5), (7, 4)),
)
```

Fixed curves work inside interactive bodies; symbolic knots, coordinate zoom
on a curve, 3D, and MyST are unsupported. Consult MuVocab's canonical
`AUTHORING.md` section “Hobby interpolating curves” for the complete contract.

Use `g.plot(expression, variable=..., xmin=..., xmax=..., ...)` for a sampled
scalar graph. Its local `variable` is bound at each horizontal sample and does
not require a Python assignment or slider. `samples` counts equal intervals,
so the polyline includes both endpoints and contains one additional point.
`g.riemann_sum(...)` accepts the same expression and local variable, plus a
positive integer `partitions`, `sample="left"`, `"midpoint"`, or `"right"`,
a horizontal `baseline`, and portable rectangle colors, opacity, and border
width. Set `approximation_color` to draw a separate step trace along the
rectangle tops; `approximation_stroke_width` gives its typographic-point width.
Both are graphic elements and must occur inside `Axis.add(...)`.

A function decorated with `@g.interactive(...)` returns semantic content,
which may be an axis or a `layout.columns(...)` / `layout.rows(...)` composition of several axes
and `ui.output(...)` displays. It executes once with symbolic terms. The
retained body shares one set of controls; nested interactive scopes are
unsupported. `ui.output` accepts a scalar expression or a coordinate vector
such as `v(x, y)`, mathematical `label`
(the renderer adds `=`), semantic `unit`, display-only `significant_digits`,
and an optional `when=(left, comparison, right)` domain guard. False guards
and nonfinite results show `undefined` text. Preserve a cancelled denominator's
zero explicitly, for example `when=(t_E, "!=", t_A)`. Use complete document
rendering for composed scopes. See the
[shared layout example and full contract](../../muvocab/docs/AUTHORING.md#computed-numeric-outputs-and-shared-layouts).
Set `frame=False` for an unboxed result, for example
`ui.output(v(x, y), label=v.n, frame=False)` beside a diagram.

For vertically aligned position/velocity diagrams, return
`layout.rows(position_axis, velocity_axis, gap=0.8)` and give both axes the
same `g.axis_layout(...)`. Rows preserve child sizing and accept semantic
objects directly; `gap` is a nonnegative em number. Use nested columns for a
formula beside either diagram. All row contents and their order reach AI.
`position.diff("tau")` computes the velocity as a `Term`, including the
alternatives of a `ui.select` expression. An explicit symbol is required;
`diff("tau", 2)` computes a second derivative. Other symbols remain constant.
The result must still be supported by the interactive numeric protocol.
See the [scalar-term contract](../../muvocab/docs/LINEAR_ALGEBRA.md#scalar-terms).

Use `g.point((x, y), draggable=True)` in that scope's 2D axis to let learners
move a point directly. Bind each moving coordinate to a distinct declared
`ui.slider` symbol; constants stay fixed, so `(x, 0)` moves horizontally.
Derived coordinate expressions, selects, checkboxes, two fixed coordinates, free canvases,
and 3D dragging are unsupported. HTML provides mouse/touch/pen dragging and
keyboard arrows, synchronized with the same sliders and their ranges/steps.
Point dragging works with coordinate zoom and does not pan the view. PDF uses
authored defaults; AI retains the movement intent and symbolic bindings.
See the [complete movable-point recipe](../../muvocab/docs/AUTHORING.md#draggable-points).
Use `ui.slider(..., visible=False)` to keep the coordinate input and its range
without showing a slider row. `ui.checkbox(default=True, label="Normalvektor")`
provides a strictly Boolean authored default and a symbolic `0`/`1` value.
Pass `when=(show, "==", 1)` to 2D lines, arrows, vectors or points to toggle
them; a hidden point's label and drag handle are hidden too. Checkbox values
cannot bind draggable coordinates. PDF uses the authored defaults and AI
retains the control declarations and conditions.

Use `g.axis(..., zoom=g.zoom(center=(t_A, x_A), x_controls=("t_A", "t_E")))`
inside that scope for coordinate zoom and drag panning at a fixed physical
plot size. HTML provides corner buttons and wheel zoom around the pointer.
Coupled slider ranges and precision follow the view; selected values stay
fixed until reaching a range boundary, then follow that boundary until moved
inside manually. Wheel zoom uses continuous steps. Wider authored slider bounds
keep their proportional overhang beyond the plot. PDF uses the original
defaults and AI retains the coupling and value-preservation rule. The
general `g.zoom` policy also accepts `y_controls`, a `factor` and `max_steps`.
For the same domain on a secant and its result, create
`valid = ui.condition(t_A, "!=", t_E, displayed=True)` and pass `when=valid`
to `g.line`/`g.arrow` and `ui.output`. This hides the secant when the displayed
times coincide; `undefined="Division durch 0"` explains the excluded quotient.
This comparison does not round the raw controls or formula. See the
[zoom contract and executable example](../../muvocab/docs/AUTHORING.md#coordinate-zoom-and-coupled-sliders).

Inside a graphic declared by `@g.interactive(...)`, each matching function
parameter is declared with `ui.slider(...)`, `ui.select({...}, ...)`, or
`ui.checkbox(...)`.
Dropdown keys are visible labels and values are scalar `Term` alternatives;
the function receives the selected expression directly. Free symbols other
than the plot's bound variable must come from those controls, and `partitions`
may be a slider term. The bound variable must not collide with a control name.
Direct HTML lazily selects the active dropdown branch and regenerates points,
rectangles, and any step trace from a closed data protocol whenever a value
changes; it never executes Python or generated JavaScript. PyTeX5 renders the
authored defaults in native TikZ, and PyAI retains all options together with
the exact expression, domain, sampling policy, and symbolic partition count.

`g.angle(vertex, first, second, label, ...)` is a target-neutral calibrated
angle marker inside `Axis.add(...)`; it never draws the two rays itself. The
vertex and a point direction accept `p(...)` or tuple/list shorthand. A
directional ray must be written as `v(...)`: tuple/list directions mean points.
`mode="minor"` selects the smaller order-independent opening, while
`mode="directed"` measures counterclockwise from `first` to `second` and can
therefore represent a reflex angle. Use a concise label string or
`math_label("α", latex=r"\alpha", label_class=...)`. An omitted class is
looked up in MuGeometry's canonical model and unknown labels use `"medium"`;
the explicit classes are `"small"`, `"medium"`, and `"large"`.

Omit `arc_radius`, `label_percent`, and `label_angle_offset` for automatic
profile-aware placement. Exact overrides use mathematical-font `em`, percent
of arc radius, and signed degrees respectively. `font_size`,
`ray_stroke_width`, and `arc_stroke_width` are typographic points; the font
defaults to the occurrence's normal body size. Direct HTML derives the visible
physical opening after axis scaling and invokes the registered provisional
MathJax-4/SVG profile. PyTeX5 derives the same visible geometry and invokes its
registered provisional LuaHBTeX/PGF/TikZ/Latin-Modern-Math profile before
emitting native TikZ. PyAI retains the unfitted geometry. PyMyST rejects the
marker explicitly. See the complete parameter and target contract in
[AUTHORING.md](../../muvocab/docs/AUTHORING.md).

`g.line(start, end, ...)` uses equal-dimensional `p(...)` values or tuple/list
shorthand. A line's `name="a"` is scalar mathematics, not a vector. Use
`name=v.a` or `name="µv.a"` explicitly for vector notation. Names may also be
semantic mathematical values or `math_label("Seite c", latex="c")`; complete
quoted MuWeave names are retained mathematical arguments expanded once at the
owning axis/scene occurrence. Supply them without outer math delimiters.

`g.arc(center, radius, start_angle=0, sweep=90, ...)` retains a 2D circular
arc in data coordinates. Angles are degrees, positive sweeps counterclockwise,
negative clockwise, with `0 < abs(sweep) <= 360`; a full turn gives a circle.
It shares the line color/cap/width and name-placement options. `label_at`
selects a fraction of the directed sweep; left/right refer to its projected
tangent. An anisotropic axis makes the data circle appear elliptical; select
`aspect="equal"` to keep it visibly circular. Labels and widths remain
typographic, independent of graphic scale. Static arcs work in 2D axes only,
including static context inside an interactive graphic. HTML/SVG, native TikZ,
and semantic AI are supported; AI keeps the unfitted original geometry, name,
explanations, and colors. See [the complete arc contract](../../muvocab/docs/AUTHORING.md#circular-arcs-and-complete-circles).

`g.arrow(start, end, ...)` uses the same geometry for a general
directed arrow; its head dimensions are typographic points. It accepts the
same scalar names and placement options as `g.line`. Lines, arrows and vector
arrows follow reactive endpoints, including reversals. Their
`label_min_length="auto"` hides labels when their measured box no longer fits;
a nonnegative number instead specifies a physical minimum segment length in
points. Collapsed segments paint neither shaft, head nor label. These fitting
choices do not remove content from AI. Nonzero thresholds cannot currently be
combined with dependent `height_from` fitting. `g.vector(vector,
...)` instead requires a `CoordinateVector`, defaults its start to the
dimension-matching zero point, and computes `end = start + vector`. Its
optional mathematical name follows this exact contract:

```python
g.vector(v(3, 2), name="a")
g.vector(v(3, 2), start=p(-1, 1), name=v.a)
g.vector(v(2, -1), name=v.v[1], label_side="right")
g.vector(v(2, -1), name=v.v["µinterval{t_A,,t_E}"])
g.vector(p(4, 3) - p(1, 1), start=p(1, 1), name=v.AB)
```

`name="a"` and `name=v.a` are equal; use structured symbols for indexed and
connection notation. `name=None` is unlabelled. `label_at` is from zero through
one, `label_side` is `"left"` or `"right"` along the direction, and
`label_offset` is a nonnegative point distance. Do not assume that the Python
assignment name can be recovered automatically. In direct HTML, complete
PyTeX5, and PyAI, an `Axis` or `Scene3D` explicitly retains an active MuWeave
string subscript in such a name. Prefer the immediately semantic
`name=v.v[interval("t_A", "t_E")]` when possible because that spelling also
works in low-level and MyST renderers.

Lines and arrows retain 2D or 3D endpoints, but a Cartesian axis accepts only
2D elements. Geometry may cross the visible boundary and is clipped to the
plot frame. Portable colors accept a `Color`, `#RRGGBB`, or readable name;
`stroke_width` is a positive number of typographic points. The default
`cap="round"` adds a semicircle centered on each endpoint. Alternatives are
`"butt"` and `"square"`. `Axis.add(*elements)` returns a new immutable axis;
elements paint in source order above the grid and below axes, frame, ticks, and
labels. `g.point(position, color=..., radius=1, label=None, label_angle=45,
label_radius=8, draggable=False)` creates a filled circular marker. Its 2D or 3D position uses
`p(...)` or tuple/list shorthand. The positive marker radius and nonnegative
centre-to-label-centre distance are measured in typographic points,
independently of coordinate scale. `label_angle` is counterclockwise from
visible right (`90` means above), after any 3D projection. All three numeric
options must be finite and not booleans. Labels stay horizontal, use the
point's color, and accept mathematical content such as `p.A`, `p.A[1]`, or
`"µp.A[1]"` without an implicit vector accent. Quoted labels expand once at
the graphic's source position. `p(...)` alone is affine data and does not
request a visible marker. For example:

```text
µg.axis(-4,6,-1,5,grid=True).add(
    g.point((2,3), label=p.A, label_angle=135),
    g.point((5,4), label=p.B, label_angle=135),
)
```

HTML and LaTeX preserve physical label offsets, including dependent fitting;
HTML also follows reactive movement and coordinate zoom. AI retains point
geometry and mathematical names but omits sizes and placement.
Bare line, arrow, vector-arrow, and marker values are invalid without a
coordinate viewport.

`g.axis` has no brace shorthand and returns a semantic block. Direct HTML uses
inline SVG plus MathJax labels. LaTeX uses native TikZ, including the
profile-calibrated angle marker. MyST rejects generated axes explicitly. The
composed axis occupies one vertical layout block but is neither a `block.*`
content command nor automatically numbered or referenceable. Use `g.canvas`
for supported 2D elements in an inline drawing without visible axes.

For retained 3D graphics, an author must select one camera explicitly:

```text
µg.scene3d(
    g.camera.orthographic(
        (6, -8, 5),
        target=(0, 0, 0),
        up=(0, 0, 1),
        view_height=4,
    ),
    width=10,
    height=7,
).add(
    g.line((-1, -1, -1), (1, -1, -1)),
    g.line((1, -1, -1), (1, 1, -1)),
    g.vector(v(1, 1, 1), name="a", color="forest-green"),
    g.point((0, 0, 0), color="dark-orange", radius=3),
)
```

The alternative is `g.camera.perspective(position, *, target=(0,0,0),
up=(0,0,1), field_of_view=45, near=0.01)`. Orthographic cameras use
`view_height=10`. `g.scene3d(camera, *, width=12, height=8)` returns an empty
immutable scene; `.add(*elements)` returns a new scene. Inputs must form a
nondegenerate 3D camera and finite real coordinates at projection time.
Perspective element points must lie beyond the near plane. Direct HTML emits
SVG, LaTeX emits projected TikZ, and MyST errors. The current scene has lines,
general arrows, named or unnamed vector arrows, filled point markers,
source-order painting, projected vector-name labels, and rectangular clipping—
no surfaces, hidden-line removal, lighting, 3D coordinate axes, or near-plane
splitting.

### Terms, points, vectors, and matrices

`Term` is the stable MuVocab scalar abstraction; SymPy is its private initial
engine. It accepts scalar numbers, strings, another `Term`, and scalar SymPy
expressions. Arithmetic, `simplify()`, and `subs(...)` return `Term`;
`as_decimal(precision=...)` explicitly evaluates a finite real constant.

`p(...)` creates an affine coordinate point and `v(...)` a coordinate column
vector. Both infer their dimension from the supplied coordinates and support
2D and 3D `.x`, `.y`, and `.z` access. Points obey affine operations:
point plus/minus vector is a point, while point minus point is a vector.
Vectors support ordinary vector/scalar arithmetic, `abs(vector)`, `.unit`,
3D `.cross(...)`, and substitution.

Use `length(...)` for visible vector-length notation and reserve `abs(...)`
for computing the Euclidean norm of a concrete coordinate vector:

```text
µlength{µv.a}
µblock.equation{µlength{µv.b-µv.a}=\sqrt{13}}
µm(length(v.AB))
µlength("µv.c[1]")
```

PDF, HTML, and AI use one vertical bar on either side. Never emit raw
`\lVert`/`\rVert` for this notation. MuVocab intentionally leaves Python's
builtin `len` untouched. The Python form accepts exact mathematical strings
and semantic objects. An active `µ` inside its quoted value opts into one
structured, source-ordered expansion at the owning `length` occurrence.

Vectors are columns and `@` always means matrix multiplication. Write
`u.T @ w` for the scalar-product special case and `u @ w.T` for an outer
matrix; plain `u @ w` is invalid. `Matrix(rows)` provides `.shape`, `.T`, and
dimension-checked `@`.

Named spellings are normal Python chains:

```text
µp.A
µp.A[1]
µv.v[1]
µv.v[1].x
µv.v[interval("t_A", "t_E")]
µv.AB
µv.A1_A2
µv.from_to(p.A[1], p.A[2])
```

`v.A_1A_2` is deliberately rejected as ambiguous. An interval or another
semantic mathematics fragment may index the complete point or vector. The
ordinary Python value works in every current renderer:

```text
µv.v[interval("t_A", "t_E")]
```

Typed direct HTML, complete PyTeX5, and PyAI additionally support the selected
string spelling `µv.v["µinterval{t_A,,t_E}"]`. The active `µ` makes this
specific subscript a retained mathematics argument; it does not establish a
global recursive-string rule. The same typed targets support it in semantic
`Axis.x`/`Axis.y` labels and in `VectorArrow.name` fields explicitly contained
by an `Axis` or `Scene3D`:

```text
µg.axis(0, 4, 0, 3, y=v.x["µTerm(2)"]).add(
    g.vector(v(2, 1), name=v.v["µinterval{t_A,,t_E}"])
)
```

Other outer objects do not inherit this behavior automatically. Symbolic
components such as `.x` still require a scalar `Term` index.

If an index is arbitrary formula source rather than a modeled object, compose
it freely in inline mathematics:

```text
µm{{µv.v}_{µinterval{t_A,,t_E}}}
µm{{µv.v}_{\substack{k\in\mathbb{N}\\k\text{ gerade}}}}
```

The `\substack` example has no current `Term` or semantic-fragment form, so it
cannot be passed through `v.v[...]`. Conversely, the free `m` spelling returns
presentation mathematics, not a `VectorSymbol` that can later be supplied to
`g.vector(..., name=...)`.

Coordinate values can use the plural brace forms `µp{1,,2,,3}` and
`µv{a,,2,,3}`. Used directly they
render as inline mathematics; compose values inside existing math with
`m(p(...))` or `block.equation(v(...))`. `g.axis` rejects retained 3D graphic
elements;
use `g.scene3d` with an explicit camera instead. See the [complete
linear-algebra and 3D contract](../../muvocab/docs/LINEAR_ALGEBRA.md).

### Mathematics

Prefer existing semantic operations over raw TeX where available. For example,
`µfrac{a,,b}`, `µsqrt{a^2+b^2}`, `µsqrt(frac("9", "4"))` and
`µsqrt("µfrac{9,,4}")` retain mathematical structure. A square root accepts a
string or mathematical object without automatic simplification; nested
source arguments are expanded once. See the
[complete mathematics reference](../../muvocab/docs/AUTHORING.md#mathematics).

Use `mtext` for literal upright mathematical text, `mop` for named operators,
`ol` for an overline (`µol{AB}`, `µol("AB")` or `µol(v.AB)`),
`accent` for selectable bars/hats/dots/arrows, `overunder` for explanations, `mathstack`
for unnumbered mathematical rows, and `mathspace` for explicit layout-only
spacing. Their argument contracts and editable examples are in the
[notation reference](../../muvocab/docs/AUTHORING.md#portable-text-operators-accents-and-explanatory-notation).
Use bare `µd` for an upright differential, for example
`µm{µv.v (t)=µfrac{µd µv.x,,µd t}}`. Write a space after `µd` before an
ordinary identifier; `µdx` would be a different command. This is a symbol,
not a callable derivative operation. AI retains its `\mathrm{d}` notation.
Mathematical µ-bearing equation-cell strings expand once. Write
`µmop{cos} (α)` with the separating space: an immediately attached `(α)` would
be a Python call trailer. Separate Unicode operators from command identifiers,
for example `µv.a ⋅ µv.b`.

Use `µpara` for `∥` and `µequi` for `⇔`; both have normal mathematical relation
spacing. `µpara[-sp]` / `µequi[-sp]` makes just that occurrence compact without
cancelling explicit spaces. Bare `µsp` equals three mu (LaTeX `\,`),
`µsp(2)` doubles it and `µsp(-1)` inserts a negative thin space. `-sp` alone
is a modifier, not a negative space. Use round call parentheses for factors,
not `µsp[3]`: for example `µsp(3) ⇒ µsp(3)`. Separate adjacent bare µ identifiers:

```text
µm{µequi µsp(2) µv.MN µpara µv.CS}
µm{µv.MN µpara[-sp] µv.CS}
```

AI preserves both relation identities and ignores all spacing choices. The
[notation reference](../../muvocab/docs/AUTHORING.md#portable-text-operators-accents-and-explanatory-notation)
specifies validation and renderer differences.

PyHTML and MuCompose both expose `--html-math-renderer=mathjax|typst-mathml`.
MathJax remains the default. Native MathML now covers static/reactive graphic
labels, measured layout, equation previews and Reader notebook execution, but
is not a replacement for every example below. Raw TeX and external modules
that require MathJax still need the default renderer. See the
[supported subset](../../pyhtml/docs/MATHEMATICS.md#experimental-native-mathml)
and `muweave_documents/math_renderer_comparison.muweave`. The switch affects
only HTML presentation, not PDF/AI or the document's HTML target identity.

Supply TeX-style formula source without `$` delimiters:

```text
Inline: µm{f(x)=3x^2}.

µblock.equation(r"F=ma", label="eq:force", tag="N2")

µm{µSet{x \in \mathbb{R},,x^2<2}}
µinterval{t_A,,t_E}
µinterval[o]{a,,b}
µinterval[lo]{a,,b}
µinterval[ro]{a,,b}
µp{3,,-2,,1}
```

`fence` and `Set` return fragments and do not enter math mode. An `interval`
is closed by default and is a complete inline-math value, like coordinate
points and vectors. Its optional modifiers `o`, `lo`, and `ro` produce
`(a,b)`, `(a,b]`, and `[a,b)`; at most one may be true. Explicit forms such as
`µinterval[ro=True]{a,,b}` and Python calls such as
`interval("a", "b", ro=True)` are equivalent.
Automatic delimiter sizing accepts `min_size=0..4` and `size_factor>=1.0`;
fixed `size=0..4` cannot be combined with `min_size`.

`forall` and `exists` are callable math fragments. Bare `µforall` and
`µexists` use the standard thin following space (3 mathematical mu, native
LaTeX `\,`). Configure one occurrence with keyword-only `space`: names are
`"none"` (0 mu), `"thin"` (3 mu), `"medium"` (4 mu), and `"thick"` (5 mu).
Explicit `"2.5mu"` strings and finite numeric mu values, including negative
values, are also valid:

```text
µm{µforall x \in A: x=x}
µblock.equation{µexists(space="4mu")y \in B: y>0}
µm{µforall(space=0)x \in A}
```

Direct HTML converts the default to an equivalent MathJax 3-mu kern. The API
does not currently accept positional variable/domain tuples; keep those terms
in the surrounding mathematics source.

Inline mathematics is unbreakable by default. For a genuinely long formula,
bare `µallowbreak` permits, but does not force, a break at one author-selected
safe boundary:

```text
µm{x_1,\dots,x_n, µallowbreak y_1,\dots,y_m}
```

Use it between self-contained phrases, normally after punctuation. Never put
it immediately before or after `=`, `+`, `-`, another relation, or a binary
operator. Direct HTML typesets the two sides independently, so such an
operator would lose its two-sided math-spacing context. A marker at the start
or end, or two adjacent markers, is invalid. `allowbreak` is a bare semantic
value, not a callable.

Use semantic quantities instead of hand-writing `\mathrm` and spacing:

```text
Die Strecke beträgt µqty{15,,m}.
Die Geschwindigkeit beträgt µqty{3,,m/s}.
Die Fläche hat die Einheit µunit{m^2}.
```

The brace quantity form has exactly two top-level string parts. Compact unit
syntax supports registered symbols, `*` or `·`, `/`, integral `^`/`**`
powers, and parentheses. Use ASCII `um` or `us` for the displayed `µm` or
`µs`. Canonical Python code composes `units` attributes with ordinary
operators. `per_mode` is `"fraction"` (default), `"slash"`, or `"power"`.
Unit algebra does not convert magnitudes, check dimensions, scale prefixes, or
rewrite products to named derived units. String magnitudes preserve exact
significant digits; scientific `e` notation is typeset as a power of ten.
PyHTML and PyTeX5 inherit the body font for upright unit symbols, color only
the unit through `theme.unit.foreground` (default `#00B300`), and keep the
value–unit gap unbreakable. See the exact symbol inventory and target behavior
in [MuVocab's mathematics reference](../../muvocab/docs/AUTHORING.md#physical-units-and-quantities).

Use structured rows for a system. Every row argument is one conceptual
column. A string containing one `µalc` marker creates one alignment boundary
inside that cell:

```text
µblock.equation(
    rows=(
        block.equation.row(r"v µalc = v_0 + at"),
        block.equation.row(r"s µalc = s_0 + v_0t + \frac12at^2"),
    ),
    label="eq:motion",
)
```

The canonical Python alternative is a two-string tuple, for example
`block.equation.row((r"v", r"= v_0 + at"))`. `µalc` is local structural
data, not an evaluated command. Ordinary columns default to centered
placement; `columns=("left", "center", ...)` controls them explicitly. An
ampersand remains exact TeX-style formula source and is never repurposed by
MuVocab; write `\&` for a visible ampersand.

The default `numbering="system"` applies outer `numbered`, `label`, and `tag`
metadata to the complete system and consumes at most one common block number.
For independently selected rows, use `numbering="rows"` and put `label`,
`tag`, or row-local `numbered` on `block.equation.row(...)`. Outer
`numbered=True` or `False` is then a default for every row. A row-local choice
wins; otherwise a label normally implies numbering and a tag alone does not.
Each numbered row consumes one ordinary common block number. Outer `label` and
`tag` are invalid in row mode. Structured systems use canonical Python syntax;
the brace form remains the one-formula form.

Use `row_gap="0.35em"` (or `0.35`, or a length such as `"0.15cm"`) on the
structured equation to control clearance between its native row boxes.
The default `None` preserves automatic spacing. Values must be nonnegative;
`0` adds no inter-row space. Em follows the current equation font size.
This does not change baselines inside formulas, font sizes, outer spacing,
or numbering; `.trim()` leaves the inner gap intact. There are exactly
`len(rows)-1` gaps, never extra ones at the top or bottom. Do not put it on a
raw formula body or an outer `item=`/`file=` request. HTML and PyTeX5 support
it; AI deliberately omits it; MyST rejects explicit values. See
[the complete contract](../../muvocab/docs/AUTHORING.md#equation-row-clearance).

### Blocks, numbers, tags, and solutions

For exams, use `block.exam_problem(item=N, points=..., exam=...)` with an
immutable `Exam(key, course, date, title="Prüfung", group=None, *, topics=(), duration_minutes=None, course_label=None)`. Points belong to the
placement, not the reusable item. Build the grading grid with
`block.exam_header(exam=..., problems=(...))` from those same task values.
An optional `exam_appearances` item part contains explicitly authored
`block.exam_appearance(exam=..., points=...)` records and is selected only by
`block.exam_appearances(item=N)`. Compilation never edits history. For the
complete template and target contract, see
[exams](../../muvocab/docs/AUTHORING.md#exams-and-occurrence-specific-points).
An exam's `ExamRubric(steps, duration_minutes=None, difficulty=None)` keeps
checkpoint scores and teacher estimates at the occurrence, not in the item.
Difficulty is `"leicht"`, `"mittel"`, or `"schwer"`. Place
`µgrading.time()` in the main item body so that it emits one private note such as
`Richtzeit: 4 min; Niveau: mittel`; publication and AI omit both estimates.
Leave either estimate unspecified when it is not needed. Scores remain
ordinary achievable-credit semantics through `µgrading("checkpoint")`.
`µgroup{...,,...}` selects lazy alternatives A, B, N, N2, ... from
`config["group"]`; `group(A=..., B=..., N2=...)` selects ordinary Python values.
Custom brace ordering uses `µgroup[groups=("A","B","N2")]{...,,...,,...}`.
Only selected content is exported to any backend or AI. The PDF exam template
uses `µ! mucompose --backends=latex --groups=A,B`; an explicit
`--config group=N2` builds only that retake. Its grading/name overlay lies
above the first header without affecting the document flow.
Add `µ! pytex5 --groups=A,B` for the same default pair when authors run
`pytex5 exam.muweave` directly; this selects complete-document mode as well.
Both commands emit `_A` and `_B` outputs even for identical task content.
An explicit `--config group=B` selects only B. In standalone PyTeX5 batch mode,
custom `--output`/`--pdf-output` values are bases: use `solutions.tex` to get
`solutions_A.pdf` and `solutions_B.pdf`, not an already suffixed base.
`--no-groups` disables standalone batching when an exact output path is needed.
`topics=("Vektoren", "Zweidimensionale Vektorgeometrie")` supplies the private
first-header margin note; do not duplicate it in the body. `duration_minutes=45`
is metadata, not printed time. `course_label="Mathe G2G"` is an explicit header
alias for the unchanged `course="Mathe G2029G"`; do not infer a class year.
AI retains all supplied exam metadata even when publish mode hides the private
topic projection. In PDF the exam height ratio includes the complete header
and footer on every page; grading/name/topic overlays do not consume body space.

Choice questions use `block.single_choice(question, options=((key, text), ...),
correct=key)` for exactly three options or `block.true_false(statement,
correct=bool, prerequisites=None)` for a truth judgement. Put each question in
its own canonical item, with an optional `explanation=` on the constructor;
do not duplicate its solution or assign exam points in the question item.
The configurable checkbox size defaults to 2.2 mm; the true/false statement
and checkbox area use configurable `widths=(4, 1)` with vertical centring;
`w` and `f` appear above their respective boxes. Question groups use compact
vertical spacing and instruct learners to select at most one answer per question.
Group question items using `µblock.multiple_choice(items=(77, 92, 93))`.
The group owns the configurable scoring policy and its printed instructions.
For an exam, place the group in a wrapper item and include that wrapper as one
`block.exam_problem`; its rubric uses the question ID strings as checkpoint
keys. The generated model solution prints their credit circles automatically.

Question order and three-option answer order are resolved once per build.
Stable question/option keys, not printed positions, identify learner input.
Hidden answer keys and explanations must not appear in learner HTML, AI or
scan metadata. In HTML, native radio inputs and a clear button persist the
selection through `.work`, including across a reordered rebuild. Full PDF,
HTML and AI projections are supported; MyST and low-level LaTeX fragment
expansion reject these typed blocks. See the
[complete choice API](../../muvocab/docs/AUTHORING.md#single-choice-truefalse-and-multiple-choice-groups).

For an individualized PDF stack, both frontends accept
`--exam-copies N`: `pytex5 exam.muweave --exam-copies 20 --publish` produces
`exam_gesamt.pdf` and `exam_gesamt.exam-batch.json`, alternating the configured
groups (A/B by default). MuCompose delegates to the same compiler. A bounded
retry avoids repeated measured choice permutations; no partial output is
published on failure. `--exam-seed SEED` makes the permutation reproducible
(ordinary single/group builds also accept it); never rebuild a matching
answer key with a fresh random seed. Keep the printed PDF with its manifest,
which records the actual per-copy seeds and page ranges. See
[PyTeX5 batch usage](../../pytex5/README.md) and
[scan metadata](../../pytex5/docs/SCAN_MANIFEST.md). This does not implement
copier OCR or the later batch scan-import workflow.

Portable numbered blocks use a common occurrence counter except for `problem`
and `exam_problem`, which share a dedicated Aufgabe counter. Both counters have
the same section prefix and reset level. Problems, exam problems, exercises,
and sample problems are numbered
by default; text, quote, equation, theorem, definition, remark, attention, and proof
blocks are not. A label normally implies numbering when `numbered` is omitted, while
explicit `numbered=False` wins. A tag is independent and can coexist with a
number.

A quotation uses `µblock.quote{...}`. It has an inset on both sides and no
automatic visible heading. It retains ordinary paragraphs, mathematics and
nested blocks; boldness is composed explicitly:

```text
µblock.quote{
µbold{Die Geschwindigkeit entspricht der Steigung im Ortsdiagramm.}
}
```

Use `block.quote(item=88)` or `block.quote(file="passage")` to quote reusable
content. For a numbered quote, use `block.quote(item=106, numbered=True)` and
refer to its implicit item identity with `ref("106")`. It shares the ordinary
block counter with equations. The default PDF/HTML designation is parenthesized
and centered at the right edge, in normal type independently of body emphasis;
references use `Zitat (number)` or `(number)` with `display="number"`.
Use `ref("106", kind_name="Aussage")` to change just this reference to
`Aussage (number)` while retaining the automatic number and target identity.
The option also works with other target kinds, excludes complete custom
`text`, and requires `auto` or `kind-number` display and an available number.
The quote body is centered to the left of its right-aligned designation, with
equal free space on both sides of the body. A long designation reduces the
wrapping width as needed. A multipage PDF quote shows it once
on its first fragment; MyST keeps a readable parenthesized prefix.
LaTeX, direct HTML and MyST use native quote containers; AI keeps the
quote role, nested content and emphasis without indentation. HTML and complete
structured PDF request `1.25` body-font units on each outer edge, independently
of blank lines; neighboring requests combine by the usual maximum rule.
The PDF template suppresses native quote-list skips, so `spacing(...)` and
explicit `gap` overrides remain authoritative. See the
[quotation reference](../../muvocab/docs/AUTHORING.md#quotations) for exact
validation and numbering rules.

Theorems use a green adaptive side label; definitions use the analogous red
``Definition`` / ``Def`` presentation; remarks use a yellow
``Bemerkung`` / ``Bem`` presentation. Attention blocks use an orange
``#FFBF80`` panel without a side label and always begin with bold ``Achtung!``;
do not repeat that prefix in the body. A proof starts with bold ``Beweis.`` and
ends with the Yin--Yang marker. If its final top-level body node is a
structured equation, direct HTML and complete PyTeX5 put the marker at that
equation's far right and retain its number or tag immediately to the left.

```text
µblock.problem[label="problem:one"]{
Berechne µm{2+2}.
}

µblock.solution[owner="problem:one", attached=True]{
Das Ergebnis ist µm{4}.
}
```

A solution is a separately placeable, separately referenceable companion. It
never consumes either automatic counter. A direct solution's owner is explicit
even when adjacent. A file-backed solution derives its owner from the file's
item identity when omitted. Without an explicit solution label, MuVocab derives
one from the owner and optional key. LaTeX/MyST add the portable `qedsymbol`
for ordinary owners. If the owner is an `exam_problem`, all visual targets
omit the solution heading and automatic completion marker, whether attached
or detached. Keep the solution and its item-owned response canvas: their
semantic identities and the AI owner relationship do not disappear with the
visible decoration. The same item used outside an exam retains normal styling.

For a terminal problem collection followed by its solutions, use one shared
canonical item sequence instead of maintaining two loops:

```text
µproblems_and_solutions(5, 6, level=1)
```

It creates an `Aufgaben` section containing items 5 and 6, then a `Lösungen`
section containing their `solution` parts in the same order, with portable page
breaks before both sections. The item identities, dedicated problem numbering,
provenance, and automatic bidirectional navigation remain those of ordinary
`block.problem(item=...)` and `block.solution(item=...)` occurrences. Item IDs
may not repeat. See the canonical
[MuVocab authoring reference](../../muvocab/docs/AUTHORING.md#assembling-terminal-problem-and-solution-sections)
for the exact contract.

### Structured reusable blocks

`35341.muweave`:

```text
µblock.source(default_kind="problem")

Berechne die Beschleunigung.

µblock.part("solution")

Setze die Werte in µm{a=\Delta v/\Delta t} ein.
```

Placement source using the canonical machine-wide item library:

```text
µblock.problem(item=35341)
µblock.solution(item=35341)
```

The numeric spelling resolves exactly `35341.muweave` below the configured
canonical item directory and creates targets `35341` and `35341/solution`
without repeating `owner`. A selected named part uses `item/kind` or
`item/kind/key`. An identity target does not itself request numbering. Typed
placement overrides an optional source default. `body`, `file=`, and `item=`
are mutually exclusive. By default only complete blank boundary lines are
removed; no `strip`, dedent, interior normalization, or newline conversion
occurs.

Use ordinary `file="motion"` for path-backed structured content outside the
canonical item namespace. It adds an omitted `.muweave` suffix and derives the
identity from the final filename. Never use `file=` as a substitute for a
canonical numeric item: `item=` deliberately has no source-local or
`.muvocab` fallback.

### Files and assets

For ordinary paths, `File(path)` searches, in order: the physical containing source directory;
nearest-first `.muvocab` directories below that directory and its ancestors;
the configured document root; explicit search directories; `MUVOCAB_PATH`
entries; and the working directory captured at build start. An absolute path
bypasses the search order.

Canonical resources use four independent build inputs:

- `MUWEAVE_ITEMS_DIR`, `--items-dir`, or `items_directory=` selects the one
  reusable-item directory. `block.*(item=N)` resolves exactly `N.muweave`
  there.
- `MUWEAVE_IMAGES_DIR`, `--images-dir`, or `images_directory=` selects the one
  shared-image directory. With it configured, `File("images/...")` maps only
  below that root.
- `MUWEAVE_INTERACTIVE_DIR`, `--interactive-dir`, or
  `interactive_directory=` selects the installed immutable `.muweb` library.
  `block.interactive("motion", ...)` resolves exactly `motion.muweb` there.
- `MUWEAVE_PERSONS_DIR`, `--persons-dir`, or `persons_directory=` selects the
  person catalogue. `person.Newton` resolves an explicit alias from the static
  metadata in `ID.muweave`; the filename stem is the stable named identity.

Explicit CLI or Python values override their environment defaults. The CLI
options are shared and inheritable through `.mu/arguments` and unqualified
initial `µ!` lines. None of these roots is related to `.muvocab`, and no
canonical lookup can be shadowed by a nearer file. Canonical item IDs are positive
decimal integers without padding; the library high-water mark prevents reuse
after deletion. Legacy `.itemsman` IDs are a separate namespace.

```text
µFile("shared/introduction.muweave").insert()
µFile("showcase.muweave").insert(lit=True)

µfigure(
    File("figures/trajectory.png").image(
        alt="Weg-Zeit-Diagramm",
        width=1,
    ),
    caption="Weg als Funktion der Zeit",
    label="fig:trajectory",
    width=0.8,
)
```

Normal insertion returns exact UTF-8 generated source for surrounding
expansion. `lit=True` protects the complete file from MuWeave expansion.
Images are never parsed as text. Direct LuaLaTeX uses the canonical source
path; lwarp and MyST publication allocate and copy target-local asset paths.
Direct PyHTML embeds the physical bytes in a native `figure` element when
`figure(...)` is used. Labeled figures receive source-order numbers; their
captions remain structured source and may contain nested commands. A
`display="name"` reference requires a single-paragraph caption. Internet URLs
are links only where a separate operation supports them; MuVocab does not
download remote images.

PyMyST standalone file output publishes registered assets beneath the page's
parent, while project mode publishes them beneath the project. Do not send a
document with registered local assets to stdout, because no stable companion
directory exists; the CLI rejects that combination.

### Named worksheet responses

Declare text answers and graphic insertion anchors in normal document flow:

```text
µresponse.text("reason", lines=4, label="Begründung", frame=False)

µresponse.graphic(
    "velocity-diagram",
    height=7,
    width=12,
    label="Geschwindigkeitsdiagramm",
)
```

Inside a structured item, the deferred canvas brace form adds one immutable
model-solution layer:

```text
µresponse.canvas[
    name="calculation",
    height="6cm",
    background="squared",
    underlay=g.axis(xmin=0, xmax=4, ymin=0, ymax=5, grid=True),
]{
Der erwartete Rechenweg darf µbold{beliebiges MuVocab} enthalten.

µblock.equation{v = \frac{\Delta x}{\Delta t}}
}
```

Text and graphic names are document-global state keys. A canvas name is local
to the structured item part containing it. For example, `calculation` inside
the solution part of `35341.muweave` becomes
`35341/solution/canvas/calculation`; no repeated item or owner argument is
needed. A canvas outside a structured item fails explicitly.

Labels are optional plain text. Text height is a positive number of lines;
graphic and canvas dimensions are positive centimetres (`height=7` and
`height="7cm"` are equivalent), and an omitted width fills the available body
width. Canvas `background` is `"blank"`, `"squared"`, `"lined"`, or
`"dotted"`; its authored height initially controls both viewport and paper.
PyHTML persists typed text, an embedded displayable graphic preview, and an
optional editable original file without changing declared geometry. It
connects item-qualified local-canvas hooks to the shared drawing palette, lets
the learner enlarge and scroll paper inside the fixed authored viewport, and
persists independent strokes and undo/redo history in `.work`. PyTeX5
emits corresponding printable areas. PyAI retains a canvas's semantic role and
qualified identity without visual dimensions or background. PyMyST rejects
all response values explicitly.

Canvas layer order is paper background, optional immutable `underlay`, model
solution, learner ink. PyHTML keeps the authored viewport fixed and enlarges
the inner paper to a visible solution's rendered height, so overflow remains
scrollable. PyTeX5 chooses the maximum of authored height, complete underlay
height, and measured model-solution height. With `--config ~solutions`, it
still measures the body in source order but discards the box instead of
shipping hidden text, links, or annotations. PyHTML omits the model layer;
PyAI omits its solution child. The direct-call `solution=` parameter accepts an
already evaluated string, but the registered brace form is canonical for
nested MuWeave source. Text and graphic responses have no brace form.

### Verbatim, index, and symbols

```text
Inline source: µverbatim.inline{µemph{Hallo}}

µverbatim.block{first line
  µemph{still source}}
```

The keyword index and symbol directory include only explicit selected
locations. Definitions are emphasized; additional roles are `explanation`,
`example`, and `related`.

```text
Eine µindex.term(
    "lineare Funktion",
    paths=index.pair("Funktion", "linear"),
) ...

µsymbols.mark(
    "linear-maps",
    notation=r"\mathcal L(A,B)",
    description="lineare Abbildungen von A nach B",
)

µindex.show(title="Stichwortverzeichnis")
µsymbols.show(title="Symbolverzeichnis")
```

## 6. Frontend workflows

### 6.1 Low-level preprocessing versus complete documents

All source suffixes are accepted as strict UTF-8; `.muweave` is the portable
convention, `.pytex` is appropriate for intentionally LaTeX-specific source,
and `.pymyst` for intentionally MyST-specific source.

Low-level commands only preprocess text:

```console
pytex5 fragment.pytex              # writes/replaces fragment.tex
pymyst fragment.pymyst             # writes/replaces fragment.md
```

Existing output files are atomically replaced. An explicit `--output` path is
used exactly. With input `-`, UTF-8 is read from stdin and output defaults to
stdout. A source map requires file output.

Complete-document mode wraps the author body in a trusted template:

```console
pytex5 lesson.muweave --document --title "Mechanik"
pymyst lesson.muweave --document --output lesson.md --title "Mechanik"
```

PyTeX5 complete mode runs LuaLaTeX by default; use `--no-pdf` for source only.
PyMyST needs `--project DIR` (or a positive build option) for a project; project
HTML is built by default and `--no-html` publishes without building. Its PDF
build is opt-in and experimental.

PyTeX5's built-in A4 complete template uses `body_width_ratio=0.76` and
`body_height_ratio=0.85`, centered on the paper. Set them with
`--body-width-ratio` and `--body-height-ratio`. Direct PyHTML uses the same
default width ratio on a fixed 52 rem surface, configured with
`--body-width-ratio`. Its `--body-height-ratio` controls only equal initial and
final whitespace calculated from a logical A4 height and defaults to `0.9`;
the screen surface stays continuous and unpaginated. MuCompose forwards both
common ratio spellings to its primary LaTeX and HTML targets when supplied.

For exact options, constraints, and Python APIs, read:

- [MuWeave CLI and API docs](../../muweave/docs/CLI.md)
- [MuDoc model foundation](../../mudoc/README.md)
- [MuVocab-to-MuDoc integration](../../muvocab/docs/DOCUMENT_MODEL.md)
- [PyTeX5 usage](../../pytex5/docs/USAGE.md)
- [PyMyST usage](../../pymyst/docs/USAGE.md)
- [PyHTML mathematics](../../pyhtml/docs/MATHEMATICS.md)
- [PyHTML offline worksheet](../../pyhtml/docs/WORKSHEET.md)
- [PyAI semantic bundle](../../pyai/docs/BUNDLE.md)
- [MuCompose CLI](../../mucompose/docs/CLI.md)

### 6.2 Templates and metadata

`--title`, `--subtitle`, repeated `--author`, `--language`, and `--date` are
shared. PyTeX5 and PyMyST own different default/custom template contracts; the
author body is inserted as retained parsed source rather than reparsed text.
Template expressions may therefore use MuWeave safely while preserving source
order and provenance.

`--vocabulary MODULE` selects a provider module (default `muvocab`). The
frontends call its `create_text_command_schema()` and target context factory.
Repeated `--setup FILE.py` is a PyTeX5 low-level extension mechanism, not the
portable MuVocab workflow.

### 6.3 Layered CLI configuration

For source `/course/grade/lesson.muweave`, settings are applied from shallower
to deeper ancestors, then initial source directives, then explicit CLI
arguments:

```text
/.mu/arguments
/course/.mu/arguments
/course/.mu/PROGRAM.arguments
/course/grade/.mu/arguments
/course/grade/.mu/PROGRAM.arguments
initial µ! directives
explicit command line
```

Here `PROGRAM` is `pyai`, `pytex5`, `pyhtml`, `pymyst`, or `mucompose`. Each nonblank
argument-file line is parsed with POSIX `shlex`; it is not a shell. Initial
directives must form a consecutive block starting at source offset 0:

```text
µ! --title "Mechanik"
µ! --config school=fms
µ! pyai --config tutoring=guided
µ! pytex5 --no-pdf
µ! pymyst --no-html
```

The resolver retains directive source coordinates and passes a body start
offset to MuWeave, so diagnostics and source maps still refer to the physical
original file. Exact inheritable options and scope-placement rules are in each
CLI guide. In particular, MuCompose shared settings belong in
`.mu/arguments` or unqualified directives, while orchestration/target-qualified
settings belong in `.mu/mucompose.arguments` or `µ! mucompose ...`.

`--config NAME` means `True`, `--config ~NAME` means `False`, and
`--config NAME=TEXT` stores exact text. Later assignments of the same key win.
In document source, `µconfig.set(...)` mutates the same context state for later
expressions only. `--publish`/`--no-publish` is a separate inheritable boolean;
publication mode cannot be changed by source configuration.

## 7. Python APIs

### 7.1 Expand a string with MuVocab

Do not use a bare `PytexContext()`, `PymystContext()`, `PyhtmlContext()`, or
`PyaiContext()` when source expects MuVocab: those constructors install only
core/frontend facilities. Create one shared schema and ask MuVocab for the
target context:

```python
import muvocab
import pytex5

schema = muvocab.create_text_command_schema()
context = muvocab.create_latex_context(schema)
result = pytex5.expand_string(
    'Das ist µemph{wichtig}.',
    context,
    source_name="example.muweave",
    output_name="example.tex",
)
```

### 7.2 Parse once, expand independently

```python
import muweave
import muvocab
import pymyst
import pytex5

source = 'µsection(title="Kinematik")\nDie Funktion µm{f(x)=x^2}.'
schema = muvocab.create_text_command_schema()
parsed = muweave.parse_string(
    source,
    source_name="chapter.muweave",
    text_command_schema=schema,
)

latex = pytex5.expand_parsed(
    parsed,
    muvocab.create_latex_context(schema),
    output_name="chapter.tex",
)
myst = pymyst.expand_parsed(
    parsed,
    muvocab.create_myst_context(schema),
    output_name="chapter.md",
)
```

`ParsedSource` contains immutable source structure, AST metadata, and compiled
expressions, but no evaluated objects or target state. Each expansion evaluates
commands once in its own fresh context. Generated command strings remain
target-dependent and are parsed only when produced. `ParsedSourceInsertion`
inserts retained parsed bodies into parsed templates without rescanning.

MuCompose does not expose a document-composition Python API. Automate it via
its CLI/subprocess boundary, or call the independent frontend APIs yourself.

### 7.3 Build the optional structured document model

The explicit structured path evaluates with no target renderer and then lets
MuVocab classify its concrete values:

```python
typed = muweave.expand_parsed_typed(
    parsed,
    muvocab.create_document_context(schema),
)
document = muvocab.document_from_expansion(
    typed,
    text_command_schema=schema,
)
prepared = muvocab.prepare_document(document)
```

This preserves the same `ExpansionValue` and nested `TypedExpansion`
occurrences. Expanded and deferred registered-command bodies are parsed
recursively. Deferred MuVocab blocks retain outer-first evaluation; raw
verbatim bodies remain explicit opaque boundaries. `prepared` adds immutable
target-neutral section/block placements, local targets, and resolved forward
references without a LaTeX, MyST, or HTML context. This path is not yet
connected to a frontend.

### 7.4 Complete documents and projects

Both frontends expose `build_document(parsed_body, context, ...)`. PyMyST also
exposes `build_project`, `publish_document`, and `publish_project`; PyTeX5
exposes `build_pdf` and an experimental `pytex5.lwarp` module. Build functions
run external tools; expansion functions do not.

### 7.5 Tracing and source maps

Pass an `ExpansionTrace` to an expansion and query exact output offsets,
positions, lines, or ranges:

```python
from muweave import ExpansionSourceMap, ExpansionTrace

trace = ExpansionTrace()
output = pytex5.expand_parsed(parsed, context, trace=trace)
segment = trace.lookup_offset(10)
segments = trace.lookup_range(10, 30)
portable_map = ExpansionSourceMap.from_trace(trace)
serialized = portable_map.to_json()
```

Provenance distinguishes copied source, command output, renderer output,
literal release, deferred output, and composed sources. A generated character
maps to its immediate output offset and a parent chain back to the originating
command; range queries return every intersecting segment. CLI `--source-map`
writes `OUTPUT.muweave-map.json`. PyTeX5 can map supported LuaLaTeX log
locations back through that file.

## 8. Errors and diagnosis

The main phases are `MuWeaveParseError`, `MuWeaveEvaluationError`,
`MuWeaveRenderError`, `MuWeaveDeferredError`, and `MuWeaveReferenceError`.
Messages include the source name, one-based line/column, source excerpt, and a
caret span. `--debug` additionally exposes the Python traceback.

Typical distinctions:

```text
µunknown_function()       # valid syntax -> evaluation error
µmake_items(              # begun trailer -> parse error
µ.                        # impossible start -> literal text
µblock.unknown{body}      # unregistered brace form -> parse error
```

When an external compiler reports a generated-output location, use the source
map rather than assuming that generated line equals author-source line. For
LuaLaTeX, use `pytex5-diagnose` as documented in
[LUALATEX_DIAGNOSTICS.md](../../pytex5/docs/LUALATEX_DIAGNOSTICS.md).

`muweave-lsp` reports live parser diagnostics and semantic highlighting from
the same non-evaluating source-analysis model. It reflows complete documents
recursively or exact prose selections while preserving executable syntax and
protected bodies. It deliberately does not flag a syntactically valid unknown
name, because available names are dynamic and checking one would require
runtime context or evaluation. Its exact editor protocol is documented in
[PROTOCOL.md](../../muweave-lsp/docs/PROTOCOL.md).

## 9. Full workflows

### Reusable people and independent profiles

Configure `--persons-dir PATH` or `MUWEAVE_PERSONS_DIR`. Use `µperson.Newton`
for a name with an HTML information card, `µperson.Newton(footnote=True)` for
a PDF short-biography footnote, and `µblock.person(person.Newton)` for a full
profile. An independent page uses that placement in a small `.muweave`
wrapper, then ordinary PyHTML export. Person IDs are named slugs, not numeric
items. A source has literal `µperson.source(...)` metadata, a short inline
biography, and an optional `µperson.part("biography")` full body. Preserve both
separately when editing. Read the exact
[person contract](../../muvocab/docs/AUTHORING.md#people-and-reusable-biographies)
before adding aliases, links or portraits. Complete PDF, direct HTML and AI
are supported; legacy LaTeX fragments and MyST fail explicitly.

### Portable source, both default MuCompose targets

```console
mucompose course.muweave \
  --title "Mathematik und Physik" \
  --author "Ada Beispiel" \
  --language de-CH
```

### Direct offline HTML

```console
pyhtml course.muweave \
  --title "Mathematik und Physik" \
  --author "Ada Beispiel" \
  --language de-CH
```

### Layout-free AI bundle

```console
pyai course.muweave \
  --title "Mathematik und Physik" \
  --author "Ada Beispiel" \
  --language de-CH
```

### Direct HTML with embedded AI context

```console
pyhtml course.muweave --language de-CH
```

### LaTeX only, source without PDF

```console
pytex5 course.muweave --document --no-pdf --output course.tex
```

### MyST project, publish without an external build

```console
pymyst course.muweave --project course.myst --no-html
```

### Experimental lwarp project without building

```console
pytex5 course.muweave \
  --html-project course_lwarp \
  --no-html \
  --no-pdf
```

Both negative switches are required for source-only lwarp publication because
complete PyTeX5 document mode otherwise enables its normal PDF build. Positive
`--html` without an explicit project derives `course_lwarp/`; every derivation
appends a fresh `_lwarp`. `--output` is invalid in lwarp mode.

## 10. Quick reference and authoring checklist

| Need | Write |
| --- | --- |
| literal marker | `\µ` |
| root operator expression | `µexpr(a + b)` |
| state-changing statements | `µexec("name = value")` |
| protect generated command text | `µlit{...}` |
| display source literally | `µverbatim.inline{...}` or `µverbatim.block{...}` |
| source beside its once-expanded result | `µshowcase{...}`; add `[editable=True, session="stable:name"]` only for a native Reader notebook cell |
| include genuinely target-specific source | `µbackend[include="html"]{...}` or `µbackend[exclude="latex"]{...}` |
| inline/display math | `µm{...}` / `µblock.equation{...}` |
| physical quantity/unit | `µqty{value,,unit}` / `µunit{unit}` |
| conditional model solution | `µsolution{...}`; use `hidden="reserve"` to retain its box when `--config ~solutions` |
| learner blank | `µblank[u, padding=1]{expected content}`; visible with solutions, hidden with the same box under `--config ~solutions`; use `-u` to state no underline explicitly |
| invisible layout exemplar | `µphantom{content}` |
| optional inline-math break | bare `µallowbreak` between safe formula phrases |
| aligned equation system | `µblock.equation(rows=(block.equation.row(...), ...))` |
| display formula following prose without an extra paragraph boundary | place `µblock.equation{...}` on the next physical line without a blank line |
| portable heading | `µsection(title=..., level=...)` |
| portable reference | `µref("stable:key")` |
| person mention / PDF short biography | `µperson.Newton` / `µperson.Newton(footnote=True)`; `text="Newtons"` changes the spelling only |
| complete reusable person profile | `µblock.person(person.Newton)`; configure `--persons-dir`; no numeric item ID |
| portable tooltip | `µtooltip[plain explanation]{visible content}` |
| exact foreground | `µcolor[COLOR]{visible content}`, with a standard name or `#RRGGBB` |
| block spacing request | `µspacing(block_value, before=..., after=...)` |
| explicit boundary change | standalone `µgap.set(...)`, `.add(...)`, or `.factor(...)` |
| theorem | `µblock.theorem[title="..."]{nested block content}` |
| definition | `µblock.definition[title="..."]{nested block content}` |
| remark | `µblock.remark[title="..."]{nested block content}` |
| attention warning | `µblock.attention{warning body without an explicit "Achtung!"}` |
| proof | `µblock.proof{argument ending in text or a display equation}` |
| quotation with bold text | `µblock.quote{µbold{quoted passage}}` |
| educational task block | `µblock.problem{...}`, `.exercise`, or `.sample_problem` |
| ordered entries or subproblems | `µlists.enumerated[keys=(...)]{first,,second}`; add `layout="grid", columns=N` only for presentation |
| canonical reusable task and solution | `µblock.sample_problem(item=35341)` and `µblock.solution(item=35341)` |
| native applet with a print description and clickable margin QR | `µblock.applet(item=88)`; configure `applet.base_url` and define a `description` part in the item; PDF adds no text link |
| synchronized terminal tasks and solutions | `µproblems_and_solutions(5, 6, level=1)` |
| ordinary path-backed solution | `µblock.solution(file="motion")` |
| mathematical overline | `µol{AB}` or `µol("AB")`; compose inside `µm{µol{MN} ∥ µol{BC}}` |
| horizontal width split | `µlayout.columns[widths=(2, 3)]{left,,right}` |
| stacked semantic diagrams | `µlayout.rows(first_axis, second_axis, gap=0.8)` with a shared `g.axis_layout(...)` |
| differential notation / symbolic derivative | `µfrac{µd x,,µd t}` / `Term("t**2").diff("t")` |
| text flowing around an image | `µlayout.wrap[width=0.4]{body,,µFile("image.png").image(alt="...", width=1)}` |
| QR-coded external link | `Open µqrcode("https://example.org", "this link")`; use `µqrcode("https://example.org", placement="inline")` inside explicit layouts |
| offline interactive block | `µblock.interactive("motion", instance="kinematics-motion-1", activity="piecewise_uniform", presentation="compact", height="11cm")`; keep the instance stable across compatible worksheet revisions |
| generated coordinate system | `µg.axis(-4, 6, -3, 5).add(g.arrow((-3,-2), (5,3)), g.vector(v(2,1), name="a"), g.point((0,0)))` |
| labelled point | `µg.axis(-1,3,-1,3).add(g.point((1,2), label=p.A, label_angle=135))` |
| draggable point | Inside `g.interactive` with slider parameters `x`, `y`: `g.axis(-5,5,-4,4).add(g.point((x,y), draggable=True))`; constants constrain movement to one dimension |
| calibrated portable angle marker | `µg.axis(-1, 4, -1, 3, x="", y="").add(g.line((0,0),(3,0)), g.line((0,0),(2,2)), g.angle((0,0), (3,0), v(2,2), math_label("α", latex=r"\alpha")))` |
| circle or circular arc | `µg.axis(-3,3,-3,3,aspect="equal").add(g.arc((0,0),2,start_angle=30,sweep=-270,name="s"))`; use `sweep=360` for a full circle |
| smooth curve through given points | `µg.axis(0,7,0,4.5).add(g.curve((0,1),(1,.5),(3,1),(4,2),(5,3.5),(7,4)))`; Hobby interpolation with shared cubic controls for HTML, LaTeX, and AI |
| scalar side name | `g.line((0,0),(3,0),name="a")`; a vector name requires `name=v.a` or `name="µv.a"` explicitly |
| source-ordered graphic scale | `µg.scale(1.5)` for later graphics, then `µg.reset()` |
| projected 3D scene | `µg.scene3d(g.camera.orthographic((6,-8,5))).add(g.vector(v(1,1,1), name="a"), g.point((0,0,0)))` |
| scalar term, point, or vector | `µTerm("a**2")`, `µp{1,,2}`, or `µv.v[1].x` |
| insert expandable source | `µFile("part.muweave").insert()` |
| insert protected source | `µFile("part.muweave").insert(lit=True)` |
| canonical shared image | `File("images/image.png").image(alt="...", width=1)` with `--images-dir` configured |
| named text answer | `µresponse.text("stable-name", lines=4, label="...", frame=False)` |
| named graphic answer | `µresponse.graphic("stable-name", height=7, width=12, label="...")` |
| item-owned handwriting area | inside a structured item: `µresponse.canvas("calculation", height=7, background="squared")` |
| handwriting area with model solution | `µresponse.canvas[name="calculation", height=7]{nested solution body}` inside a structured item |
| keyword/symbol directory | explicit `index.term` / `symbols.mark`, then `.show()` |
| both default outputs (PDF and direct HTML) | `mucompose SOURCE.muweave` |
| semantic model input only | `mucompose SOURCE.muweave --backends=ai` |
| direct HTML carrying matching semantic context | `mucompose SOURCE.muweave --backends=html` |

Before emitting a document:

- Use only names present in the installed-author-namespace table or explicitly
  supplied by a selected vocabulary/setup module.
- Prefer semantic MuVocab operations. Keep target-specific LaTeX, MyST, or HTML
  source out of unguarded portable content; wrap an unavoidable fragment in an
  explicit `backend` gate. Inside `µm{...}` and `µblock.equation{...}`,
  portable TeX-style mathematics commands are valid.
- Use Python quoting for canonical calls; brace bodies are strings, not Python
  literal syntax.
- Use `qty` and `unit` rather than hand-written target spacing or `\mathrm`
  for physical units.
- Use `expr` for a root operator expression and keep outer trailers adjacent.
- Assign stable explicit labels to independently referenced blocks unless a
  canonical structured-item identity already provides the target.
- Give referenced list entries semantic `keys`; address an item-owned entry as
  `ITEM/entry/KEY`, and do not derive identity from grid position.
- Keep solutions linked to an explicit owner even when physically adjacent.
- Put block structural declarations on complete physical lines.
- Use `lit` for expansion protection and `verbatim` for visible source; they
  solve different problems.
- Give every image useful plain-text alternative text.
- Give every response a stable name unique across text and graphic fields.
- Remember that source is trusted executable Python.
- Keep explicit PDF destinations distinct; the implicit MyST PDF already gains
  a fresh `_myst` marker.
- Consult [AUTHORING.md](../../muvocab/docs/AUTHORING.md) for the exact operation contract before
  using an unfamiliar option.
