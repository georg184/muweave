"""Configure the human-facing MuWeave Suite Sphinx documentation."""

import sys
import warnings
from pathlib import Path

from sphinx.deprecation import RemovedInSphinx11Warning

SUITE_ROOT: Path = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SUITE_ROOT / "src"))

import muweave_suite

warnings.filterwarnings(
    "ignore",
    category=RemovedInSphinx11Warning,
    module=r"sphinx\.ext\.napoleon\.docstring",
)

project: str = "MuWeave Suite"
author: str = "MuWeave contributors"
release: str = muweave_suite.__version__

extensions: list[str] = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.viewcode",
]
templates_path: list[str] = []
exclude_patterns: list[str] = []
primary_domain: str = "py"

autodoc_typehints: str = "description"
autodoc_member_order: str = "bysource"
napoleon_google_docstring: bool = True
napoleon_numpy_docstring: bool = False

html_theme: str = "alabaster"
html_static_path: list[str] = []
html_title: str = "MuWeave Suite documentation"
