# MuWeb module bridge
Audience: interactive-project developers and PyHTML maintainers

The packaged bridge is the only supported persistence connection between a
supported embedded application and its host. Include the exact source
from `muweb bridge` or `muweb.module_bridge_source()` in `embed.html`.
Do not copy and independently modify its protocol code inside every project.

The host starts the module Blob URL with two fragment parameters:

```text
#muweave-instance=uniform-motion-1&muweave-channel=<random-channel>
```

The stable instance identifies learner state. The host-generated channel
separates concurrent occurrences. Each message envelope contains:

```json
{
  "format": "muweave-interactive-bridge",
  "protocolVersion": 1,
  "instance": "uniform-motion-1",
  "channel": "...",
  "sequence": 0,
  "kind": "ready",
  "payload": {}
}
```

The child accepts messages only from `window.parent`, with exact format,
version, instance, channel, and a strictly increasing integer sequence. Opaque
sandbox origins require `postMessage(..., "*")`; source-window and channel
validation provide the occurrence boundary.

`window.MuWeaveModuleBridge` provides:

- `subscribeState(listener)` and `getState()` for restored host state;
- `updateState(value)` to publish a complete JSON-compatible state value;
- `setSnapshotProvider(provider)` for state held in a project model;
- `registerStateMigration(fromVersion, migration)` to declare one synchronous
  `fromVersion -> fromVersion + 1` learner-state upgrade before bridge
  readiness;
- `reportPreferredHeight(px)`, `reportProgress(value)`, and
  `reportResult(value)` for structured host integration;
- `reportError(message)` for recoverable project diagnostics; and
- `isInitialized()` / `isEnabled()` for explicit UI state;
- `getTypography()` for the host's detached normal-typography snapshot;
- `getModuleContext()` for the selected occurrence, activity, and view; and
- `fontSizePt(step=0)` for an absolute signed font-size step in points.

The host sends `init`, `migrate-state`, `request-snapshot`, and
`host-disabled`. The child sends `ready`, `migration-result`, `state-changed`,
`snapshot`, `preferred-height`, `progress`, `result`, and `error`. State values
contain only null, booleans, finite numbers, strings, arrays, and plain
string-keyed objects; cycles and richer JavaScript objects are errors.

## Host typography

The host's `init` payload may contain this validated presentation snapshot:

```json
{
  "typography": {
    "fontSizePt": 10,
    "lineHeight": 1.35,
    "scaleFactor": 1.25
  }
}
```

Older hosts may omit it; the bridge then uses the values shown above. The font
size and line height are finite and positive, while the geometric scale factor
is finite and at least one. After accepting `init`, the bridge retains an
immutable internal snapshot and sets these CSS custom properties on the module
document root:

```text
--muweave-body-font-size: 10pt
--muweave-line-height: 1.35
--muweave-size-factor: 1.25
```

Use `var(--muweave-body-font-size, 10pt)` and
`var(--muweave-line-height, 1.35)` for ordinary application text.
`getTypography()` returns a detached object with the three numeric fields.
`fontSizePt(step)` requires a signed finite number, calculates
`fontSizePt * scaleFactor ** step`, and rounds the result to the nearest
`0.001 pt`, matching MuVocab's `µsize` policy. Call it after initialization
for headings or other typography steps, including intermediate values such as
`fontSizePt(1.57)`. Typography is host presentation, not learner state: modules
must not persist it, migrate it, or echo it through `updateState`.

## Activity and presentation

Current hosts also include this validated occurrence snapshot in `init`:

```json
{
  "module": {
    "id": "motion",
    "version": "20260829.3",
    "stateVersion": 1,
    "instance": "kinematics-motion-1",
    "activity": "piecewise_uniform",
    "presentation": "compact"
  }
}
```

`getModuleContext()` returns a detached copy, or `null` with an older host.
The project uses `activity` to select a manifest-declared activity inside the
single packaged application. It uses `presentation` only to choose between:

- `compact`: activity controls and feedback without standalone introduction,
  global title, navigation, or other surrounding page chrome;
- `full`: the complete independently usable application.

Activity is part of the host's learner-state compatibility record. A producer
must not reinterpret one activity's saved state as another activity's state.
Presentation is deliberately absent from that record: switching between the
compact in-document view and the full tab view does not create a new learner
identity or invalidate compatible work.

## State migrations

Register every supported adjacent migration while the entry document is still
loading:

```javascript
const bridge = window.MuWeaveModuleBridge;

bridge.registerStateMigration(1, (oldState) => {
  if (oldState === null || typeof oldState !== "object") {
    throw new TypeError("state version 1 must be an object");
  }
  return {
    ...oldState,
    hintsUsed: Number.isSafeInteger(oldState.hintsUsed) ? oldState.hintsUsed : 0,
  };
});

bridge.registerStateMigration(2, (oldState) => {
  if (!Number.isSafeInteger(oldState.hintsUsed) || oldState.hintsUsed < 0) {
    throw new TypeError("state version 2 has invalid hintsUsed");
  }
  return {
    ...oldState,
    view: typeof oldState.view === "string" ? oldState.view : "task",
  };
});
```

The bridge announces the registered source versions in `ready`. Registration
after readiness and duplicate source versions are errors. A handler is
synchronous, deterministic, offline, and side-effect free. It receives a
detached JSON copy, validates the complete source schema, and returns a
complete value valid for exactly the next integer schema. Returning a Promise
or richer JavaScript object fails JSON validation.

For a stored schema 1 and current schema 3, PyHTML requests 1 -> 2 and then
2 -> 3. It validates the protocol envelope and JSON shape after each result.
Only the module can validate domain invariants, so each handler must throw on
invalid input or output. The application receives no `init` and cannot call
`updateState` during this transaction. PyHTML keeps the original record
untouched, persists only the final schema-3 record, and then sends `init` with
that final value.

If any adjacent handler is absent, throws, returns invalid data, times out, or
if the stored schema is newer than the module, PyHTML preserves the exact old
record in quarantine and initializes a visibly fresh state. An ordinary
producer release change with the same `state_version` needs no migration.

After `host-disabled`, `updateState` throws. An application must then disable
state-changing controls visibly rather than accumulate unsavable learner work.
The bridge never uses browser storage as an embedded-mode authority.
