"""Trusted setup for the complete executable pytex5 example."""

from dataclasses import dataclass
from typing import cast

from pytex5 import PytexContext

context: PytexContext = cast(PytexContext, globals()["context"])


@context.commands.command(brace_argument="text")
def emph(text: str) -> str:
    """Wrap one processed text body in LaTeX emphasis.

    Args:
        text: Exact recursively processed body text.

    Returns:
        LaTeX emphasis source.
    """

    return rf"\emph{{{text}}}"


@context.commands.command(brace_argument="text")
def strong(text: str) -> str:
    """Wrap one processed text body in bold LaTeX text.

    Args:
        text: Exact recursively processed body text.

    Returns:
        Bold LaTeX source.
    """

    return rf"\textbf{{{text}}}"


@dataclass(frozen=True, slots=True)
class Task:
    """Represent one task that owns its final pytex5 rendering."""

    title: str

    def __pytex__(self, context: PytexContext) -> str:
        """Render this task as trusted LaTeX source.

        Args:
            context: Active document context.

        Returns:
            Bold task title.
        """

        return rf"\textbf{{{self.title}}}"


def make_tasks(*, topic: str) -> list[Task]:
    """Create the deterministic task collection used by the document.

    Args:
        topic: Requested example topic.

    Returns:
        Six task objects supporting indexing and attribute access.

    Raises:
        ValueError: If the complete example requests another topic.
    """

    if topic != "vectors":
        raise ValueError("The complete example only defines vector tasks.")
    titles = (
        "Vektoren-Aufgabe 1",
        "Vektoren-Aufgabe 2",
        "Vektoren-Aufgabe 3",
        "Vektoren-Aufgabe 4",
        "Vektoren-Aufgabe 5",
        "Vektoren-Aufgabe 6",
    )
    return [Task(title) for title in titles]


class TikzCommands:
    """Provide small stateful TikZ helpers for the complete example."""

    def __init__(self) -> None:
        """Initialize the documented unit scale."""

        self.scale_factor: float = 1.0

    def reset(self) -> None:
        """Reset mutable TikZ state without producing document text."""

        self.scale_factor = 1.0

    def scale(self, value: int | float) -> None:
        """Set a validated positive scale without producing document text.

        Args:
            value: Positive drawing scale.

        Raises:
            ValueError: If the scale is not positive.
        """

        if value <= 0:
            raise ValueError("The TikZ scale must be positive.")
        self.scale_factor = float(value)

    def axis(
        self,
        *,
        xmin: int,
        xmax: int,
        width: int,
        height: int,
        grid: bool,
        x: str,
        y: str,
    ) -> str:
        """Validate the example axis and return its fixed TikZ representation.

        Args:
            xmin: Smallest displayed x-coordinate.
            xmax: Largest displayed x-coordinate.
            width: Requested drawing width.
            height: Requested drawing height.
            grid: Whether to include the help grid.
            x: LaTeX x-axis label.
            y: LaTeX y-axis label.

        Returns:
            Complete three-line TikZ axis source.

        Raises:
            ValueError: If arguments differ from this documented example.
        """

        configuration = (xmin, xmax, width, height, grid, x, y, self.scale_factor)
        expected = (3, 7, 5, 3, True, "$t$", "$v$", 1.0)
        if configuration != expected:
            raise ValueError("Unexpected axis configuration in complete example.")
        return "\n".join(
            (
                r"\draw[step=1cm,gray!30] (3,0) grid (7,3);",
                r"\draw[->] (3,0) -- (7,0) node[right] {$t$};",
                r"\draw[->] (3,0) -- (3,3) node[above] {$v$};",
            )
        )

    def plot(self, *, points: list[tuple[int, int]]) -> str:
        """Validate and render the fixed point series from the example.

        Args:
            points: Ordered integer-coordinate points.

        Returns:
            One TikZ plot command.

        Raises:
            ValueError: If the documented points are changed unexpectedly.
        """

        if points != [(3, 2), (4, 5), (5, 8)]:
            raise ValueError("Unexpected points in complete example.")
        return r"\draw[thick] plot coordinates {(3,2) (4,5) (5,8)};"


tikz: TikzCommands = TikzCommands()
a: int = 4
b: int = 3
result_a: str = "Variante A"
result_b: str = "Variante B"
use_a: bool = False
