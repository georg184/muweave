"""Expand one parsed MuWeave source independently for two targets."""

from pathlib import Path

import muvocab
import muweave
import pymyst
import pytex5

source_path: Path = Path(__file__).with_name("minimal.muweave")
source: str = source_path.read_text(encoding="utf-8")
schema: muweave.TextCommandSchema = muvocab.create_text_command_schema()
parsed: muweave.ParsedSource = muweave.parse_string(
    source,
    source_name=str(source_path),
    text_command_schema=schema,
)

latex_context: pytex5.PytexContext = muvocab.create_latex_context(schema)
myst_context: pymyst.PymystContext = muvocab.create_myst_context(schema)

latex: str = pytex5.expand_parsed(
    parsed,
    latex_context,
    output_name="minimal.tex",
)
myst: str = pymyst.expand_parsed(
    parsed,
    myst_context,
    output_name="minimal.md",
)

assert r"\section*{Kinematik}" in latex
assert "# Kinematik" in myst
