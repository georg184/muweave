# Typed expansion

Audience: backend developers and document-layer implementers

`expand_parsed_typed` evaluates trusted MuWeave source without flattening
portable semantic values into LaTeX, MyST, HTML, or generic strings. It is an
explicit alternative output boundary over an existing `ParsedSource`:

```python
from dataclasses import dataclass

from muweave import (
    ExpansionText,
    ExpansionValue,
    MuWeaveContext,
    SemanticValue,
    expand_parsed_typed,
    parse_string,
)


@dataclass(frozen=True, slots=True)
class Heading(SemanticValue):
    title: str


parsed = parse_string('Before µHeading("Motion") after')
context = MuWeaveContext({"Heading": Heading})
expanded = expand_parsed_typed(parsed, context, output_name="chapter.tree")

assert isinstance(expanded.parts[0], ExpansionText)
assert isinstance(expanded.parts[1], ExpansionValue)
assert expanded.parts[1].value == Heading("Motion")
assert isinstance(expanded.parts[2], ExpansionText)
```

MuWeave still executes unrestricted Python. Typed output changes neither the
trust boundary nor evaluation semantics.

## Public model

```python
ExpansionText(
    text: str,
    provenance: Provenance,
    exact: bool,
    protected: bool = False,
)

ExpansionValue(
    value: object,
    provenance: Provenance,
    command_name: str | None,
    bodies: tuple[TypedExpansion, ...],
    source_metadata: Mapping[str, object],
    configuration: Mapping[str, object] | None = None,
    *,
    state: OccurrenceState | None = None,
    arguments: Mapping[str, TypedExpansion] | None = None,
)

OccurrenceState(
    configuration: Mapping[str, object] = {},
    sections: Mapping[str, object] = {},
)

TypedExpansion(
    parts: tuple[ExpansionText | ExpansionValue, ...],
)
```

All records are immutable. `arguments`, `source_metadata`, state
configuration, and the top-level section mapping are copied into read-only
mappings. Real typed expansion always supplies the complete
`ExpansionValue.state`. Its
`configuration` property is the exact compatibility view
`value.state.configuration`; the optional constructor argument exists for
tests and other callers constructing configuration-only synthetic values.

An occurrence state contains every ambient expansion parameter registered in
the one `MuWeaveContext` timeline. It is not a view of the context's final
mutable state. A deferred outer command captures its snapshot before its body
runs, values inside that body see changes made there, and a late deferred or
reference result restores the snapshot of its original source occurrence.
Empty text never creates an `ExpansionText`; an entirely empty result is
`TypedExpansion(())`.

`ExpansionText.clip(start_offset, end_offset)` returns one nonempty relative
subrange. It clips an exact source span to the same character range, while
conservative generated output retains its whole producer provenance. A
downstream structural parser therefore does not need to reproduce MuWeave's
source-position rules when it separates paragraphs or other text regions.

Only `expand_parsed_typed(parsed, context=None, *, output_name="<typed>")` is
provided. Call `parse_string` explicitly when starting from text. This keeps
parsing reusable and makes the structured path visible at the call site.

## Value policy

The processor handles final evaluated objects in this order:

1. `None` contributes no part.
2. A `str` follows normal transitive generated-source expansion.
3. `SemanticValue`, core `ReferenceTarget`, and resolved core `Reference`
   become `ExpansionValue` without target rendering.
4. A direct `TypedValueInsertion`, or a value handled by a context-registered
   typed adapter, retains its replacement semantic value and expands its
   opted-in inputs as positional bodies and/or named structured arguments at
   the same occurrence.
5. Every other object uses normal `render_muweave` behavior. Its resulting
   string remains eligible for transitive generated-source expansion.
6. `ParsedSourceInsertion` expands its retained parse directly and preserves
   the inserted source identity.

Context renderers for semantic values are intentionally bypassed. Consequently
the same parsed source can be expanded into a target-neutral value tree even
when the supplied context also has LaTeX or MyST renderers. The string APIs
continue to invoke those renderers normally.

## Registered text-command bodies

An `ExpansionValue` produced by a registered text command records the exact
registered name in `command_name`. A canonical Python expression has
`command_name is None`.

Every registered brace body is retained in order under `bodies`. An expanded
body is recursively evaluated before its handler. A deferred body reaches its
outer handler as exact source, then becomes its own recursively evaluated
`TypedExpansion`; this preserves outer-first semantic state without reparsing
renderer output. A raw body is one or more exact `ExpansionText` parts with
`protected=True`; commands that merely look active inside it are not parsed.

A deferred handler may return `DeferredBodySelection` instead of a semantic
value. The selected body expansions are then spliced directly into the
surrounding `TypedExpansion`, in source order, and no outer `ExpansionValue` is
created. An empty selection performs no nested evaluation. This generic
control has no backend identity; a vocabulary supplies the context-local
selection policy.

The normal handler is still called exactly once with string-compatible body
arguments. A deferred typed command must return a retained semantic value so
its later body tree has an explicit owner. The returned object remains in
`ExpansionValue.value`, but `ExpansionValue.bodies` is the authoritative
representation of structured brace content. A document adapter must consume
the body tree rather than parse a string-valued field of the object again.

MuWeave carries nested values through ordinary string interpolation using
private operation-local slots. They are not output text or a persistence
format. A handler that destructively removes, duplicates, corrupts, or mixes a
slot with another operation receives `MuWeaveExpansionError` instead of a
silently incomplete tree.

## Vocabulary-owned parsed bodies and arguments

A vocabulary may materialize a semantic value from one or more already parsed
sources without teaching MuWeave about that value type:

```python
from muweave import ParsedSourceInsertion, TypedValueInsertion


def adapt_chapter(request, context):
    selected = select_and_parse_chapter(request, context)
    return TypedValueInsertion(
        Chapter(request.title),
        (ParsedSourceInsertion(selected, {"package.physical_path": request.path}),),
    )


context.register_typed_value_adapter(ChapterRequest, adapt_chapter)
```

Adapters are consulted only by `expand_parsed_typed`; ordinary string
expansion continues to use the context renderer for the original value. The
adapter runs once at the evaluated occurrence. Each `ParsedSourceInsertion`
then expands immediately in the same context and work budget before later
surrounding source. Positional `bodies` run first in tuple order; named
`arguments` then run in mapping insertion order. The replacement must be a
`SemanticValue`, `Reference`, or `ReferenceTarget`.

`TypedInput` is the union of `ParsedSourceInsertion`, `SemanticValue`,
`Reference`, and `ReferenceTarget`. Both `bodies` and `arguments` accept these
inputs. An already constructed semantic child enters the same typed adapter
path recursively: its constructor is **not** called again and no renderer or
`str(...)` conversion intervenes. Child occurrences retain individual state
snapshots and inherit the producer's source metadata. They conservatively
refer to the enclosing producer range, not an invented Python-argument range.
Parsed string bodies keep their own virtual or physical ranges plus that
producer chain. Recursion cycles and excessive depth/work fail explicitly;
reusing the same immutable object at separate sequential occurrences is valid.

Use `register_typed_value_adapter(Type, adapter, direct_only=True)` for an
adapter supplying the direct-Python equivalent of registered brace bodies.
It is skipped entirely when those bodies already exist: the processor neither
reparses them nor evaluates them twice. The default `direct_only=False` keeps
the existing contract, including the error if an adapter attempts to replace
registered bodies. Named-argument materializers may still accompany them.
`context.adapt_typed_value(value, *, bodies_retained=False)` selects the
nearest registered adapter without expanding anything; wrapper adapters may
delegate to their wrapped value and preserve annotations on its replacement.

Python still constructs all call arguments in Python evaluation order before
the resulting owner is inserted. Only then are its opted-in source bodies
expanded in order. An earlier **body's** state change affects later body
occurrences, not constructors Python has already executed. This is not lazy
Python evaluation or a recursive walk through arbitrary object attributes.

A vocabulary opts selected Python parameters into structured source by naming
them explicitly. There is no recursive walk over arbitrary Python strings:

The following is a vocabulary-implementation pattern; `Axis` and
`StructuredLabel` stand for vocabulary-owned semantic types rather than
MuWeave public names.

```python
from dataclasses import replace

from muweave import ParsedSourceInsertion, TypedValueInsertion, parse_string


def adapt_axis(axis, context):
    if not isinstance(axis.x, str) or "µ" not in axis.x:
        return None
    parsed_label = parse_string(
        axis.x,
        source_name="<axis x argument>",
        text_command_schema=context.commands.text_command_schema,
    )
    return TypedValueInsertion(
        replace(axis, x=StructuredLabel("x")),
        arguments={"x": ParsedSourceInsertion(parsed_label)},
    )


context.register_typed_value_adapter(Axis, adapt_axis)
```

`ExpansionValue.arguments["x"]` is the authoritative nested
`TypedExpansion`. A document adapter recursively interprets it just like a
structured command body. The replacement value carries only a private marker
identifying where that child belongs; it does not carry a pre-rendered HTML,
LaTeX, or MyST string.

The enclosing semantic occurrence keeps the state snapshot from before its
inserted children run. Values inside each argument see earlier mutations in
that argument sequence, and mutations remain visible to later arguments and
later surrounding source. Deferred work and references inside named arguments
share the complete operation's finalization boundary, so a named argument may
refer forward to a target later in the root document.

The public `ExpansionValue` has `command_name is None` for children supplied
by `TypedValueInsertion`. Its positional bodies and named arguments are always
structured expansions. A non-`None` command name still identifies a
registered text form, whose schema decides whether its body is structured or
raw. One occurrence may own registered-command bodies and adapter-supplied
named arguments simultaneously. Parsed insertions retain their own source
names, absolute ranges, metadata, and provenance; adapters must not flatten
their content into generated target strings.

## Deferred work, references, and literals

Typed finalization preserves the ordinary global phase order across the root
and all reachable structured bodies and arguments:

1. deferred thunks run exactly once;
2. every visible local reference is validated;
3. references resolve while target registration is frozen;
4. literal fragments open last.

A semantic deferred result and a resolved `Reference` remain typed values.
Deferred string output follows the existing rule: its active `µ` is not
reopened as new command source. Both retain state captured at their original
occurrences rather than the context's later final state. Finalization is
read-only: it cannot mutate configuration or vocabulary state and cannot call
context-bound `eval`/`exec` or an expansion API to reopen ordered execution. A
`lit` payload becomes protected text and is never rescanned.

## Provenance

Every public part has immediate `Provenance` and the available outer producer
chain. `exact=True` is limited to character-for-character source or inserted-
source copies with equal text and span lengths. Generated source uses the
`generated` kind and points to its producing command. Deferred, reference, and
literal results use their corresponding late-phase kinds.

Typed parts have no final output offsets. The target serializer decides actual
artifact text and constructs its source map from node and part provenance.

## Boundary

Typed expansion does not split paragraphs, allocate section or block numbers,
interpret semantic bodies, escape target syntax, collect or publish assets,
apply a document template, or run a builder. An optional downstream document
package owns those steps. Complete occurrence-state snapshots let such a
package apply source-ordered structural policy without retaining or sharing a
mutable backend context. Target serializer output is not MuWeave input and is
never rescanned for state commands. MuWeave does not import that package, and the normal
`expand_fragment`, `expand_string`, and `expand_parsed` APIs remain direct
string transformations.
