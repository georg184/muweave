# MuCompose command-line contract
Audience: document authors, consumer developers, and AI authoring agents

MuCompose runs the installed `pytex5`, `pyhtml`, and optional `pyai` commands
as independent child processes for one trusted source file. It translates
target-qualified options to each frontend's local spelling. Parsing,
expansion, semantic projection or rendering, assets, source maps, publication,
and external builds remain frontend-owned.

MuCompose exposes no document-composition Python API. Its supported automation
boundary is the `mucompose` command; the import package exports only
`mucompose.__version__`.

> **Security warning:** Selected frontends execute unrestricted Python from
> the source and selected vocabulary. Process only trusted input.

## Basic invocation

```console
mucompose chapter.muweave
```

`INPUT` must be a readable UTF-8 file. `.muweave` is conventional, but other
suffixes are accepted. Standard input (`-`) is rejected because both children
must independently reopen the same physical source.

The default children and artifacts are:

| Target | Child mode | Normal artifacts |
| --- | --- | --- |
| LaTeX | `pytex5 INPUT --document` | `chapter.tex` and `chapter.pdf` |
| direct HTML | `pyhtml INPUT` | self-contained interactive `chapter.html` |

The semantic AI target is supported but not selected by default. Select it
alone or together with presentation targets:

Select an ordered subset with:

```console
mucompose chapter.muweave --backends=latex
mucompose chapter.muweave --backends=html
mucompose chapter.muweave --backends=ai
mucompose chapter.muweave --backends=html,latex,ai
```

`--backends` accepts only the distinct names `latex`, `html`, and `ai`. Order
controls child execution order. Empty, repeated, whitespace-padded, and unknown
names are errors. A target-qualified option for an unselected target is also
an error, including a negative switch such as `--no-latex-html`.

PyMyST remains an independent package and command, but is currently not a
MuCompose target.

## PDF series builds

`--groups=A,B` is an opt-in, inheritable MuCompose option requiring
`--backends=latex`. It runs a fresh PyTeX5 process for each named series,
passing `--config group=NAME` and distinct `_NAME.tex` / `_NAME.pdf` outputs.
No source parsing or vocabulary evaluation is moved into MuCompose. An
explicit process-level `--config group=N2` narrows the build to that one
series; inherited group settings do not narrow a batch. Group names are
case-sensitive filename-safe identifiers, not predefined school categories.

```muweave
µ! --config group=A
µ! mucompose --backends=latex --groups=A,B
µ! pytex5 --groups=A,B
```

With this bootstrap, `mucompose exam.muweave` creates `exam_A.pdf` and
`exam_B.pdf`. Use `--groups=A,B,N,N2` to change the default list. Both custom
`--latex-output` and `--latex-pdf-output` paths receive `_NAME` before their
extension in group mode; they remain exact paths in ordinary non-batch mode.
Source maps and engine intermediates consequently have separate source bases.
`--no-latex-pdf` keeps source-only series builds; experimental lwarp and
non-LaTeX targets are rejected in this initial PDF-only mode. A failing series
does not suppress the remaining series or roll back a successful PDF.
The PyTeX5-scoped directive also lets `pytex5 exam.muweave` build the same pair
directly. MuCompose adds `--no-groups` to each already selected frontend child;
its explicit destinations therefore remain exact and no recursive A/B batch
or second group suffix is added. See [standalone series builds](../../pytex5/docs/USAGE.md#pdf-series-builds).

## Combined exam copies

```console
mucompose exam.muweave --backends=latex --exam-copies 24
mucompose exam.muweave --backends=latex --exam-copies 3 --exam-seed lesson-9
```

`--exam-copies N` requests a positive total number of exams: N=3 means A, B,
A by default. `--groups` supplies a different ordered cycle; an explicit
`--config group=N2` repeats only N2. MuCompose forwards one installed PyTeX5
command with the requested count, group cycle, seed and output bases. PyTeX5
alone owns sequential independent copy processes, temporary artifacts, merge
validation, progress and final publication. Plain `--groups=A,B` without
`--exam-copies` retains its separate A/B artifacts.

The result is one fresh `exam_Druckbestände/<timestamp>_<build-id>/` directory
containing `exam_gesamt.pdf`, `exam_gesamt.exam-batch.json` and
`exam_gesamt.quellen.tar.gz`. The exact directory is reported at completion;
existing print directories and loose output files are not replaced.
`--latex-output draft.tex` supplies the base for `draft_gesamt.pdf`, while
`--latex-pdf-output print.pdf` selects `print_gesamt.pdf`. Source-only output,
non-LaTeX targets and experimental lwarp are rejected. The count and seed are
explicit invocation controls and cannot be inherited from `.mu` or `µ!`.

`--exam-seed SEED` is also forwarded to ordinary single/group PyTeX5 builds.
In copy mode it is a master seed; the retained per-copy seeds permit replay of
individual teacher copies with the same group and shuffle order. Keep the
complete trio, and give **only the PDF** to learners: the companions contain
private source/solutions and original MC keys. The JSON's inclusive page ranges
and embedded scan manifests
preserve print identities after individual temporary PDFs are removed. Its
individual PDF hashes are historical; only the outer PDF hash binds the merged
artifact. See [PyTeX5's combined-copy contract](../../pytex5/docs/USAGE.md#combined-exam-copies)
for the complete replay, failure, external-tool and manifest semantics.

## Portable document options

Explicit process options use the shared `mucli` contract and are forwarded
identically to both selected children:

| Option | Meaning |
| --- | --- |
| `--title TEXT` | Plain document title. |
| `--subtitle TEXT` | Plain document subtitle. |
| `--author TEXT` | Plain author name; repeat to preserve order. |
| `--language TAG` | Alphanumeric subtags separated by hyphens, such as `de-AT`. |
| `--date YYYY-MM-DD` | Exact ISO calendar date. |
| `--vocabulary MODULE` | Importable dotted provider module; default `muvocab`. |
| `--config NAME[=VALUE]` | Repeatable expansion setting described below. |
| `--items-dir PATH` | Canonical reusable-item directory; defaults from `MUWEAVE_ITEMS_DIR`. |
| `--images-dir PATH` | Canonical shared-image directory; defaults from `MUWEAVE_IMAGES_DIR`. |
| `--interactive-dir PATH` | Canonical installed `.muweb` module directory; defaults from `MUWEAVE_INTERACTIVE_DIR`. |
| `--persons-dir PATH` | Canonical person-library directory; defaults from `MUWEAVE_PERSONS_DIR`. |
| `--publish` / `--no-publish` | Suppress or explicitly restore working-only author presentation; default is working mode. |

Inherited shared options are not redundantly forwarded: each child reads the
same `.mu/arguments` files and unqualified `µ!` directives itself.

`--config name` means boolean `True`, `--config ~name` means boolean `False`,
and `--config name=value` retains the exact string after the first `=`. Names
use dotted Python-identifier syntax. Assignments remain ordered; the last
assignment of each name initializes that name in the fresh target context.

`--publish` is deliberately not a configuration assignment. MuCompose
forwards an explicit switch identically to every selected child, and each
vocabulary context treats publication as immutable process policy. It removes
private author notes, working item-ID badges, and the `Arbeitsfassung` marker;
source code cannot re-enable them. An inherited switch in `.mu/arguments` or an
unqualified initial `µ!` line is read independently by each child and is not
forwarded a second time.

## Shared primary document dimensions

| Option | Contract |
| --- | --- |
| `--body-width-ratio RATIO` | Forwarded to PyTeX5 and PyHTML; `(0, 1]`, default `0.76`. |
| `--body-height-ratio RATIO` | Forwarded to PyTeX5 and PyHTML; `(0, 1]`. Without an override, PyTeX5 uses `0.85` and PyHTML uses `0.9`. |

The width ratio compares the authorial body with the paper or fixed HTML
surface. The height ratio controls the A4 LaTeX body and equivalent logical
top/bottom spacing in continuous HTML; it does not introduce HTML page breaks.

## LaTeX target

| MuCompose option | PyTeX5 option | Contract |
| --- | --- | --- |
| `--latex-output PATH` | `--output PATH` | Exact ordinary LaTeX source path. |
| `--latex-html-project DIRECTORY` | `--html-project DIRECTORY` | Exact experimental lwarp project. |
| `--latex-template PATH` | `--template PATH` | Trusted UTF-8 document template. |
| `--latex-pdf` / `--no-latex-pdf` | `--pdf` / `--no-pdf` | Enable or disable normal LuaLaTeX PDF; enabled by default. |
| `--latex-pdf-output PATH` | `--pdf-output PATH` | Exact `.pdf` destination; incompatible with `--no-latex-pdf`. |
| `--latex-html` / `--no-latex-html` | `--html` / `--no-html` | Enable or disable experimental lwarp HTML; disabled by default. |

`--latex-output` and `--latex-html-project` are mutually exclusive, and an
ordinary output cannot be combined with positive `--latex-html`. With lwarp
enabled and no explicit project, one fresh `_lwarp` marker is appended to the
input stem: `chapter.muweave` uses `chapter_lwarp/`, while
`chapter_lwarp.muweave` uses `chapter_lwarp_lwarp/`.

## Direct HTML target

| MuCompose option | PyHTML option | Contract |
| --- | --- | --- |
| `--html-output PATH` | `--output PATH` | Exact self-contained destination; default replaces the input suffix with `.html`. |
| `--html-embed-ai` / `--no-html-embed-ai` | `--embed-ai` / `--no-embed-ai` | Include or omit inert semantic context for the exact HTML view; enabled by default. |
| `--html-math-renderer {mathjax,typst-mathml}` | `--html-math-renderer {mathjax,typst-mathml}` | Select only HTML mathematics; MathJax remains the default, native MathML is an optional limited pilot. |

Direct PyHTML uses no MyST, JATS, Node.js, or external builder. Its result is
atomically replaced and opens offline through `file://`.
Embedded context is built by PyHTML from its single typed expansion; it does
not invoke a second child or create an `.ai/` directory.

The renderer option uses deliberately identical qualified spelling in PyHTML
and MuCompose, participates in frontend-scoped argument inheritance, and is
rejected when HTML is not selected. It is never sent to PyTeX5 or PyAI.
The native pilot requires `pyhtml[typst]`; see PyHTML's
[mathematics guide](../../pyhtml/docs/MATHEMATICS.md#experimental-native-mathml)
for its supported notation and explicit failures. No full `pytypst` backend
or `_typst.pdf` / `_typst.html` output is implied.

## Semantic AI target

| MuCompose option | PyAI option | Contract |
| --- | --- | --- |
| `--ai-output DIRECTORY` | `--output DIRECTORY` | Exact bundle root; default replaces the input suffix with `.ai`. |

PyAI creates `document.md`, canonical `document.json`, `manifest.json`, and
only referenced local assets. It deliberately omits page geometry, spacing,
colors, and other presentation decisions. It retains headings, mathematics,
units, labels and references, pedagogical block roles, tasks and solutions,
tooltip explanations, response fields, graphics semantics, and source
coordinates. It invokes no model or external builder.

## Shared build controls

| Option | Contract |
| --- | --- |
| `--tex-bin DIRECTORY` | Forwarded only when selected PyTeX5 work runs LuaLaTeX or lwarp. |
| `--source-map` / `--no-source-map` | Ask selected presentation frontends for provenance sidecars. PyAI always includes source coordinates in `document.json`. |
| `--debug` | Ask children for complete traceback diagnostics; process-only. |
| `--version` | Print MuCompose's version and exit. |

## Layered invocation arguments

For a physical source, precedence is:

1. each ancestor `.mu` directory, from shallow to deep;
2. `.mu/arguments`, then `.mu/mucompose.arguments`, in each directory;
3. consecutive initial `µ!` lines in the source;
4. explicit process arguments.

Portable settings belong in `.mu/arguments` or unqualified directives:

```text
# .mu/arguments
--language de-AT
--author "Ada Lovelace"
--config fms
```

The complete shared inherited set is `--title`, `--subtitle`, `--author`,
`--language`, `--date`, `--vocabulary`, `--config`, `--items-dir`,
`--images-dir`, `--interactive-dir`, `--persons-dir`, and the positive/negative publication
switch.

MuCompose orchestration belongs in `.mu/mucompose.arguments` or scoped source
directives:

```text
# .mu/mucompose.arguments
--backends=html,latex
--body-width-ratio 0.76
--no-latex-pdf
```

The orchestration layers may inherit:

- `--backends`;
- `--body-width-ratio` and `--body-height-ratio`;
- positive and negative HTML AI-embedding switches;
- `--latex-template`;
- positive and negative LaTeX-PDF and lwarp-HTML switches;
- positive and negative source-map switches.

Inputs, output/project destinations, PDF destinations, `--tex-bin`, `--debug`,
`--help`, and `--version` are process-only. Misplaced inherited options fail
instead of being ignored or applied twice.

Initial directives must form one contiguous block at physical offset zero:

```text
µ! --title "Lineare Bewegung"
µ! --config fms
µ! mucompose --backends=html,latex
µ! pytex5 --no-pdf

µsection(title="Kinematik")
```

No blank line, comment, indentation, BOM, or other text may precede the block.
The first non-directive line ends it. Argument files and directive payloads use
POSIX shell-style quoting and `#` comments one physical line at a time, but no
shell runs: variables, substitutions, wildcards, and pipelines are not
expanded. The original directive characters remain represented in source
coordinates even though expansion begins after the bootstrap block.

## Process and artifact boundary

The basic child vectors are:

```text
pytex5 INPUT --document [explicit shared options] [mapped LaTeX options]
pyhtml INPUT [explicit shared options] [mapped direct-HTML options]
pyai INPUT [explicit shared options] [mapped AI options]
```

Each child independently reads, parses, expands, renders, publishes, and maps
the same source with a fresh context. No evaluated value, namespace state,
reference registry, asset registry, or source map is shared. MuCompose runs all
selected children even after one fails and never rolls back a successful
peer's artifacts.

Input, derived source/PDF/project paths, and explicit HTML destinations take
part in collision preflight. An AI bundle may not contain another selected
artifact or project, and may not lie inside one. Backend-owned files inside a
selected non-AI project remain that backend's responsibility.

## Workflows

Publish LaTeX source and direct HTML without LuaLaTeX:

```console
mucompose chapter.muweave --no-latex-pdf
```

Build only LaTeX/PDF at explicit destinations:

```console
mucompose chapter.muweave \
  --backends=latex \
  --latex-output build/chapter.tex \
  --latex-pdf-output build/chapter.pdf
```

Publish only direct HTML:

```console
mucompose chapter.muweave \
  --backends=html \
  --html-output build/chapter.html
```

Omit the normally embedded semantic context deliberately:

```console
mucompose chapter.muweave --backends=html --no-html-embed-ai
```

Publish only the semantic model bundle:

```console
mucompose chapter.muweave \
  --backends=ai \
  --ai-output build/chapter.ai
```

Opt into experimental lwarp HTML while retaining the PDF:

```console
mucompose chapter.muweave --backends=latex --latex-html
```

Request independent target provenance maps:

```console
mucompose chapter.muweave --source-map
```

## Exit statuses

| Status | Meaning |
| --- | --- |
| `0` | Every selected child succeeded; no arguments also prints help and returns zero. |
| `1` | At least one child failed or could not start; peer children were still attempted. |
| `2` | Invalid process or inherited arguments. |
| `3` | Main source I/O or UTF-8 decoding failed. |

Child stdout and stderr remain attached to the caller. MuCompose adds one
concise diagnostic for a missing child or nonzero child status.
