# Reusable parsed source

Audience: backend developers and application integrators

`analyze_string` separates recoverable source analysis from strict compilation
and execution:

```python
from muweave import analyze_string, parse_analysis

analysis = analyze_string(
    'Result: µcalculate(topic="vectors")[2].title',
    source_name="chapter.muweave",
)

if analysis.diagnostics:
    for diagnostic in analysis.diagnostics:
        print(diagnostic.message, diagnostic.span)
else:
    parsed = parse_analysis(analysis)
    assert parsed.analysis is analysis
```

Neither operation evaluates a document expression. `parse_analysis` compiles
the Python ASTs already retained by the supplied analysis without rescanning,
retokenizing, or extracting commands again. `parse_string` is the strict
convenience composition of these two operations:

```python
from muweave import MuWeaveContext, expand_parsed, parse_string

parsed = parse_string(
    'Result: µcalculate(topic="vectors")[2].title',
    source_name="chapter.muweave",
)

latex_context = MuWeaveContext({"calculate": make_latex_items})
myst_context = MuWeaveContext({"calculate": make_myst_items})

latex = expand_parsed(parsed, latex_context, output_name="chapter.tex")
myst = expand_parsed(parsed, myst_context, output_name="chapter.md")
```

`SourceAnalysis` retains the immutable source, all scanned marker occurrences,
hierarchical structural nodes, Python AST/token metadata, used text-command
syntax declarations, and zero or more syntax diagnostics. `ParsedSource`
retains that exact analysis plus compiled expression and trailer code. Neither
retains namespace objects, handlers, evaluated values, mutable context state,
rendered strings, references, deferred work, or source-map output.

## Structural analysis and recovery

Strict parsing raises the first `MuWeaveParseError`. Read-only tooling instead
uses `SourceAnalysis.diagnostics` and may continue inspecting accepted later
lines. A balanced qualified `µname{...}` or `µname[...]{...}` spelling is
ordinary structural syntax even when its name or exact modifier form is absent
from the supplied schema. Its marker, qualified target, delimiters, modifier,
separator candidates, bodies, and valid trailers are retained in an
`AnalyzedTextCommand` without a syntax diagnostic. `parse_analysis()` compiles
the same structure. Only later expansion resolves whether the text-command
form exists and raises `MuWeaveEvaluationError` if it does not. This is the
same phase boundary used by a syntactically valid unknown name in canonical
Python form.

The schema still supplies body semantics for declared commands. In particular,
a known raw body remains opaque. An unresolved form has no such semantic
declaration; analysis retains its balanced generic body structure, but the
source must be reparsed with the active declaration before that form can
execute.

Other failures skip conservatively through the physical line containing the
error, then resume with the normal MuWeave scanner and Python-authoritative
extractors. Recovery does not implement an alternative expression or
text-command grammar. An unfinished construct extending reliably to the end of
its enclosing range leaves no later range to recover.

The detailed immutable node types live in `muweave.analysis` rather than being
mirrored through every package-root import. `SourceAnalysis.root` is an
`AnalyzedRange`; `SourceAnalysis.iter_nodes()` walks its ordinary source-copy,
escaped-marker, literal-marker, expression, text-command, and error nodes
depth-first. Expanded and deferred text-command bodies contain nested ranges.
Raw bodies are intentionally opaque and have `bodies is None`.

`TextCommandInvocation` and unresolved `TextCommandStructure` retain separate
spans for the marker, target, optional opening/modifier/closing brackets,
opening and closing braces, plural or candidate `,,` separators, argument
bodies, the complete command, and optional Python trailers. Extracted
expressions and trailers both retain their exact physical Python tokens.
Editor tooling therefore need not rediscover punctuation or Python token
boundaries from command strings.

An `AnalysisDiagnostic` contains its message, exact original `SourceSpan`, and
an optional underlying Python tokenizer/parser cause. `parse_analysis()`
recreates the normal strict `MuWeaveParseError` and preserves that cause chain.

Each `expand_parsed` call therefore:

- uses the namespace, text-command bindings, and renderers of its own context;
- evaluates every command occurrence independently and exactly once;
- produces an independent source map when given its own `ExpansionTrace`;
- parses only command source generated dynamically during that expansion.

Call `expand_parsed_typed` instead when a downstream document layer needs to
retain evaluated `SemanticValue` objects and structured registered-command
bodies before target rendering. It reuses the same immutable parse and
exactly-once evaluator. See [Typed expansion](TYPED_EXPANSION.md).

`analyze_string` and `parse_string` accept an optional half-open physical root
range through `start_offset` and `end_offset`. Text outside that range remains
part of the same immutable `SourceText`, so line numbers, absolute offsets,
source hashes, and later provenance are not rebased, but it contributes no
node, evaluation, or output. `end_offset=None` selects the physical source end.
An accepted command may not extend across the selected boundary.

## Logical source composition

An immediate command result may be a `ParsedSourceInsertion`. MuWeave expands
the retained parse result at that exact position in the current context instead
of rendering it to a string:

```python
from muweave import (
    MuWeaveContext,
    ParsedSourceInsertion,
    expand_parsed,
    parse_string,
)

body = parse_string(
    "Portable body: µvalue",
    source_name="chapter.muweave",
)
template = parse_string(
    "<document>µbody</document>",
    source_name="target-template.txt",
)
context = MuWeaveContext(
    {
        "body": ParsedSourceInsertion(body),
        "value": "expanded",
    }
)

result = expand_parsed(template, context)
assert result == "<document>Portable body: expanded</document>"
```

This is the core composition primitive for a target backend whose trusted
template exposes an expression such as `µdocument.body()`. The backend may
parse one authorial body once, retain it in its `document` facade, and return a
fresh insertion value from `body()`.

Insertion has these semantics:

- the inserted source is not rescanned, reparsed, or recompiled;
- its commands evaluate at the insertion position in the same context;
- template prefix, inserted source, and template suffix share source order;
- deferred work, references, and literals remain protected until the enclosing
  `expand_parsed` operation finalizes the complete logical document;
- one parse result may be inserted repeatedly and evaluates independently each
  time;
- recursive insertion of an already active parse result is an expansion cycle;
- every inserted source must be compatible with the active text-command schema;
- optional `source_metadata` is scoped to that insertion and then restored;
- an expansion trace retains the inserted physical source separately from the
  template and links it through the inserting command.

`ParsedSourceInsertion` is an immediate expansion-control value, not a normal
renderable object. Returning it from deferred work or passing it to the ordinary
rendering protocol is an error. A parsed source already owns its diagnostic
name, so `set_generated_source_name()` cannot rename an insertion.

## Text-command schema

Ordinary compact Python expressions such as `µname`, `µfactory()[2]`, and
`µsection(title="Kinematik")` need no schema. Only the optional `{...}` and
`[...]{...}` text forms affect parse-time structure. Their handler-independent
shape is declared through `TextCommandSchema`:

```python
from muweave import MuWeaveContext, TextCommandSchema, expand_parsed, parse_string

schema = TextCommandSchema()
schema.register("emph", brace_argument="text")
parsed = parse_string(
    "µemph{important}",
    text_command_schema=schema,
)

latex_context = MuWeaveContext(text_command_schema=schema)
myst_context = MuWeaveContext(text_command_schema=schema)
latex_context.commands.bind("emph", latex_emph)
myst_context.commands.bind("emph", myst_emph)

latex = expand_parsed(parsed, latex_context)
myst = expand_parsed(parsed, myst_context)
```

The parameter is deliberately named `text_command_schema`: it does not list
normal Python names or constrain the execution namespace. Structural
recognition of a balanced qualified brace or modifier spelling does not perform
an existence check against this schema. A parse result stores the deterministic
declarations actually used by declared text commands and refuses expansion
when a context lacks or changes one of them. Additional unused declarations in
a target context are permitted. An unresolved structure fails semantically
when reached; it is not retroactively assigned body semantics by a declaration
added after parsing.

Configure every text-command shape before parsing. Target contexts may bind
different callables and modifier adapters, but the source spelling, body
policy, and modifier availability must agree.

## Namespace providers

MuWeave accepts an ordinary dictionary as its Python namespace. A higher-level
application should use a factory that creates a fresh context and fresh
stateful services for each independent target expansion:

```python
def make_latex_context(schema: TextCommandSchema) -> MuWeaveContext:
    """Create one independently mutable LaTeX expansion context.

    Args:
        schema: Shared parse-time text-command schema.

    Returns:
        Fresh configured context.
    """

    context = MuWeaveContext(
        {
            "section": section,
            "tasks": LatexTaskService(),
        },
        text_command_schema=schema,
    )
    context.commands.bind("emph", latex_emph)
    context.renderers.register(Section, render_latex_section)
    return context
```

This composition layer, not the parser, decides which Python objects authors
can reach. Large APIs can be grouped behind roots such as `tasks`, `figures`,
or `project`; frequently used semantic constructors can remain flat names.

## Persistence boundary

`SourceAnalysis` and `ParsedSource` are in-process objects, not stable
serialized file formats. Analysis contains interpreter-owned Python ASTs;
parsed source additionally contains compiled code. Both are cheap to share
directly within one process. MuWeave does not currently write a parse-cache
helper file.

A future persistent cache is justified only by measurements. It must be
versioned and bound to the exact source content, Python/MuWeave compatibility,
and required text-command declarations. It must never store evaluated values,
mutable namespaces, rendered output, references, deferred work, or source maps.
