# MuWeave Reader

Licensed under the [GNU GPLv3](LICENSE) (`GPL-3.0-only`).
Copyright (C) 2026 Georg G. See [NOTICE](NOTICE) for scope and third-party notices.

`muweave-reader` is the optional native host for self-contained PyHTML
documents. The same `.html` file still opens and works as an ordinary offline
worksheet in a browser. Opening it in the reader additionally enables author-
declared notebook cells backed by the locally installed MuWeave toolchain.

```bash
muweave-reader lesson.html
```

The native toolbar provides **Back** and **Forward** arrow buttons for visited
locations inside the document, including references and table-of-contents
entries. **Alt+Left** and **Alt+Right** perform the same navigation; the
platform's standard back/forward shortcuts also work, except **Backspace** and
**Shift+Backspace**, which remain available for text editing. Buttons are disabled at
the corresponding end of the history. The browser restores the previous
scroll position without reloading the document or undoing learner edits.
Manual scrolling also contributes reading positions by default. The history
belongs only to the current window and is not saved in `.work`.

The **Lesepositionsverlauf einstellen** icon beside the search button opens
the native history settings:

- Enable or disable recording of manual scrolling. Link and TOC navigation
  continues to work when recording is disabled.
- **Scroll pause:** `1.0 s` by default, adjustable from `0.2` to `10 s`.
  Continuous movement, including inertial scrolling, forms one group until
  that pause. Holding or dragging a scrollbar does not split the group.
- **Minimum distance:** `50 %` of the visible document height by default,
  adjustable from `10 %` to `200 %`. Smaller adjustments update the current
  reading position rather than creating another step.

Once the minimum distance is crossed, Back already works, even before the
pause. Further scrolling updates that group's destination. Links always form
their own steps and retain the exact position immediately before the jump.
Back/Forward itself never records a new scroll step. A new sufficiently large
scroll or link jump after Back replaces the forward branch.

Only scrolling the main document counts: sidebar, editor, local worksheet,
and embedded-quiz scroll areas do not. Automatic layout changes and search
scrolling do not start a group. Settings apply immediately in this window and
are remembered for subsequently opened reader windows, separately from `.work`.
Switching recording off does not delete positions already in the history.
Ordinary browsers are unchanged.

Use the reload icon, **F5**, or **Ctrl+R** to reload the currently hosted
artifact from disk after rebuilding the HTML while the reader is open.
External links still open outside the reader and do not enter this local
navigation history. Existing HTML documents need not be rebuilt for these
native controls.

## Search the document

The magnifying-glass button or **Ctrl+F** opens the native search bar
(**Cmd+F** on macOS). Type a word or phrase to highlight its occurrences and
scroll to the active match. The counter shows the active match and total, for
example `2 / 7`, or **Keine Treffer** when the text is absent.

- **Enter** in the search field or **F3** anywhere: next occurrence.
- **Shift+Enter** in the search field or **Shift+F3** anywhere: previous
  occurrence. The arrow buttons perform the same operations. Navigation wraps
  around at the first and last match.
- **Aa** toggles case-sensitive matching; the default ignores case.
- **Esc** or the close button hides the bar, clears the highlights, and returns
  focus to the document. The query is retained for this reader window.

Opening search uses a short, single-line text selection as its initial query,
if present. An open search is refreshed automatically after reloading the
document. **Shift+Enter** in a notebook cell still runs that cell; the search
shortcut applies only inside its own controls.

This is the embedded browser's text search, not a symbolic formula search or
handwriting recognition. SVG-drawn mathematical glyphs and canvas strokes are
not searchable as ordinary text. Searching neither edits HTML nor changes or
saves `.work`, and it requires no Python-execution permission. Existing HTML
files need not be rebuilt to use it.

## Editable showcases

An author creates the first supported cell by making a showcase editable and
assigning it one stable document-local session:

```text
µshowcase[editable=True, session="intro:arithmetic"]{
µexec("answer = 6 * 7")
µexpr(answer)
}
```

The source panel retains the normal parser-derived syntax highlighting while
it is edited. The reader sends changed text through MuWeave's non-evaluating
structural source analysis and updates the coloured layer behind the editor;
it does not maintain a second JavaScript grammar and highlighting never grants
execution trust. The transparent input and visible source layer have identical
text geometry, including a trailing empty line, so the caret remains exactly on
the highlighted source. The editor grows automatically without an inner
scrollbar; **Shift+Enter** or the run button evaluates the complete cell. The
first successful run replaces the authored initial result, and each later run
replaces the preceding runtime result. Python names and MuWeave configuration
persist within the named session. Every run uses fresh document structure, so
counters, references, layout state, and assets from an earlier result do not
leak into the next one.

Notebook results use the document's chosen HTML math renderer. In an HTML file
built with PyHTML's default `--math-renderer=typst-mathml` (or
`muweave --html-math-renderer=typst-mathml`), every manual run produces native
MathML and result-local styles, using the host's embedded mathematical font.
The same native optical measurement handles fraction/matrix settings on every
replacement, including a text-only document's first mathematical result.
Typst must be installed in the reader's Python environment to execute such
cells and is a PyHTML runtime dependency, but is not needed merely to view the
authored result. Explicitly selected MathJax remains available, including for
legacy documents; unsupported native notation gives a diagnostic
instead of switching engines in the background.

Edited cell source is ordinary learner state and is saved with the worksheet's
other data in `.work`. Generated HTML output is deliberately session-only:
persisted state cannot inject executable markup
into a later privileged reader session. The immutable showcase result produced
when the author built the document remains visible in every host.

## Automatic work state

For `lesson.html`, the reader automatically uses the exact sibling file
`lesson.work`. It loads an existing valid file on startup, creates it when it
is absent or empty, and atomically replaces it when PyHTML saves learner work.
The green connection indicator therefore appears without **Arbeitsstand
einrichten**, a directory picker, or a browser file permission. An invalid
nonempty sidecar is reported and retained unchanged.

Several reader windows or supported browser views may point at that same
sidecar. A visible connected view checks it every two seconds and again as soon
as the view regains focus. If the view has no own pending changes, it adopts a
new external state automatically. Every save is based on the exact file bytes
seen by the preceding read; if another view changed them, the stale save is
rejected and the status turns red instead of overwriting the newer file.

This automatic capability exists only because the native reader already knows
the canonical path of the hosted HTML file and has the current user's normal
filesystem rights. Opening the same HTML in an ordinary browser preserves
PyHTML's IndexedDB mirror and explicit browser-permission workflow instead.
PyHTML remains responsible for the `.work` schema, freshness comparison, and
worksheet state; the reader exposes only the fixed sibling read/atomic-write
operation.

## Trust boundary

MuWeave source is trusted Python. The reader never executes a cell on load and
asks for explicit confirmation before the first execution in each window.
Confirmation grants the document arbitrary Python execution with the current
user's permissions. The worker process, size limits, and timeout make execution
interruptible and protect the GUI protocol; they are not a security sandbox.
Only open and execute documents you trust.

The first runtime slice supports normal MuVocab text, mathematics, static
graphics, and local assets. It does not yet activate a newly generated nested
interactive MuWeb module inside a notebook result.

## Development

See [Development and GUI tests](DEVELOPMENT.md) for the isolated, bounded
headless test runner and the separate non-GUI checks.
