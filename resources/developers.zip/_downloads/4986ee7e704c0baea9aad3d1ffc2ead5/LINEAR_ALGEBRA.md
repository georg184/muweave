# Terms, points, vectors, and matrices

Audience: MuWeave authors, AI authoring agents, and vocabulary integrators

MuVocab represents scalar expressions and affine geometry as immutable semantic
Python values. They are not backend strings: direct HTML, LaTeX, and MyST turn
the same value into target mathematics only when the document is rendered.
SymPy 1.14 or newer is the initial private algebra engine behind `Term`.
Author code should depend on the public MuVocab types rather than SymPy APIs.

## Scalar terms

Construct a scalar with the class spelling `Term(...)`:

```python
a = Term("a")
expression = (a + 2) ** 2
result = expression.subs(a=3)       # Term("25")
decimal = Term("1/3").as_decimal(precision=8)
```

`Term` accepts integers, finite or symbolic scalar strings, `float`,
`Decimal`, `Fraction`, another `Term`, and a scalar SymPy expression. Use
Python-style expression syntax in strings; `a**2` is the clearest spelling for
a power. A Boolean or matrix is not a scalar term. Arithmetic returns new
`Term` values. `simplify()` and `subs(...)` likewise retain the abstraction;
`as_decimal(...)` is the explicit boundary for a finite real approximation.

`diff(variable, order=1)` returns the symbolic derivative as another `Term`.
`variable` is either a nonempty Python identifier string (including Unicode
identifiers) or a `Term` containing exactly one symbol. A string is a literal
symbol name, not an expression to parse. `order` is a strictly positive Python
integer; booleans are rejected. Other symbols are held constant. There is no
implicit choice of differentiation variable and no finite-difference step.

```python
position = Term("tau**3/3 + sin(tau)")
velocity = position.diff("tau")            # Term("tau**2 + cos(tau)")
acceleration = position.diff("tau", 2)     # Term("2*tau - sin(tau)")
initial_velocity = velocity.subs(tau=0)    # Term("1")
```

In `g.interactive`, differentiating a dropdown-selected expression with
respect to its local plot variable retains the selection and differentiates
the alternatives. Controls independent of that variable remain constant.
The computed derivative is the retained expression in HTML, LaTeX, MyST and
AI; no Python callback or differentiation routine is sent to the browser.
Unknown functions may retain an unevaluated symbolic derivative, which is
subject to the ordinary target and interactive-expression restrictions.
Symbolic differentiation does not establish differentiability at a corner,
branch boundary or excluded domain point. The upright notation `µd` is a
separate [mathematical symbol](AUTHORING.md#portable-text-operators-accents-and-explanatory-notation).

These all render as inline mathematics when used directly in source:

```text
µTerm("a**2 + 2*a + 1")
µexpr((Term("a") + 1) ** 2)
```

MuWeave documents already execute trusted unrestricted Python. Treat strings
passed to the symbolic engine as trusted input for the same reason.

## Coordinate values

The lower-case `p` and `v` names are callable namespaces:

```text
Punkt: µp(1.5, 3)
Raumpunkt: µp(Term("a"), 2, 3)
Vektor: µv(1, -2, 4)
```

The plural brace forms split coordinates only at top-level `,,`:

```text
µp{1,,2,,3}
µv{a,,2,,3}
```

Canonical Python calls are preferable when a coordinate is itself a nontrivial
expression. `p(...)` returns `CoordinatePoint`; `v(...)` returns a column
`CoordinateVector`. Their dimension is the number of coordinates. The current
algebra is dimension-neutral, with named `.x`, `.y`, and `.z` access for the
first three components. Asking a 2D value for `.z` is an error.

Points form an affine space:

```python
P = p(1, 2, 3)
d = v(4, -1, 2)
Q = P + d                 # point
connection = Q - P        # vector
same = P.to(Q)            # the same vector
position = P.position_vector
```

Adding two points is deliberately unsupported. A point plus or minus a vector
is a point; subtracting two equal-dimensional points is their connecting
vector.

## Symbolic points and vectors

Attribute and index chains are ordinary Python expression syntax:

```text
µp.A
µp.A[1]
µv.a
µv.v[1]
µv.v[1].x
µv.v[1].coordinates(3)
```

These denote `A`, `A_1`, vector `a`, vector `v_1`, scalar component
`v_{1,x}`, and the coordinate column `(v_{1,x}, v_{1,y}, v_{1,z})`. Compact
point attributes are single upper-case letters. `p.symbol("Start")` and
`v.symbol("velocity")` provide exact longer names.

A bare identifier string used as a subscript is a literal label, so
`v.x["E"]` denotes vector `x` with the uppercase subscript `E`; it is not
SymPy's predefined Euler constant. Pass a `Term`, as in `v.u[Term("i + 1")]`,
when the subscript is an expression rather than a label.

A complete semantic mathematics fragment can also be the index of a point or
vector. For example, an average velocity belonging to a time interval has two
supported spellings in the typed document pipelines:

```text
µv.v[interval("t_A", "t_E")]
µv.v["µinterval{t_A,,t_E}"]
```

The first spelling constructs the portable `Interval` immediately and works in
every current renderer, including the low-level string APIs and MyST. In the
second spelling, the active `µ` opts this particular string parameter into
structured expansion. Direct HTML, complete PyTeX5 documents, and PyAI retain
the parsed index beside the vector occurrence and render it only at their
mathematics boundary. It is not ordinary recursive expansion of arbitrary
Python strings. Effects inside that selected source occur at the vector's
position and before later surrounding source.

The structured-string spelling applies when the point, vector, or connection
vector is itself an expansion occurrence. It also applies in the explicitly
declared mathematical fields of generated graphics: semantic `Axis.x` and
`Axis.y` labels, and `VectorArrow.name` values contained by an `Axis` or
`Scene3D`. For example:

```text
µg.axis(0, 4, 0, 3, y=v.x["µTerm(2)"]).add(
    g.vector(v(2, 1), name=v.v["µinterval{t_A,,t_E}"])
)
```

That does not authorize a recursive walk through arbitrary semantic objects.
For any other containing field, use the already semantic `interval(...)` form
until its API explicitly adopts the typed-argument contract. Components such
as `.x` and `.coordinates(3)` still require a scalar `Term` index; a semantic
or structured display fragment indexes the complete symbol only.

Use ordinary mathematics composition when the index is arbitrary formula
source rather than an available semantic object. The interval spelling can,
for example, also be written as:

```text
µm{{µv.v}_{µinterval{t_A,,t_E}}}
```

This unrestricted form is essential for a presentation-only index for which
MuVocab has no structured value. A two-line condition is one such example:

```text
µm{{µv.v}_{\substack{k\in\mathbb{N}\\k\text{ gerade}}}}
```

The `m` form remains the universal presentation-only fallback and works in the
low-level and MyST pipelines as well. It constructs inline mathematics, not a
reusable `VectorSymbol`. A typed main document can alternatively retain such
source in a symbol by placing an active MuWeave expression in the selected
string, but a semantic constructor such as `interval(...)` remains preferable
when one already exists.

The explicit connecting-vector operations are:

```text
µp.A.to(p.B)
µv.from_to(p.A[1], p.A[2])
```

The following compact forms are equivalent where their endpoint split is
unambiguous:

```text
µv.AB
µv.A1_A2
µv.A12_B3
```

`v.A_1A_2` is rejected because its endpoint boundary is ambiguous. Use
`v.A1_A2` or `v.from_to(p.A[1], p.A[2])` instead. For named points,
`.position_vector` denotes the connection from `O` to that point.

The semantic symbol is shared, but its arrow typography belongs to the target.
The LaTeX adapter uses `esvect` for compact, prominent arrows and correct index
placement. Direct HTML and MyST use the native TeX-style `\vec` accent for a
named base symbol and append every optional subscript normally after that
accented symbol. A connection vector instead uses `\overrightarrow` across its
complete endpoints.
Authors therefore write the same `v.*` expression in every target and must not
encode one backend's arrow command in the source.

## Vector and matrix algebra

Coordinate vectors support equal-dimensional addition and subtraction, scalar
multiplication and division, unary minus, `abs(vector)` for the Euclidean norm,
`.unit`, substitution, and a 3D `.cross(other)` product.

Use semantic `length(...)` or its brace form for visible length notation:

```text
µlength{µv.a}
µblock.equation{µlength{µv.b-µv.a}=\sqrt{13}}
µm(length(v.AB))
µlength("µv.c[1]")
```

The renderer uses one vertical bar on either side in PDF, HTML, and AI output.
Do not write raw `\lVert`/`\rVert`. The two operations are intentionally
different: `length(value)` retains notation for rendering, whereas
`abs(v(3, 4))` computes the concrete value `5`. Python's builtin `len` is not
replaced.

`length` accepts exact mathematical strings and semantic mathematics objects.
A quoted string containing an active `µ` opts into structured expansion at
that occurrence, so `µlength("µv.c[1]")` retains the indexed vector as a
semantic child rather than printing the command text literally.

Vectors are columns. Python's `@` keeps its matrix-multiplication meaning:

```python
u = v(1, 2, 3)
w = v(4, 5, 6)
scalar = u.T @ w           # Term("32")
outer = u @ w.T            # 3 by 3 Matrix
```

`u @ w` is intentionally invalid: transpose the left vector to request the
scalar-product special case. `Matrix(rows)` requires a nonempty rectangular
iterable of scalar-compatible rows. `.shape`, `.T`, and dimension-checked
matrix multiplication are available.

Values compose inside other semantic mathematics without nested delimiters:

```text
Inline: µm(p(1, 2)).
µblock.equation(v(Term("a"), 2), label="eq:vector")
```

## Graphics and the 3D boundary

`g.line(start, end, ...)` accepts coordinate points as well as tuples or
lists, so these are equivalent:

```python
g.line((0, 0), (2, 1))
g.line(p(0, 0), p(2, 1))
g.line((0, 1), (4, 3), name=v.x[1], color="#800000")
```

The optional line `name` is scalar mathematical content by default:
`name="a"` means `a`, not a vector. Use `name=v.a` or `name="µv.a"` explicitly
for vector notation. The `label_at`/`label_side`/`label_offset` controls match
named vector arrows; this labels a vector-valued graph without an arrowhead.
Complete quoted MuWeave names are mathematical source retained once by the
owning `Axis` or `Scene3D` in structured targets. `g.arc` uses this same name
contract for two-dimensional circular arcs; see
[the graphics reference](AUTHORING.md#circular-arcs-and-complete-circles).

`g.arrow(start, end, ...)` uses the same point contract for a general directed
graphic arrow. `g.vector(vector, ...)` instead retains a `CoordinateVector`,
derives its endpoint, and can carry its mathematical name:

```python
g.vector(v(3, 2), name="a")
g.vector(v(3, 2), start=p(-1, 1), name=v.a)
g.vector(v(2, -1), name=v.v[1])
g.vector(v(2, -1), name=v.v["µinterval{t_A,,t_E}"])
g.vector(p(4, 3) - p(1, 1), start=p(1, 1), name=v.AB)
```

The default start is the dimension-matching zero point. `name="a"` and
`name=v.a` are equivalent, while the structured forms retain subscripts and
connection-vector notation. The coordinate vector stays independent of its
graphic name, so ordinary algebra does not acquire or propagate presentation
metadata. The quoted MuWeave spelling is interpreted only when this named
graphic segment is contained by an `Axis` or `Scene3D` occurrence in direct
HTML, complete PyTeX5, or PyAI. Use
`name=v.v[interval("t_A", "t_E")]` for the universal
low-level and MyST-compatible spelling.

Line construction retains 2D or 3D geometry. `g.axis(...)` is a 2D viewport
and therefore rejects a 3D line explicitly. Use an explicit camera and scene
for three-dimensional geometry:

```python
camera = g.camera.orthographic(
    (6, -8, 5),
    target=(0, 0, 0),
    up=(0, 0, 1),
    view_height=4,
)
scene = g.scene3d(camera, width=10, height=7).add(
    g.line((-1, -1, -1), (1, -1, -1)),
    g.line((1, -1, -1), (1, 1, -1)),
    g.vector(v(1, 1, 1), name="a", color="forest-green"),
    g.point((0, 0, 0), color="dark-orange", radius=3),
)
```

`g.camera.perspective(...)` accepts the same `position`, `target`, and `up`
arguments plus a vertical `field_of_view=45` in degrees and a positive
`near=0.01` plane. Orthographic `view_height` is the visible vertical extent
in world coordinates; the scene's `width` and `height` are output dimensions
in centimetres. Camera vectors must be nondegenerate. Every point must be a
finite real 3D point at render time, and every line endpoint or point marker in
the current perspective implementation must lie beyond the near plane.

The retained scene is projected only at the target boundary. Direct HTML emits
inline SVG and LaTeX emits ordinary 2D TikZ with identical projected
coordinates. MyST rejects the value explicitly. The scene accepts lines,
general arrows, named or unnamed vector arrows, and filled point markers,
paints them in source order, and clips geometry to the projected rectangle.
It does not yet perform near-plane clipping, hidden-line removal, lighting,
surfaces, or 3D coordinate axes. A `g.point(...)` marker and arrowhead have
target-independent dimensions in typographic points; the underlying affine
`p(...)` and algebraic `v(...)` values remain nonvisual. No backend silently
discards a z-coordinate. Symbolic coordinates may be constructed, but call
`.subs(...)` before static projection.
