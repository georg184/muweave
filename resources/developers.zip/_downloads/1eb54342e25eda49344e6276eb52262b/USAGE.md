# PyMyST usage reference
Audience: document authors, consumer developers, and AI authoring agents

PyMyST is the MyST frontend for MuWeave. It can expand a standalone MyST page,
compose a complete page with frontmatter, publish a one-page MyST project,
build one self-contained offline HTML worksheet, and optionally run MyST's
conventional site or experimental PDF builders. Parsing,
Python evaluation, transitive expansion, references, literal protection,
provenance, and source maps remain owned by `muweave`. Portable author
commands and their MyST renderers remain owned by `muvocab`.

> **Security:** source files, templates, setup scripts, and expressions execute
> unrestricted Python with the current user's permissions. Process only trusted
> inputs.

## Backend context versus MuVocab

`PymystContext()` is a bare MyST backend context. It adds a project-asset
registry to MuWeave's core context but does **not** install MuVocab commands or
renderers.

The CLI defaults to `--vocabulary muvocab`. It imports that trusted provider,
asks it for a text-command schema, and creates a fresh MuVocab-configured
`PymystContext`. The equivalent Python workflow is explicit:

```python
from muweave import parse_string
from muvocab import create_myst_context, create_text_command_schema
from pymyst import expand_parsed

schema = create_text_command_schema()
body = parse_string(
    'µsection(title="Kinematics")\nThe answer is µm{v = a t}.',
    source_name="chapter.muweave",
    text_command_schema=schema,
)
context = create_myst_context(schema)
myst = expand_parsed(body, context, output_name="chapter.md")
```

A custom provider selected by `--vocabulary MODULE` must expose compatible
`create_text_command_schema()` and `create_myst_context(...)` operations. The
provider and every setup script are trusted executable code.

## Processing modes

### Low-level standalone page

Low-level preprocessing is the default. PyMyST expands the supplied source and
publishes only that page:

```bash
pymyst fragment.pymyst
```

This creates or replaces `fragment.md`. No project configuration, plugin, HTML,
or PDF is created. Registered local assets are copied beneath
`fragment.md`'s parent using their collision-safe `assets/...` paths.

### Complete-document page

`--document` treats the input as an authorial body and inserts its retained
parse into PyMyST's trusted document template:

```bash
pymyst chapter.pymyst --document --title "Kinematics" --author "Ada"
```

The default template prepends supported YAML frontmatter and otherwise leaves
the expanded body intact. It does not invoke MyST by itself.

Document mode is also selected by `--template`, any shared metadata option, or
any option that requests a project. Vocabulary selection, `--config`, and
`--setup` alone do not select it.

### Buildable MyST project

`--project DIRECTORY` publishes a one-page project and builds a sibling
self-contained HTML worksheet by default:

```bash
pymyst chapter.pymyst --project chapter.myst
```

The project contains:

```text
chapter.myst/
├── index.md
├── myst.yml
├── pymyst.mjs
└── assets/          # when local assets were registered
```

The same project mode is selected by positive `--offline-html`, positive
`--html`, positive `--pdf`, an offline HTML destination, or a non-default
`--site-template`. When no explicit project is given for file input, its final
suffix is replaced by `.myst`. Project mode with standard input requires
`--project`.

Offline HTML is enabled by default whenever project mode is active. The
conventional large MyST site and experimental PDF are disabled by default:

| Goal | Options |
| --- | --- |
| Publish project and offline HTML | `--project DIR` |
| Publish project source only | `--project DIR --no-offline-html` |
| Also build the conventional MyST site | `--project DIR --html` |
| Also build experimental PDF | `--project DIR --pdf` |
| Build only experimental PDF | `--project DIR --no-offline-html --pdf` |

## Input and output paths

- Every input is strict UTF-8.
- `.pymyst` is the recommended standalone MyST-source suffix, not a parser
  restriction. Any readable filename is accepted.
- For non-project file input without `-o`, the final suffix is replaced with
  `.md`; a suffixless filename receives `.md`.
- `-o PATH` means exactly `PATH`; `-o -` sends file input to standard output.
- Input `-` reads standard input and defaults to standard output.
- Input and output paths must differ.
- Existing page files are atomically replaced after successful expansion.
- Ordinary output parent directories are not created.

Project mode cannot be combined with `--output`. Its page is always
`PROJECT/index.md`. The project root is created only if its parent already
exists. Each owned project file and asset is replaced atomically; unrelated
files remain, and the complete project is not one filesystem transaction.

For physical input, the default offline worksheet replaces the input's final
suffix with `.html`, independently of the selected project directory.
`--offline-html-output PATH` selects an exact `.html` destination.

The default PDF destination appends `_myst` to the project-directory stem:
`chapter.myst/` produces sibling `chapter_myst.pdf`. The marker is appended on
every derivation, so `chapter_myst.myst/` produces `chapter_myst_myst.pdf`.
`--pdf-output PATH` instead selects an exact `.pdf` destination.

## Complete CLI reference

Run `pymyst --help` for the installed version. Current options are:

| Option | Meaning |
| --- | --- |
| `INPUT` | UTF-8 file with any suffix, or `-` for standard input |
| `-o PATH`, `--output PATH` | Exact standalone page output, or `-` |
| `--source-map` | Publish `OUTPUT.muweave-map.json`; requires file output |
| `--setup PATH` | Execute trusted UTF-8 Python in the context; repeatable |
| `--debug` | Append complete chained Python tracebacks to diagnostics |
| `--version` | Print the package version |
| `--document` | Select complete-document composition |
| `--template PATH` | Trusted custom MuWeave template; implies document mode |
| `--project DIRECTORY` | Publish a buildable one-page project |
| `--site-template NAME_OR_PATH` | MyST site template; default `book-theme` |
| `--offline-html`, `--no-offline-html` | Enable or disable self-contained offline HTML; project default enabled |
| `--offline-html-output PATH` | Exact self-contained `.html` destination |
| `--html`, `--no-html` | Enable or disable the conventional large MyST site; default disabled |
| `--pdf`, `--no-pdf` | Enable or disable experimental PDF export |
| `--pdf-output PATH` | Exact PDF destination; requires positive `--pdf` |
| `--tex-bin DIRECTORY` | Prepend a TeX directory for PDF child processes |
| `--title TITLE` | Plain document title |
| `--subtitle SUBTITLE` | Plain document subtitle |
| `--author AUTHOR` | Plain author; repeat to preserve author order |
| `--language TAG` | Hyphen-separated language tag such as `de` or `de-AT` |
| `--date YYYY-MM-DD` | Publication date |
| `--vocabulary MODULE` | Trusted vocabulary provider; default `muvocab` |
| `--config VALUE` | Context setting; repeatable |
| `--items-dir PATH` | Canonical reusable-item directory; defaults from `MUWEAVE_ITEMS_DIR` |
| `--images-dir PATH` | Canonical shared-image directory; defaults from `MUWEAVE_IMAGES_DIR` |
| `--interactive-dir PATH` | Canonical installed `.muweb` module directory; defaults from `MUWEAVE_INTERACTIVE_DIR` |
| `--persons-dir PATH` | Canonical person-library directory; defaults from `MUWEAVE_PERSONS_DIR`. |
| `--publish`, `--no-publish` | Suppress or restore working-only vocabulary content; default is working mode |

`--config name` stores `True`, `--config ~name` stores `False`, and
`--config name=value` stores the exact text after `=`. The resulting settings
initialize the context's reserved `config` object before setup and expansion.
With MuVocab, `--publish` skips `µprivate{...}` bodies before nested
evaluation and cannot be undone by later source configuration.

`--pdf-output` must end in `.pdf` and requires positive `--pdf`. `--tex-bin`
also requires positive `--pdf` and changes only the environment of the child
PDF process.

`--offline-html-output` must end in `.html` and is incompatible with
`--no-offline-html`.

The command exits with status `0` for success/help/version, `1` for a
processing or build failure, `2` for invalid usage, `3` for input/output or
UTF-8 failure, and `4` for setup read/compile/runtime failure.

## Layered arguments and source directives

For file input, arguments are applied from lowest to highest precedence:

1. ancestor `.mu/arguments` files, from the shallowest ancestor downwards;
2. matching ancestor `.mu/pymyst.arguments` files in the same order;
3. consecutive `µ!` lines at the beginning of the source;
4. explicit process arguments.

Initial directives may be unqualified or scoped:

```text
µ! --config school=fms
µ! pymyst --language de-AT
µ! pytex5 --language de
```

The first two apply to PyMyST. A directive scoped to another known frontend is
consumed but ignored. Removed directive lines retain their physical positions
for diagnostics and source maps.

The inheritable allowlist consists of the shared metadata options,
`--vocabulary`, `--config`, `--items-dir`, `--images-dir`,
`--interactive-dir`, `--persons-dir`, the publication
switch, `--template`, `--site-template`, `--pdf`,
`--no-pdf`, `--offline-html`, `--no-offline-html`, `--html`, and `--no-html`.
Input/output paths, setup scripts, `--document`, `--project`, offline/PDF
destinations, `--tex-bin`, help, and version remain explicit process controls.

### Setup scripts

Each repeatable `--setup PATH` runs in order after the vocabulary has created
the fresh context and before source expansion. Ordinary definitions become
visible to later expressions:

```python
# project.py
school_name = "Example School"
```

```bash
printf 'School: µschool_name\n' | pymyst - --setup project.py
```

The setup execution namespace also contains `context`, allowing deliberate
command and renderer registration. Prefer importable modules for reusable
project functionality.

## Templates and metadata

Shared metadata has this Python contract:

```text
title: str | None = None
subtitle: str | None = None
authors: tuple[str, ...] = ()
language: str | None = None
date: datetime.date | None = None
```

Authors must be nonempty strings without edge whitespace. Language tags contain
alphanumeric subtags separated by `-`. Title, subtitle, authors, and date are
serialized as protected YAML data. Author names use CSL's literal-name form.

MyST has no supported document-frontmatter field for the portable `language`
value. The default template therefore does not emit one. The value remains
available to trusted templates, is stored on `MystProject`, and is applied as
the root `<html lang="...">` attribute after a successful HTML build.

A custom template is trusted MuWeave source and may insert:

```text
µ__pymyst_document__.frontmatter()
µ__pymyst_document__.body()
```

The runtime also exposes its validated metadata as attributes for deliberate
trusted-template use. `body()` inserts the original `ParsedSource` at that
exact point. Template prefix, body, and suffix share one context, evaluation
order, reference phase, and finalization boundary without reparsing the body.

## Project structure and rendering policies

The default `myst.yml` describes one `index.md` page, enables heading
numbering, and selects `book-theme`. `--site-template` changes that exact MyST
template identifier or path.

The dependency-free `pymyst.mjs` document transform adapts target-neutral
MuVocab output to the MyST project:

- it turns MuVocab's unnumbered marker into a non-enumerated heading;
- it applies encoded continuous delimiter-size factors after KaTeX rendering;
- it realizes semantic left-margin block numbers;
- it right-aligns semantic solution-end marker lines;
- it presents marked MuVocab horizontal partitions with their relative widths,
  gap, and per-part alignment.

The official project initially uses MyST's native KaTeX mathematics path. The
policy plugin is part of projects produced by `build_project`; a standalone
`.md` page does not include or execute it.

## Local assets

A vocabulary renderer such as MuVocab's `File(...).image()` registers an
existing local source with the active `PymystContext`. The registry produces a
safe relative path below `assets/`, deduplicates the same canonical source, and
adds deterministic suffixes for basename collisions.

For standalone CLI file output, PyMyST snapshots the context registry and
copies every required file under the selected page's parent before atomically
replacing the page. For example, `--output public/chapter.md` publishes a
reference such as `assets/plot.png` as `public/assets/plot.png`. Standard
output has no stable companion-file root and is rejected when the document
registered local assets.

Project mode applies the same registry snapshot below `PROJECT/assets/` before
publishing the project source and its support files.

Programmatic standalone publication is available when a `MystProject` has been
built:

```python
from pathlib import Path
from pymyst import build_project, publish_document

project = build_project(parsed_body, context)
published_paths = publish_document(project, Path("public/chapter.md"))
```

This is the same page-and-assets operation used by standalone CLI file output.
It deliberately omits `myst.yml` and `pymyst.mjs`. Use
`publish_project(project, directory)` for the complete buildable project.

## Offline HTML, conventional site, and experimental PDF

`build_offline_html` publishes the immutable project into a temporary
directory and asks MyST for a JATS/XML intermediate representation:

```text
myst build index.md --jats --force --output TEMP/document.xml
```

PyMyST converts that structure and MathML to its package-owned interactive
shell, embeds registered local images as data URLs, and atomically replaces one
exact `.html` destination. The result has no theme directory, server, network,
or runtime companion assets. The temporary project is discarded.
Marked MuVocab horizontal partitions become CSS grids in this conversion.
Marked wrapped side objects become CSS floats, allowing their body text to
resume full width below the object. Their dimensions and alignments agree with
the corresponding policies in the normal project.

The current worksheet shell keeps handwriting as normalized, pressure-aware
vector points and rebuilds smooth outlines with the locally bundled
`perfect-freehand` runtime. The source-derived document has a fixed 21 cm width,
an A4 minimum height, and an 18 cm content width; longer author content extends
that surface vertically. On a narrow viewport it retains its logical width and
the workspace scrolls horizontally. The shell adds no sample prose, response
field, sample page, or navigation to the author body. The view-scale control
scales document content and annotations as one unit without reflowing text.

A fixed palette occupies the left side outside the page stack. Drag its vertical
right-edge splitter to change the reserved horizontal space from 230 to 500
pixels. When the splitter has keyboard focus, Left and Right change the width
by 10 pixels, Shift changes it by 50 pixels, and Home and End select the two
limits. Two compact `−`/`+` rows remain fixed at the palette's top: **Palette**
scales its text, controls, and spacing from 75 to 140 percent, while **Document**
scales page content and annotations together from 70 to 140 percent. Every
click changes the selected scale by five percentage points. These controls do
not move when either scale changes. All three view settings persist in saved
copies; palette scaling leaves document geometry unchanged. The palette's
**Document bedienen** mode makes the transparent canvas ignore pointer input,
so links and author-provided controls remain usable. Selecting pen, fountain
pen, highlighter, line, selection, or eraser activates one canvas spanning the
complete document surface. Drawing history and selection are therefore global.
Scrolling over the palette is contained there, including at its upper and lower
boundaries, instead of continuing into the document.

Four compact pattern buttons select solid, dashed, dotted, or dash-dot strokes
without opening a menu. The active button remains visibly pressed and has a
textual accessible label. The selected style applies to straight lines and to
freehand curves drawn with the pen, fountain pen, or highlighter. A solid
freehand stroke retains its pressure-dependent outline. Patterned freehand
strokes follow the same smoothed centreline with constant width, because a
dashed Canvas path cannot retain `perfect-freehand`'s filled pressure outline.
Changing the style while any drawing elements are selected restyles them as one
undoable operation. Holding the end of a freehand stroke straightens it using
the current style. Lines can snap to existing endpoints or a movable ruler; an
optional length uses logical document centimetres. A tap selects one stroke; a
lasso selects every fully enclosed stroke, and dragging moves the selection.
The eraser offers two explicit modes. **Bereich** is the default and removes
only the continuously swept part of every touched stroke, splitting the
remaining vector into independently selectable fragments. **Element** removes
each touched stroke completely. One uninterrupted eraser gesture is one undo
operation in either mode. Transient selection graphics are omitted from print
and saved state.

Worksheet state format 6 retains author-provided responses, palette settings,
global strokes, line styles for straight and freehand strokes, ruler, and view
scale. The version-6 runtime still accepts formats 1 through 5 from the earlier
worksheet prototype. Freehand strokes saved by an older format default to
solid. See the [dependency rationale](../DEPENDENCIES.md).

`build_html` invokes this argument vector from the published project root:

```text
myst build --html
```

It requires generated HTML below `_build/html/`, validates each root HTML tag,
and applies the retained portable language to every generated page. It returns
captured stdout/stderr and the ordered generated paths.

Experimental `build_pdf` invokes MyST's PDF export for `index.md`, writes to a
temporary sibling of the selected destination, validates the PDF signature,
and atomically replaces the destination only after success. PyMyST does not
install MyST or TeX itself.

If a requested external build fails, already published project source remains
available for inspection. Neither low-level preprocessing nor document
composition invokes an external builder unless project/build options request
one.

## Source maps

`--source-map` publishes a versioned provenance sidecar named
`OUTPUT.muweave-map.json`. For a project this is
`PROJECT/index.md.muweave-map.json`. The map contains source/output identities,
Unicode coordinates, hashes, and provenance, but no document contents. Page
and sidecar are separately atomic; consumers must validate the stored output
hash before using mapped positions. Source maps require file output.

PyMyST currently has no downstream MyST diagnostic mapper. Generic trace and
source-map inspection remains available from `muweave`.

## Public Python API

The package root exports only PyMyST-owned operations and immutable result
types. Generic parse, trace, renderer, reference, and source-map types remain in
`muweave`.

### Expansion and document composition

```python
expand_fragment(text, context, *, source_name="<string>",
                output_name="<string>", render_value=render_muweave,
                trace=None) -> str

expand_string(text, context=None, *, source_name="<string>",
              output_name="<string>", render_value=render_muweave,
              trace=None, start_offset=0) -> str

expand_parsed(parsed, context=None, *, output_name="<string>",
              render_value=render_muweave, trace=None) -> str

build_document(body, context=None, *, title=None, subtitle=None, authors=(),
               language=None, date=None, template=None,
               template_name="<pymyst default template>",
               output_name="<string>", trace=None) -> str
```

`expand_fragment` retains deferred capsules and requires the same context for a
later complete expansion. Ordinary callers use `expand_string`.
`build_document` requires an unexpanded `muweave.ParsedSource`, not a string.

### Project construction and publication

```python
build_project(body, context=None, *, title=None, subtitle=None, authors=(),
              language=None, date=None, template=None,
              template_name="<pymyst default template>",
              site_template="book-theme",
              output_name="<myst project>/index.md", trace=None)
    -> MystProject

publish_document(project, output_path) -> tuple[Path, ...]
publish_project(project, project_directory) -> tuple[Path, ...]
```

`MystProject` contains `document_path`, `document`, `configuration_path`,
`configuration`, `plugin_path`, `plugin`, `language`, and `assets`. Building it
is pure: it writes no files and invokes no external tool.

### External builders

```python
build_html(project_directory, project, *, executable="myst")
    -> MystHtmlBuild

build_offline_html(project, output_path, *, executable="myst")
    -> MystOfflineHtmlBuild

build_pdf(project_directory, project, output_path, *, executable="myst",
          tex_bin=None) -> MystPdfBuild
```

`MystOfflineHtmlBuild` records the exact output path plus MyST stdout/stderr.
`MystHtmlBuild` records the project directory, HTML directory, generated HTML
files, stdout, and stderr. `MystPdfBuild` records the project directory, exact
output path, stdout, and stderr. External failures use `PymystBuildError`.

The exact root surface is:

```text
MystHtmlBuild, MystOfflineHtmlBuild, MystPdfBuild, MystProject,
PymystBuildError, PymystContext, __version__, build_document, build_html,
build_offline_html, build_pdf, build_project, expand_fragment, expand_parsed,
expand_string, publish_document, publish_project
```

Private project-policy helpers and the delimiter-marker integration protocol
are intentionally not root APIs.

## Common recipes

```bash
# Standalone page without external tools
pymyst chapter.pymyst

# Complete page with frontmatter but no project
pymyst chapter.pymyst --document --title "Mechanics"

# Publish project source without invoking MyST
pymyst chapter.pymyst --project build/chapter.myst --no-offline-html

# Build self-contained offline HTML as chapter.html
pymyst chapter.pymyst --project build/chapter.myst

# Also build the conventional large MyST site
pymyst chapter.pymyst --project build/chapter.myst --html

# Build experimental PDF only
pymyst chapter.pymyst --project build/chapter.myst --no-offline-html --pdf
# writes build/chapter_myst.pdf
```
