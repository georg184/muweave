# MuWeave Suite open questions

## AI learning-coach context

### AI-CONTEXT-01 — Publication and occurrence identity

The [initial paragraph coach](../pyhtml/docs/LEARNING_COACH.md) uses an explicit
logical document key, exact publication digest and semantic tree paths joined
to the same typed expansion. Repeated item appearances have separate targets
while retaining existing item/part identities. That publication-local binding
is implemented; it does not migrate saved work or conversations after editing.
Which paragraph and item associations can be retained safely across revisions,
extensions and renames? Which changes need explicit migration or an
unresolved-work state? Input IDs must continue to reuse existing worksheet
identities rather than visible numbers, file offsets or screen positions.

### AI-CONTEXT-02 — Time and history granularity

Which events retain creation/change/deletion times: an answer submission, a
stroke, an edit group, or a full interaction? What history supports comparisons
across days and weeks, beyond the current undo/redo buffer? How are local-clock
uncertainty, timezone information, imports, missing historical times, and
retention limits represented? Are session/time-range views sufficient, or is
there a separate user-facing need for chronological drawing layers?

### AI-CONTEXT-03 — Visual snapshots and content anchoring

What resolution, cropping, and tiling rules make a PNG view of handwriting
legible without sending the entire document? How should a coach see both
author scaffold and learner marks while retaining their distinct origins?
How are freehand root-overlay regions attached to semantic content across
document revisions, and which coordinate metadata belongs only in the snapshot
renderer rather than in the model's reading context?

### AI-CONTEXT-04 — Runtime context and disclosure

Which generic module/notebook interface exposes the currently shown generated
question and results without copying executable source or invoking author
expansion again? Which learner records, images, and chat history are selected
for each request, and how are user consent, provider transport, and tutor
policy delivered separately? The authoring scopes for pedagogical instructions
are addressed in AI-CONTEXT-05. The absence of these runtime features must not
block a complete static author export.

### AI-CONTEXT-05 — Author-defined question starters

General and local pedagogical guidance now uses MuVocab's `coach` annotation;
its nested scope and composition rules are documented in the
[authoring guide](../muvocab/docs/AUTHORING.md#coaching-instructions).
The initial UI offers editable explanation/hint starters. Which additional
learner-visible starters may an author supply or customize at a target?

### AI-CONTEXT-07 — Private classroom hosting

The user supplied a separate OpenRouter key intended for public use, with a
limited funded allowance; individual learner accounts are not needed for that
trial. Direct public access is implemented in standalone HTML and does not
require hosting; the build/operator contract is in the
[coach guide](../pyhtml/docs/LEARNING_COACH.md).
For a future classroom service with server-held private credentials, where
should it run, and which access rules and centrally enforced usage budgets
should apply? The shared public trial account and its direct transport are settled.

## Exam scanning

### EXAM-SCAN-01 — Printed markers and page identifiers

Which geometric marker family, sizes and quiet margins survive
the actual copier workflow while preserving enough writing space? How should
the importer orient and match simple identical squares, or should the print
use coded fiducials? How many distributed marks and which minimum detected
subset are appropriate? Decide through the print
prototype in the [exam-scan plan](docs/PLAN-PRUEFUNGSSCANS.md).
The choice of two larger copies of the same page QR is settled in the shared
print template (see the plan). Do its new quiet zones and placements survive
the actual copier's edge cropping and partial occlusion? Physical acceptance
is still open; it must use new print samples, not change retained originals.
Generic supplements deliberately have no QR or exam binding. The importer uses
contiguous submission order and explicit exam START boundaries; which neutral
fiducials and layout checks best distinguish the permitted supplement layouts
from an exam page with a damaged code?
