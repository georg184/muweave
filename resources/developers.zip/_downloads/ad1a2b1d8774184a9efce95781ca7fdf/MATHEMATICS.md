# Mathematics in direct HTML

Audience: document authors, consumer developers, and AI authoring models

PyHTML renders MuVocab mathematics directly from the prepared MuDoc tree. It
does not pass through MyST or JATS. By default, a pinned MathJax 4.1.3 component is embedded
in each HTML document that contains math, so the result opens through
`file://` without a server or network connection. Text-only documents do not
contain MathJax.

## Experimental native MathML

The renderer choice has the same qualified spelling in both frontends:

```console
pyhtml lesson.muweave --html-math-renderer=mathjax
pyhtml lesson.muweave --html-math-renderer=typst-mathml
mucompose lesson.muweave --html-math-renderer=typst-mathml
```

`mathjax` remains the default. The option is inherited through frontend-scoped
`.mu/pyhtml.arguments`, `.mu/mucompose.arguments` and initial `µ! pyhtml ...` /
`µ! mucompose ...` directives. Explicit CLI arguments take precedence.
MuCompose forwards the option only to its HTML child. Choosing this renderer
does not select a new backend, change HTML target conditions, or rename the
ordinary `.html` output. Use PyHTML's `--output` or MuCompose's `--html-output`
to retain two comparison artifacts.

The optional build dependency is `pyhtml[typst]`, currently bounded to the
tested Python binding `typst>=0.15,<0.16`. Missing/incompatible installations
give an error; ordinary MathJax builds do not load that dependency. PyHTML
compiles each complete formula from vocabulary-generated Typst, extracts
native MathML and its CSS, and embeds an unmodified Latin Modern Math 1.959
font. The result opens offline without Typst, WASM, MathJax or KaTeX on the
learner's machine. Normal worksheet JavaScript remains present.

The supported MuVocab subset now includes:

- `m` and `block.equation`, including structured cells and row labels;
- `frac` and `sqrt`, with brace bodies, direct objects, and µ-bearing Python
  strings expanded exactly once, including nested fractions and roots;
- coordinate points/vectors, matrices, named points and connection/vector arrows;
- units and quantities, intervals, automatic/fixed/minimum-size fences,
  lengths and quantifiers;
- literal `mtext`, named `mop` operators, `accent`, `overunder`, `mathstack`
  and explicit `mathspace`, including nested retained source;
- inner mathematical colors/tooltips, blanks/phantoms, and explicitly
  underlined blanks, including hidden answers;
- explicit inline `µallowbreak` boundaries, preserving nested semantic values;
- simple existing `Term` expressions: numbers, symbols, pi,
  arithmetic, powers, roots, and sin/cos/tan/exp/log;
- text leaves with decimal numbers, individual Latin/Greek letters, ordinary
  operators, visible `(...)` / `[...]`, invisible grouping `{...}`, and
  single-token or braced scripts. Write `x^{12}`, not ambiguous `x^12`.

Adjacent letters remain separate variables, not function names. Use semantic
`mop` for operator notation or `Term` for calculated functions. A literal slash remains a
slash; use `µfrac` for a fraction. These leaves are a bounded shared notation,
not raw Typst and not a general TeX-to-Typst translator.

```text
µblock.equation{µfrac{1,,1+µsqrt{a^2+µfrac{1,,2}}}=µv(3,5)}
µsqrt(frac("9", "4"))
µsqrt("µfrac{9,,4}")
```

Complete-formula/cell colors and tooltips, equation numbering and ordinary
references stay in the HTML layout. The AI bundle comes from the exact same
typed expansion and is independent of this presentation choice. Generated
MathML is source-mapped to its owning formula occurrence, not character-for-
character back into the generated Typst/XML.

Equation-reference previews reuse retained source without evaluating it again.
Graphic and native reactive-graphic labels use MathML in the existing HTML
overlay, not MathML nested inside an SVG text node. `trim` and directed column
height matching measure native formula boxes after font loading. Angles use
the separate provisional MuGeometry profile
`muweave-native-mathml-lm-1.959-box-v1`: its browser boxes are not certified
MathJax ink bounds and have no direct native observations yet.

The shell-free APIs `expand_body_string` and `expand_parsed_body` accept the
same `html_math_renderer` keyword. Reader notebook protocol 2 forwards the
publication's choice on every manual run. Result CSS accompanies the MathML;
the host already contains the pinned font and optical measurement runtime,
even if its initial content has no formula. Repeated runs replace the previous result. Ordinary browsers show the
authored result but do not execute new MuWeave source.

Current limits are explicit: raw TeX commands, unsupported semantic math
values and continuous fence `size_factor != 1` are not supported. Underlined blanks
use an adapter-owned outer MathML rule: Typst 0.15 drops its own `underline`
decoration. The rule stays visible when the answer is hidden and retains the
surrounding color. Native `allowbreak` splits the inline math into retained
segments with HTML break opportunities; it does not re-evaluate the source.
External `.muweb` modules requiring a MathJax runtime still fail in native
mode. A notebook result does not activate new nested interactive modules.
There is no hidden fallback or additional MathJax runtime.

**Spacing:** native MathML supports the shared occurrence-local
[`math.fraction.*` and `math.matrix.*` policies](../../muvocab/docs/AUTHORING.md#compact-coordinate-vectors-and-matrices),
including overrides and smaller script styles. An embedded script measures
after font loading, repeats on font-size changes, and handles late Reader
results. Fractions remain `mfrac`, with a fixed mathematical-axis rule and
unchanged glyph sizes. Matrices remain `mtable`, with measured row clearances
and native stretching parentheses. The approach uses MathML's explicit
`mpadded` box/offset model, not CSS margins pretending to control a fraction's
inner gap. [MathML Core](https://w3c.github.io/mathml-core/#fractions-mfrac),
[mpadded](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mpadded).

**Parentheses:** `math.fence.gap_em` adds explicit inner clearance (default
`0`); `math.matrix.fence_size` selects `"auto"` or a fixed family `0`–`4`.
Explicit `fence`/`Set` values use their `size`/`min_size` arguments. Native
fixed sizing sets both `minsize` and `maxsize` on the pair's own `mo` elements;
a minimum leaves `maxsize` free. Family zero disables stretching. No glyphs
or fraction contents are scaled. These size attributes also work without JS.
[MathML operator sizing](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mo).

Our marked matrices remove the first/last-column outer horizontal cell padding
(`0.4em` per side by the MathML standard), while preserving internal column
gaps. This corrects the unusually large vector-parenthesis clearance without
changing Latin Modern Math. Natural glyph side bearings and available
delimiter sizes still depend on the font and browser.
[MathML Core cell defaults](https://w3c.github.io/mathml-core/#entry-in-table-or-matrix-mtd).

Ordinary token heights come from the loaded font's actual glyph metrics,
avoiding Firefox's extra DOM line leading. Complex native constructs such as
radicals and stretched accents conservatively keep their native box; explicit
phantoms/padding remain intentional space. Thus the common policy does not
promise pixel identity between browsers or between native MathML and MathJax.
Ordinary `Term`-generated fractions keep native spacing unless explicitly
constructed with `frac`. Without JavaScript, formulas still display as native
MathML but receive no optical correction. Real Chrome, Firefox and Reader
tests cover the policy; this is not a screenreader/accessibility certification.

The executable comparison is in the workspace at
`muweave_documents/math_renderer_comparison.muweave`.
It includes editable cells, a triangle/equation height comparison and a
velocity slider. The complete author corpus has now been inventoried and its
ordinary mathematics migrated: Kinematik, both vector lessons, and all 73
library items with their companion parts also build with native MathML.
The spacing-comparison document also builds natively. Editable fraction and
parenthesis presets, with actual/default values, live in `showcases.muweave`.
The full native showcase builds with `--config ~showcase.embed_modules`, which
explicitly changes its MathJax-dependent Motion example to an external link.
Without this option its requested embedded runtime still fails. The six fixed
arrow experiments in `Vektorpfeil_Varianten.muweave` remain explicitly native
TeX demonstrations. These are classified examples, not a silent fallback.
The remaining sections describe the default MathJax path unless stated
otherwise.

## Author syntax

Write TeX-style source without target delimiters:

```text
Die Geschwindigkeit ist µm{v(t)=v_0+at}.

µblock.equation(r"F=ma", label="eq:force", tag="N2")
```

`m(text)` is inline mathematics. `block.equation(...)` is the only display
mathematics operation. The brace form is available for one formula:

```text
µblock.equation[label="eq:energy"]{E=mc^2}
```

Numbers, tags, labels, and references are prepared target-neutrally before
HTML rendering. MathJax typesets only the formula. Consequently a LaTeX, MyST,
and direct-HTML expansion of the same source receives the same allocated
designation.

## Inline line breaks

An ordinary `µm{...}` formula is one indivisible MathJax SVG. MathJax's own
automatic inline line breaking is disabled, so browsers cannot choose a
different internal break near a relation such as the `=` in `µm{a=0}`.

For a long formula, put bare `µallowbreak` at an explicitly safe optional
boundary:

```text
µm{x_1,\dots,x_n, µallowbreak y_1,\dots,y_m}
```

PyHTML emits one atomic MathJax span for each side and exactly one `<wbr>` at
the marker. The marker is not visible and does not force a new line. It must
have nonempty mathematics on both sides and must not be repeated directly.

Choose a boundary between self-contained mathematical phrases, preferably
after punctuation. Do not put `µallowbreak` immediately before or after `=`,
`+`, `-`, another relation, or another binary operator: the separate MathJax
spans cannot preserve an operator's spacing relationship across that boundary.

## Aligned systems

Use one `block.equation.row(...)` value per line. Every row argument is one
conceptual column. An ordinary string is an ordinary cell; one equation-local
`µalc` marker gives that cell an inner alignment boundary:

```text
µblock.equation(
    rows=(
        block.equation.row(r"v µalc = v_0 + at"),
        block.equation.row(r"s µalc = s_0 + v_0t + \frac12at^2"),
    ),
    label="eq:motion",
    tag="Bewegung",
)
```

PyHTML places the resulting rendering tracks in shared CSS grid columns. With
`numbering="system"`, the entire grid has at most one designation. With
`numbering="rows"`, put `label`, `tag`, and optional `numbered` values on
individual rows:

```text
µblock.equation(
    rows=(
        block.equation.row(
            r"v µalc = v_0 + at",
            label="eq:velocity",
        ),
        block.equation.row(
            (r"s", r"= s_0 + v_0t + \frac12at^2"),
            label="eq:path",
            tag="Weg",
        ),
    ),
    numbering="rows",
)
```

Each row label becomes an exact HTML anchor. `ref(...)` creates a normal local
link to that anchor.

The two-string tuple is the canonical Python alternative to `µalc`:

```text
block.equation.row((r"a^m \cdot a^n", r"= a^{m+n}"))
```

`µalc` is structural data for an equation cell, not an evaluated MuWeave
command. Spaces and tabs immediately beside it are ignored. An ampersand is
ordinary exact TeX-style source and is never repurposed; write `\&` when the
formula should display an ampersand.

Every populated cell in one conceptual column must consistently be ordinary
or aligned. Trailing cells may be absent. Ordinary columns default to centered
placement; use `columns=("left", "center", "right", ...)` to select their
placement. PyHTML adds inter-column spacing and sufficient vertical row space
itself; authors do not insert `\quad`, `\vphantom`, or manual line spacing.
Tall fractions and fences therefore enlarge their row without colliding with
adjacent rows. The free spaces before, between, and after the conceptual
columns are equal whenever the system fits. They shrink together toward zero
as the formulas need more room. The optional designation occupies its own
right-edge track and is not a formula column. If even zero additional column
space is insufficient, the equation container scrolls horizontally. PyHTML
never scales the complete system and does not silently reduce its font size.

Inline formulas use TeX text style. Display-formula cells use TeX display style
at the same 10 pt base size as surrounding body text. Fractions, limits, and
large operators therefore receive display-style geometry without independently
enlarging every glyph. Row designations remain ordinary accessible text and
align to the same baseline as their formula row.

## Tooltips and mathematical boundaries

An equation reference can preview its actual semantic target:

```text
µref("eq:power", preview=True)
```

An ordinary equation target contributes its formula. A labeled row in a
structured system contributes the complete row, including all conceptual
cells. The preview is therefore updated automatically when the target changes;
authors must not repeat its formula in a separate tooltip description. Other
reference-target kinds currently reject `preview=True` explicitly.

MuVocab's portable `tooltip` can explain a complete formula:

```text
µtooltip(m(r"a^n b^n=(ab)^n"), "Potenzen mit gleichem Exponenten")
```

Structured systems additionally expose complete conceptual cells and the two
segments on either side of an alignment boundary:

```python
block.equation.row(
    (tooltip(r"a^n", "linkes Segment"), r"=b^n"),
    tooltip((r"x^2", r"=y"), "gesamte konzeptionelle Zelle"),
)
```

An annotation on a two-segment conceptual cell creates one continuous hover
and keyboard-focus trigger spanning both aligned tracks. The tooltip therefore
keeps one stable position while the pointer crosses the alignment boundary.
An annotation on only one segment remains limited to that segment. Direct HTML
does not yet support an annotation inside one undivided TeX-style formula
string. `µm{a+µtooltip[Term]{b}}` therefore raises a located error instead of
silently losing the tooltip. Annotate the complete formula or use a structured
cell/segment boundary.

## Fences, sets, and points

MuVocab math fragments remain composable inside either math operation:

```text
µm{µSet{x \in \mathbb{R},,x^2<2}}
µm{µpoint{3,,-2,,1}}
µm(fence("a", "b", left="[", right="]"))
```

Direct HTML currently supports automatic delimiter sizing, automatic sizing
with `min_size=0..4`, and fixed `size=0..4`. A continuous `size_factor` other
than `1.0` raises a source-located render error; it is not silently ignored.

## Offline boundary

The embedded runtime uses TeX input, SVG output, Latin Modern Math, the pinned
MathJax `color` extension, and a local SVG font cache. All official dynamic SVG
font ranges and that extension are packaged and preloaded inside the document.
Before initial typesetting, PyHTML marks every verified bundled range as
locally resolved and installs it into the active SVG font. Thus infrequent
ranges such as `\mathcal` and `\mathbb` do not fall back to MathJax's default
CDN path in browsers with different startup scheduling. Dynamic `autoload` and
`require` are disabled. Author source therefore cannot request another
JavaScript or font resource at runtime. Commands that depend on an unavailable
dynamic extension are outside the current PyHTML math contract. MathJax
`\text{...}` content inherits the document's embedded Latin Modern Sans face.

Automatic inline formula breaking is also disabled in the runtime. Explicit
`µallowbreak` markers are implemented by MuVocab's HTML structure, not by
MathJax heuristics.

The browser runtime and complete modern SVG font data add approximately 4.7 MB
to a math-bearing HTML file. They add nothing to a document without semantic
mathematics. The four embedded text-font faces are part of every document;
authored local files are handled independently by PyHTML's shared
content-addressed store.

## Python and source maps

The normal entry point remains `pyhtml.expand_string(...)` or
`pyhtml.expand_parsed(...)` with `muvocab.create_html_context(schema)`. There
is no separate public MathJax API. Nested MuWeave expressions inside brace
math are evaluated exactly once, and their generated formula characters retain
their own source-map provenance. The MathJax runtime itself is generated shell
content attributed to the document root.

A complete runnable source is available at
[`../examples/mathematics.muweave`](../examples/mathematics.muweave).
