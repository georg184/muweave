# Offline worksheet

Audience: MuWeave authors and users of generated PyHTML documents

Every ordinary `pyhtml` build returns one self-contained interactive HTML
worksheet. Open the `.html` file directly in a current browser; no server,
Node.js installation, MyST project, or network connection is required.

Working output shows a small **Arbeitsfassung** badge outside the authorial
flow. MuVocab `µprivate{...}` notes occupy the otherwise unused right author
rail; browser layout stacks nearby notes so they do not cover each other and
they never reserve body space. MuVocab supplies their orange foreground,
white background, and orange accent through its backend-neutral theme. Structured-item
badges show only the bare ID, identically for every part, and use the same
working-presentation principle. Use `--config ~author.private` or
`--config ~author.item_ids` to hide either category while editing. Use
`--publish` for learner-facing output: it removes all three working indicators
and skips private bodies before nested evaluation, while leaving stable item
identity in worksheet and embedded AI data.

## Contents navigation

An **Inhaltsverzeichnis** icon appears immediately beside document zoom when
the vocabulary supplies selected headings. Click it to open a scrollable
hierarchy over the document. The currently read section is highlighted. A
heading link jumps below the fixed controls, transfers keyboard focus to the
heading, and closes the panel. Escape and the close button return focus to the
icon; moving focus or clicking outside also closes the panel. The controls
remain above the global drawing layer. Opening them reserves no document width
or height and cannot change normalized ink coordinates.

For MuVocab documents, contents are enabled by default and include logical
levels 0 through 2, including unnumbered headings. Configure them at build time:

```text
µ! pyhtml --config toc
µ! pyhtml --config toc.max_level=2
```

`pyhtml lesson.muweave --config ~toc` disables the control;
`--config toc.max_level=5` includes all six levels. Existing target-qualified
`µ!` directives also work when building with MuCompose. The vocabulary resolves
these initial settings independently of later `config.set(...)` calls. They
filter only navigation, not headings, numbering, reference targets, or the
embedded AI context. Empty contents have no button.

Rebuild older HTML files and reload them to obtain this control. The same
offline artifact works in an ordinary browser and MuWeave Reader. Panel state
and its current-section mark do not enter `.work`; an HTML copy resets the
panel to closed too. Newly evaluated notebook fragments have isolated heading
anchors and do not create a second document contents panel or modify the
original navigation/AI expansion.

## Document and sidebar

The authored document is a fixed A4-width surface. CSS defines `1in = 96px`
and `1in = 2.54cm`, so its 210 mm width is retained as the fractional value
`793.700787401574803px`, not rounded to 794 px. It uses embedded Latin Modern
Sans with configurable defaults of 10 pt base size, a 1.35 body
line-height, a 1.25 geometric font-size step, 0.5 body-font units of additional
blank-line paragraph spacing, and a compact 1.2 heading line-height. Set them
through initial `--config` assignments named `typography.font_size_pt`,
`typography.line_height`, `typography.scale_factor`,
`typography.paragraph_gap`, and `section.line_height`; an initial `µ!` block
uses the same options. `µsize[n]{...}` selects the absolute signed step `n`.
The step may be any finite real number; the resulting shared size is rounded
to `0.001 pt`. Headings use the same factor unless the exceptional setting
`section.scale_factor` explicitly overrides headings alone; normally leave it
unset. The authorial body occupies
76% of the surface by default, leaving equal 12% side margins. Set another ratio in `(0, 1]` with
`--body-width-ratio RATIO` or the Python API's `body_width_ratio` argument.
The fixed width prevents later viewport changes from reflowing text under
existing strokes; a narrow browser window scrolls horizontally.

The screen document has continuous height. PyHTML no longer simulates A4 page
height or inserts screen page breaks. `--body-height-ratio RATIO` and the
Python API's `body_height_ratio` nevertheless control equal initial and final
whitespace calculated from the A4 height belonging to the fixed document
width. The default `0.9` models 5% above and below; it does not constrain the
continuous content height. Actual browser printing may still paginate on A4
through its print stylesheet, with final scaling controlled by the browser and
printer. The ruler interprets the complete surface width as 21 logical
centimetres. Document text uses justified alignment by default; the root
language metadata enables the browser's available automatic hyphenation. An
explicit MuVocab alignment still overrides that inherited default for its own
content.

The fixed left sidebar does not cover the drawing layer. The full-document
layer behaves as one continuous surface: a stroke crossing an internal tile
boundary is one stroke in `.work`, and Undo, Redo, selection, and erasing act
on that one object. PyHTML uses sparse vertical canvas tiles only as a browser
rendering detail; it does not allocate a bitmap as tall as the complete
document. This keeps very long worksheets usable in Chromium as well as
Firefox. **Arbeitsstand** is a
non-scrolling section pinned at its top, so the persistence colour and actions
remain visible. A compact unlabelled sidebar-zoom group sits above it at the
top left, where changing the sidebar width cannot move it; the document's
matching group is fixed at the top left of the document region and overlays
that region instead of using document space. Both groups use reduced vertical
padding so this persistent interface chrome consumes little height. Each
three-control group carries one shared tooltip across its buttons, input, and
intervening space. A separate region below the work state
scrolls **Zeichenpalette** and **Ausgabe** while containing wheel scrolling at
either end. The drawing palette is therefore one part of the sidebar rather
than the complete sidebar. Dragging the outer splitter changes the one sidebar
scale: occupied width, controls, and type change together, and the displayed
percentage follows in 0.1-percentage-point increments. That percentage is also
directly editable from the keyboard. The adjacent `−`/`+` buttons move to the
next lower or higher 5% grid value. All three interactions write the same
`settings.sidebar.controlScale`; there is no independent saved width. The
sidebar range is 50–200%. The document retains its separate editable
percentage and `−`/`+` buttons but no splitter; its wider 25–300% range supports
both a compact overview and substantial enlargement without relying on a
learner knowing the browser's own zoom control. Scaling it transforms content
and annotation layer together. One central sidebar font size makes ordinary
buttons consistent, including the eraser-mode buttons; headings and helper
labels derive their smaller sizes from it. The base lettering is deliberately
12.5% larger than the geometry's original type scale. Compensated line heights,
padding, gaps, and control sizes keep the established layout dimensions
unchanged. At browser zoom 100%,
the displayed sidebar and document values of 100% use authoring baselines of
75% and `168.5%`, respectively. The document baseline incorporates the local
A4 calibration. The first standards-width build measured 21.03 cm on the
reference display, so its provisional factor is corrected to 21 cm and rounded
to four significant digits:

```text
logical A4 width = 21 cm * 96 px/in / 2.54 cm/in
                 = 793.700787401574803... CSS px
exact correction = 1.686378571428571... * 21 / 21.03
                 = 1.6839728959...
fine calibration = pyhtml.geometry.DOCUMENT_BASE_SCALE
```

The order of magnitude has a useful physical interpretation. A 1920 by 1080
display has about 2202.91 pixels along its diagonal. At 96 pixels per inch that
would be 22.95 inches; at 14 inches it has about 157.35 pixels per inch, a
ratio of about 1.64 to 96. The retained empirical factor corresponds to about
13.62 inches under that simplified one-device-pixel-per-CSS-pixel model. As of
July 2026, 1920 by 1080 was the largest individual worldwide desktop category
reported by [StatCounter](https://gs.statcounter.com/screen-resolution-stats/desktop/),
at 22.3%.

That calculation explains the scale but cannot replace calibration. CSS
defines a reference pixel by visual angle and recommends pixel anchoring for
screens; CSS centimetres therefore need not be physical screen centimetres.
Operating-system scaling, device pixel ratio, and browser page zoom further
change the mapping. See
[CSS Values and Units Level 4](https://www.w3.org/TR/css-values-4/#absolute-lengths)
and Chromium's
[coordinate-space description](https://www.chromium.org/developers/design-documents/blink-coordinate-spaces/).
The displayed percentages are relative to their authoring baselines; they do
not repeat the browser's own zoom value. The document
percentage is an editable number field: type an exact value or use its arrow
keys for 0.1-percentage-point steps. The adjacent `−` and `+` buttons retain
their faster 5-point steps. To check or refine physical A4 width, leave browser
zoom at 100% and adjust the document field until the white 21 cm surface agrees
with a sheet or physical ruler.

## Item-owned local work surfaces

MuVocab can place `response.canvas(...)` only inside a structured item source.
PyHTML renders its fixed viewport, optional label, and blank, squared, lined,
or dotted paper. Its runtime key contains the item, exact selected part, and
local canvas name—for example
`35341/solution/canvas/calculation`. Reusing the same local name in another
item therefore does not collide.

The pinned sidebar layer selector and the **Aktivieren** button at the surface
select the same pen, line, selection, and eraser tools used by the full-page
overlay. The highlighted frame and central selector identify where new strokes
go; the local toolbar deliberately adds no redundant status line. A canvas
nested in a solution uses the complete prepared designation, such as `Lösung
von Beispielaufgabe 2.1.`, in the selector and tooltips; technical state paths
remain internal. An explicit canvas `label=` overrides that derived control
name. Undo and redo affect only the active layer. Each local surface has
independent strokes and history in `.work`. On a full-width surface its compact
controls occupy the document's right margin rather than reducing the paper
width. Their type and geometry derive from the document typography. In
`layout.columns`, a surface in the first or last column places its controls in
the corresponding outer margin. A surface in a middle column keeps the
controls above its paper. Other narrow containers retain the same above-paper
fallback.

An explicit author `height` is a lower bound for the initial paper. When it is
omitted, MuVocab derives that paper height from the complete immutable
underlay stack and uniform `padding`; a content-free canvas falls back to
seven centimetres. The independent optional `viewport_height` fixes the
visible window. Omitting it makes PyHTML fit the viewport to the resolved
initial content, so an authored diagram does not acquire a default scrollbar.
An explicit smaller viewport deliberately scrolls. The optional author
`width` fixes the viewport and initial paper width; omitting it uses the
available text or layout-column width. Authors can therefore put a narrower
surface beside other content with `layout.columns` without granting learner
state control over document reflow.

An author may place an immutable model solution on the paper with MuVocab's
deferred brace form:

```text
µresponse.canvas[
    name="calculation",
    background="squared",
    underlay=(
        g.axis(xmin=0, xmax=4, ymin=0, ymax=5, grid=True),
        g.axis(xmin=0, xmax=4, ymin=-2, ymax=2, grid=True),
    ),
    padding="0.15cm",
]{
Erwarteter Rechenweg mit µbold{verschachteltem MuVocab}.
}
```

The exact visual layer order is paper pattern, ordered authored underlays, model
solution, learner ink. With the default `solutions=True`, the model body is
visible in MuVocab's occurrence-local `theme.solution.foreground` color
(default `#800000`) and enlarges the inner paper when its rendered height
exceeds the author minimum. An automatic viewport grows with that initial
content; only an explicit viewport remains fixed and scrolls. Uniform
`padding` is inside the paper around both authored visual layers.
`--config ~solutions` omits the model layer entirely. It does not disable
learner ink, alter the item-qualified layer identity, or depend on `--publish`.
The model solution is immutable document content and is never written into
`.work`.

A learner may enlarge the internal paper width and height in 0.5 cm steps and
scroll it without moving later document content; neither dimension can be
reduced below its resolved author/content minimum. Increasing width adds empty paper on the
right and does not stretch or move existing strokes.
The learner may also change each local paper independently between blank,
squared, lined, and dotted backgrounds. The author-selected background is the
initial and legacy-state default; the learner selection is restored from
`.work` without changing the source document.
Every local surface also has its own 25–300% zoom. Its percentage field accepts
0.1-point steps and the adjacent buttons move to the next 5-point grid value.
The viewport stays fixed while paper dimensions, ruling, strokes, and stroke
widths scale together. At a sufficiently small zoom the whole paper fits and
its scrollbars disappear. The zoom belongs to that item-qualified layer and is
restored from `.work` together with its explicitly enlarged paper dimensions
and drawing history. Automatically derived paper height is rebuilt from the
current document instead of being persisted as a learner override.
Regenerating the HTML retains `.work` records whose item/canvas key is no
longer present, so a temporarily omitted item does not erase its learner work.
Structured expandable scaffold gaps are planned but not implemented. The ruler
currently remains specific to the full-document layer.

## Interaction modes and tools

The pinned **Zeichnen** section directly below **Arbeitsstand** contains one
mode button and the **Zeichenebene** selector. The button reads **Zeichnen
aktivieren** or **Zeichnen deaktivieren**. Drawing mode and selected layer are
independent saved values: changing the selector while drawing is off chooses
the next target without activating it; changing it while drawing is on moves
the active canvas immediately.

When drawing is disabled, pointer interaction passes through every drawing
canvas and the complete palette is functionally disabled under a grey veil.
The work-state controls and layer selector always remain usable. Each local
surface has an **Aktivieren**/**Deaktivieren** mode button outside its disabled
settings. It uses the same inactive and active colours as the corresponding
sidebar button and needs no separate textual layer-status indicator:

- Activating a local surface selects it, updates the sidebar selector, enables
  drawing, and unlocks that surface's paper controls.
- Activating another local surface switches directly to it.
- The active local button deactivates drawing without forgetting the selected
  layer. The root **Gesamtdokument** layer is deactivated through the pinned
  sidebar button.
- Inactive local paper controls are disabled under a light grey veil; their
  activation buttons normally remain available. While drawing is active on
  **Gesamtdokument**, its document-wide canvas lies above every local toolbar,
  so all local activation buttons are visibly veiled and disabled as well.
  Deactivate root drawing or choose a local layer in the pinned selector to
  make those buttons usable again.

The selected mode and layer are restored from the immediate browser mirror and
from `.work`, using the same freshness rules as other learner state. The
drawing tools are:

- **Stift**, **Füller**, and **Textmarker** create pressure-aware vector
  freehand strokes. Holding a sufficiently straight final movement briefly
  converts it to a line.
- **Gerade** draws a line, optionally with an exact logical centimetre length.
  Endpoints can snap to existing line endpoints.
- **Auswahl** lassos one or more elements and moves them together.
- **Radierer** either removes only the traversed portions or complete touched
  elements.
- Four visual line-style buttons apply solid, dashed, dotted, or dash-dot
  patterns to lines and freehand curves.
- **Lineal** displays a movable and rotatable guide over the same canvas.
- The standard curved-arrow **Undo** and **Redo** icons in the pinned
  **Arbeitsstand** section operate on the vector drawing history. Each
  successful history change immediately marks the persistence state as
  changed; there is deliberately no one-click action that clears every stroke.

Every drawing-palette control has a native browser tooltip. Sidebar scrolling
is contained and does not continue by scrolling the document at either end.

## Interactive web modules

MuVocab `block.interactive(...)` places a validated installed `.muweb`
application in the worksheet. It is the sole external MuWeb-application
command and an ordinary referenceable block. The usual form selects a named
activity and its compact view in a sandboxed offline iframe:

```text
µblock.interactive(
    "motion",
    instance="kinematics-uniform-motion-1",
    activity="piecewise_uniform",
    presentation="compact",
    height="11cm",
)
```

Configure its exclusive library with `--interactive-dir` or
`MUWEAVE_INTERACTIVE_DIR`. The required `instance` is the stable learner-state
identity and must be unique in the complete document. Moving the activity or
extending surrounding text preserves state when the instance stays unchanged.
The instance is also the block reference key; `numbered=True` optionally uses
the common block counter.

`activity` selects subject matter or behavior declared by the artifact.
`presentation` independently selects the surrounding view: compact omits an
application's standalone introduction and page chrome, whereas full retains
that complete chrome inside the host. Inline occurrences default to compact
and tab occurrences to full. Both presentations use the same artifact, state
schema, and learner identity.

`open="tab"` launches the same locally composed module in a dedicated tab;
`mode="link", open="tab"` opens only the canonical HTTPS page and requires
the full presentation. Inline
presentation accepts an optional positive centimetre height. Without one, the
artifact's preferred height and content resize messages determine the
viewport. The default sandbox permits scripts but grants neither network nor
same-origin access. Module markup, global JavaScript, keyboard handling, and
browser storage are isolated from the worksheet and other occurrences.

A format-three module may declare an exact shared host runtime. The current
closed registry supports `math: muweave-mathjax-4-svg-v1`. The outer HTML
stores PyHTML's verified MathJax 4 payload once even when the document itself
and several modules need mathematics. Each isolated iframe or tab still needs
its own JavaScript initialization, so the host inserts the stored script text
into the module entry before creating that realm's Blob URL. The completed
worksheet remains self-contained and offline. An unknown role/profile pair is
a build error rather than a network lookup or silent fallback.

Isolation also prevents inherited document CSS. Each occurrence therefore
carries its retained normal point size, line-height multiplier, and
`typography.scale_factor` into bridge initialization. The packaged MuWeb
bridge installs `--muweave-body-font-size`, `--muweave-line-height`, and
`--muweave-size-factor` inside the module and exposes signed point-size steps
through `fontSizePt(step)`. A conforming quiz uses those values instead of its
own unrelated base font or heading scale. This is presentation, not learner
state, and is never written to `.work`. The selected activity is stored for
compatibility; the compact/full view is not.

The module reports complete JSON-compatible state, progress, and result
snapshots through the MuWeb bridge. PyHTML stores them under the instance in
the same immediate IndexedDB and portable `.work` paths as other learner work.
Before explicit save, full-copy save, or page teardown, the host requests a
fresh snapshot. Replacing the HTML preserves a record when module ID and
integer state-schema version still match; a producer release change alone is
compatible. An older schema is upgraded through every module-declared adjacent
migration before the application receives `init`. The host retains the old
record until the final value has passed JSON validation and durable browser
storage. Missing, failed, malformed, timed-out, and future paths retain the
exact record in quarantine, start the current module empty, and produce a
visible compatibility notice. The module developer contract is documented in
the [MuWeb bridge guide](../../muweb/docs/BRIDGE.md).

The embedded PyAI bundle contains only activity metadata. It references no
archive bytes, so visible HTML, model context, and repeated activity
occurrences do not duplicate the content-addressed payload. See the
[complete author contract](../../muvocab/docs/INTERACTIVE.md).

## Native parameter-driven graphics

MuVocab `@g.interactive(...)` graphics are distinct from packaged MuWeb
applications. PyHTML receives their already validated semantic graphic plus a
closed JSON expression tree for every parameter-dependent SVG attribute. The
worksheet runtime evaluates only the documented numeric expression nodes; it
does not execute generated JavaScript, call `eval`, or translate arbitrary
Python into JavaScript. Slider or dropdown input updates the existing SVG on
the next animation frame. Numeric steps are quantized before evaluation;
`step=None` arrives as HTML `step="any"` and is only clamped to the authored
range. Dropdowns store a validated option index and the expression evaluator
enters only the selected piecewise branch. The heavy native track is replaced
by a thin guide line by default and can be enabled independently of this
behavior. Human-readable values use the authored significant-digit budget;
this formatting never rounds the value used for persistence or geometry.

Current control values are stored under `reactiveGraphics`, keyed by the
author-defined interactive-graphic ID. They use the same immediate IndexedDB
commit and portable `.work` path as other learner state. Only parameter values
are persisted: transformed SVG coordinates are derived state and are rebuilt
from the authored expressions after every load. PyTeX5 renders the authored
control defaults, while the embedded PyAI representation retains the controls,
defaults, and symbolic geometry.

## Native notebook cells

An author can turn the source compartment of a showcase into an optional
native notebook cell while preserving its ordinary static projection:

```text
µshowcase[editable=True, session="lesson:experiment"]{
µexec("value = 6 * 7")
Das Ergebnis ist µexpr(value).
}
```

`session` is a unique stable document-local identity. In every ordinary
browser the textarea and run button remain disabled. Without saved edits, the
original parser-highlighted source and exactly-once author result remain
visible. Restored edits have no result until manually executed in Reader.
No Python interpreter or execution service is
embedded in the HTML.

The optional `muweave-reader lesson.html` command hosts that unchanged file in
Qt WebEngine. Its Qt WebChannel progressively enables the source and run
button. Shift+Enter or the button sends the complete edited source to a
separate persistent Python worker only after an explicit trust decision. A
stable session retains user Python names and configuration across manual runs;
each run nevertheless gets fresh counters, references, document structure,
layout, and asset registration.

The editable textarea stays transparent over the source presentation rather
than replacing it with plain text. Changed source is sent over a separate
bounded reader call to MuWeave's non-evaluating structural analyzer, and the
returned exact segments replace the coloured layer only if the request still
matches the current editor generation. Thus live editing keeps the same syntax
roles as authored showcases without executing source or duplicating the
MuWeave grammar in JavaScript.

The worker returns shell-free adapter-generated HTML and explicit immutable
dependencies. The authored showcase result is the initial output. A successful
manual run replaces that output, and every later run replaces the preceding
runtime output instead of building an output history in the document. PyHTML
uses the already embedded MathJax runtime when required. Edited source is
captured by the same revision and persistence path as other learner state.
Runtime result HTML is session-only and is removed from full-copy clones;
temporary Blob asset URLs are revoked and never enter `.work`. The original
author expansion and embedded AI bundle are never updated by a manual run.

Each saved cell keeps its exact author source in `defaultSource`, its active
editable `source`, and recoverable `previousSources`. Loading `.work`, a browser
mirror, or a saved HTML copy compares the baseline with the current author
source. An unchanged baseline preserves edits. A changed baseline selects the
new author source; differing learner edits remain in the recovery disclosure
**Dokumentvorlage aktualisiert – früheren Zellquelltext anzeigen**. A legacy
record without a baseline is treated conservatively: differing source is
retained there rather than silently reactivated. An unedited old default
does not need a backup. Removed sessions are retained for later reuse.

Opening the disclosure allows copying previous source; Reader additionally
offers **Diesen Quelltext in die Zelle übernehmen**. This changes only the
editor and never executes Python. The next ordinary save retains the baseline
and backups; reconciliation itself also schedules a portable save. Other
answers, drawings, and unrelated sidecar fields are not reset. This is a
notebook-source compatibility rule, not a blanket reset of all learner work
on every document change.

Neither the authored result nor a previous runtime result is presented for
different source. Editing, recovery, or cross-view restoration hides an
unrelated result and marks the cell as unevaluated, including its expansion
tooltip. A completion for source changed while execution was pending is not
displayed. Only a manual run produces a new result. Saved HTML copies retain
the original author source/result and the separate edited-source records;
transient output and recovery controls are reconstructed rather than copied.

Notebook execution has full current-user Python authority. Process separation,
request-size limits, and a timeout make it interruptible, but they are not a
security sandbox. See the [reader trust contract](../../muweave-reader/README.md).

## Saving and portability

The portable learner-owned state is a sibling file named after the document.
For example, `kinematik.html` uses `kinematik.work`. It contains answers,
imported graphics and editable originals, root and item-local vector strokes,
local paper heights, and up to 60 undo and redo states per drawing layer. It
also contains all adjustable worksheet settings: the unified sidebar scale,
document scale, drawing-enabled state, selected drawing layer and active tool,
every tool's colour and width, line style and exact length, eraser mode, ruler
visibility and geometry, and native reactive-graphic control values. Replacing
`kinematik.html` with a longer author build does not replace
`kinematik.work`.

`.muwork` was the former suffix. Browser state stored under that former key is
still migrated to the canonical `.work` key on first use. The current workflow
does not scan for or import a physical `.muwork`; first-time setup addresses
only the exact canonical `.work` name.

The runtime also keeps an automatic mirror in the browser's IndexedDB, keyed
by the local HTML path. This mirror is loaded immediately without file-system
permission, so reopening the same document restores the learner state even
when Chrome refuses to reactivate the `.work` grant. Every completed change,
such as one input event or one finished stroke, increments a revision and
immediately starts an IndexedDB transaction. Where supported, the transaction
requests strict durability. PyHTML counts the browser copy as saved only after
the transaction completes; there is no autosave timer in front of this first
durable copy. When an older browser record is normalized to the current schema,
PyHTML immediately writes that canonical representation back to IndexedDB. The
migration itself does not create a learner revision and does not require a new
drawing action or an active `.work` file grant.

The physical `.work` is updated independently after ten seconds without
another change. This debounce prevents a complete JSON replacement for every
short burst of typing or drawing while preserving the immediately committed
browser copy. Revisions, not clocks, decide which current-format state is newer
when browser mirror and sidecar meet again. `savedAt` remains a tie-breaker and
supports migration of older states. A newer browser state is written to the
sidecar after permission returns; a newer sidecar replaces a clean browser
mirror.

A connected, visible view checks the physical `.work` every two seconds and
checks immediately when its tab or window regains focus. Consequently, a
second browser tab, browser window, or MuWeave Reader window that is not being
edited follows a save from the active view without a manual reload. The check
uses a SHA-256 identity of the exact physical bytes, not only revision numbers
or timestamps. Before every replacement PyHTML rereads and compares that
identity. If both the external file and the current view changed since their
last common state, PyHTML marks a red conflict and stops portable saving rather
than silently choosing one version. Polling is shared by browser and reader;
neither `BroadcastChannel` nor a file-observer API is needed.

When the exact same artifact is hosted by `muweave-reader`, its native bridge
derives `kinematik.work` from the canonical `kinematik.html` path. It loads the
file automatically, creates an absent or empty file, and atomically replaces
it on save. No connection action, picker, or browser file permission is
required. The version-2 native bridge reports an identity for the exact bytes
read, checks that identity again directly before each atomic replacement, and
rejects a stale save if another view wrote first. PyHTML still performs schema
validation, browser-cache reconciliation, and the visible state transition.
Invalid nonempty JSON is reported and retained. The connection control
immediately becomes the green, inactive **Mit kinematik.work verbunden**
status. This is a reader capability, not additional authority available to an
ordinary web page.

The coloured status at the top of the pinned work-state section reports the
exact boundary:

- Red means that the current revision has not yet been confirmed by either
  persistence target, saving failed, or local and external work conflict. A
  conflict blocks sidecar writes instead of overwriting either version.
- Orange means that only the browser mirror or only `.work` has confirmed
  the current revision and reads **Nur im Browser gesichert** for the usual
  browser-first interval.
- Green means that both targets have confirmed it and names the portable file,
  for example **In kinematik.work gesichert.**

The internal revision number is deliberately not shown. The indicator remains
exactly one line high. Text that does not fit travels horizontally inside that
fixed line, so a colour or wording change cannot move the work-state actions
or the scrolling tools below it. The green message instead shortens only a
long filename stem with an ellipsis while retaining `.work` and
**gesichert.** at the right. Reduced-motion browser settings replace movement
in other long messages with an ellipsis. The adjacent diskette-shaped Save button is disabled
while the indicator is green and becomes available as soon as either
persistence target falls behind.

PyHTML asks the browser to retain its storage persistently. A refusal does not
disable IndexedDB, but the status tooltip explains that `.work` remains the
portable safeguard. While `.work` is behind, PyHTML installs a standard
close-warning handler. Browsers do not guarantee that such a handler runs on a
crash, process kill, or operating-system shutdown, so it is a warning rather
than an absolute prohibition. The immediate IndexedDB transaction is the
primary protection against those cases.

Current Chrome and Chromium provide the portable sidecar workflow on Linux:

1. Give the learner only `lesson.html` and open it directly. The red connection
   button reads **Arbeitsstand einrichten**.
2. Use that button and select the directory containing `lesson.html`. PyHTML
   verifies that the directory has an entry with that exact HTML filename. It
   opens `lesson.work` when it exists or creates that exact file when it does
   not. There is no Save As or overwrite dialog.
3. An existing nonempty `lesson.work` is read and validated before any write;
   invalid content is reported and retained unchanged. After successful setup,
   the button changes to **Mit lesson.work verbunden**, turns green, and becomes
   inactive. Its tooltip names both files. Later changes reach IndexedDB
   immediately and this one sidecar after ten seconds without another change.
4. PyHTML discards the transient directory handle after deriving the file
   handle and persists only the exact `lesson.work` handle. Browser permission
   granted for the directory during setup cannot be revoked programmatically
   by the page, so this is a minimization of retained capability rather than a
   claim that the browser grant has disappeared.
5. On later openings the browser mirror appears automatically. If Chrome still
   considers the remembered file permission valid, the file reconnects and
   turns green automatically; otherwise click the same red button once.

The page assigns each HTML path its own picker ID, so Chrome normally reopens
the directory picker at the location remembered for that document. The
runtime never scans the selected directory and touches only the current HTML
name and the exact derived `.work` name.

JavaScript can read the textual parent path from a `file://` URL, but the File
System Access API does not accept an arbitrary path string as `startIn`. It
accepts only a previously granted file or directory handle or one of a few
well-known directories. PyHTML therefore cannot open the sibling directory
without one initial learner choice. Checking for the current HTML filename
guards against an obvious wrong directory, but cannot distinguish two
same-named copies in different directories.

The browser mirror belongs to the browser profile and the exact local path. It
can disappear when browser data is cleared and does not travel with copied
files. The `.work` therefore remains the portable backup to retain and copy
with the HTML, even though it is not required for every reopening in Chrome.

There are no separate Open or `.work` download actions after setup.
The diskette button writes the connected file immediately; if no file is
connected yet, it starts the same setup action. Browsers
without the File System Access API continue to use the immediate IndexedDB
mirror, but the red connection button is disabled because they cannot receive
a persistent write handle for the physical `.work`.

**Vollständige HTML-Kopie** remains a secondary portable snapshot. It embeds
the current state in a new self-contained HTML file together with the authored
document, local source images, and drawing runtime. Neither workflow needs a
server, network resource, `localStorage`, or `sessionStorage`; the automatic
mirror uses the structured IndexedDB store.

By default, a second inert JSON element contains the authored semantic PyAI
bundle. Saving a complete copy preserves it unchanged. The `.work` envelope
keeps learner state separate from authored semantic context; a future tutor
runtime can combine both without mistaking learner work for source material.
An author build with `--no-embed-ai` deliberately omits the semantic element.

The sidecar envelope has identity `muweave-work-state`, version 8, and contains
the `pyhtml-offline-worksheet` state at version 24. The envelope records both
its content revision and the last revision confirmed in the portable sidecar.
Version 5 separated `settings.sidebar`, `settings.document`, and
`settings.drawing` from learner content in `responses`, `slots`, and
`annotations`. Version 6 defines the saved sidebar width at 100% sidebar scale,
so its occupied width follows the scale without losing the splitter setting.
Version 7 adds the monotonic revision. Version 8 replaces the independent
sidebar width and control scale with one 0.1%-quantized scale, migrating their
previous product so the displayed width does not jump. Version 9 adds
item-qualified local drawing state and preserves orphaned layer records across
regenerated author documents. Version 10 adds a separately persisted zoom to
each local layer and defaults older local-layer records to 100%. Version 11
persists local paper width and defaults older records to their authored
viewport width. Version 12 stores the learner-selected local-paper background
and defaults older records to the author selection. Version 13 stores drawing
activation independently from the selected layer and tool; version 12 and
older infer the former mode from their `interact` pseudo-tool. Version 14 adds
instance-keyed interactive-module records and retained quarantine entries;
work-envelope version 4 carries that state through the portable sidecar.
Version 15 keeps the same shape but introduces transactional adjacent module
state migrations before initialization. A version-14 worksheet is therefore
normalized and rewritten once even when its serialized fields need no change.
Version 16 changes the logical document width from the historical 832 CSS
pixels to the standards-derived A4 width without converting pre-production
learner coordinates. Version 17 adds a `notebooks` branch keyed by stable
editable-showcase session names. Those original records contained only edited source.
Dynamic result HTML and temporary asset URLs remain in memory and are stripped
from a complete saved HTML clone as well as from `.work`. Work-envelope
version 5 carries that source state. Work-envelope version 6 retains the same
JSON members and introduces the multi-view continuity rule: a writer must
still be based on the exact sidecar content last observed. The associated
content token is runtime and browser-cache metadata, not another portable
envelope member.
Version 18 distinguishes an explicit learner paper-height override from the
automatically resolved authored/content height. Only the former remains an
override across rebuilt HTML; a legacy derived height resets to the new
document minimum while strokes and history remain intact. An omitted authored
viewport follows the current immutable content height, whereas an explicit
viewport remains fixed and may scroll.
Version 19 adds the `reactiveGraphics` branch. Each entry stores only the
current values of the controls belonging to one stable interactive-graphic ID;
SVG coordinates and other rendered attributes are deliberately recomputed.
Work-envelope version 7 carries this branch through the portable sidecar.
Version 20 adds author-source baselines and recoverable previous notebook
source. Work-envelope version 8 carries that reconciliation contract; older
source-only records are readable but cannot prove compatibility with rebuilt
author source. Baseline reconciliation advances the content revision and the
sidecar remains behind until the normal atomic save succeeds.
Inside that worksheet, interactive-module state format 2 adds each manifest
activity to its compatibility record. Format 1 remains readable and acquires
the occurrence's current activity during normalization. Compact/full
presentation is intentionally not stored because it is only a view choice.
Unknown top-level envelope members are preserved so future tutor or chat state
can share the file. Envelope versions 1 through 7 and embedded worksheet
versions 1 through 19 remain readable and are upgraded in memory; formats
predating drawing history begin with empty undo and redo stacks.
Saved-state integers are frontend protocol versions, not package versions.

Root stroke coordinates are relative to the fixed document width. Each local
layer uses its own fixed width. Vertical coordinates use the same respective
width as their unit, rather than a fraction of changing paper height. Appending
material at the end or enlarging local paper therefore does not renormalize
existing strokes.
Centimetre-based line lengths derive a local surface's physical width from its
ratio to the 21 cm document surface, so they do not inherit the root canvas's
scale. Editing content above a root stroke can still move the authored text
beneath it; stable element anchors remain a separate future feature.

## Authored response fields

The root annotation canvas remains usable over every rendered document.
MuVocab additionally provides two document-global in-flow response fields and
the item-owned local canvas described above:

```text
µresponse.text("reason", lines=4, label="Begründung")

µresponse.graphic(
    "velocity-diagram",
    height=7,
    width=12,
    label="Geschwindigkeitsdiagramm",
)
```

Text and graphic names are stable document-global state keys. A local canvas
uses its qualified item/part/name key instead. Text responses are non-resizable
fixed-height fields; long answers scroll inside their box rather than moving
later document content and canvas strokes.

A graphic response is a fixed insertion area measured in logical centimetres.
Omit `width` to use the available body width. Its controls accept an SVG, PNG,
JPEG, or WebP preview and an optional original file in any format. The preview
is contained inside the declared area and never changes document geometry. A
`.work` file and a saved HTML copy both retain response text, preview
bytes, original-file bytes, and filenames in their versioned state. The
generated controls are frontend UI and are reconstructed when either state is
loaded; they are not duplicated in the serialized document markup.

Printing hides the insertion controls and empty-slot instruction. An imported
preview remains visible. PyTeX5 renders every response kind as a fixed
printable area. The current MyST target rejects them explicitly.

### Item-owned selection answers

MuVocab's `block.single_choice` and `block.true_false` render one radio group
per stable item-owned input, for example `77/choice/answer`. The radios look
like the square printed checkboxes, but allow only one selected answer.
**Auswahl löschen** restores the unanswered state. This frontend control is
hidden when printing and rebuilt, rather than duplicated, in saved HTML copies.

Worksheet format 24 adds `choices`, mapping an input identity to a stable
option key or `null`. It never stores a shuffled position, answer text or
correctness. Legacy states migrate with no selections. Reordered options keep
the same selected key; a removed option is not silently replaced by another.
Unmatched records remain retained for recovery. Selection changes use the same
browser mirror, sidecar synchronization and mutation tracking as other inputs.
Applying a refreshed external work state updates the visible radio groups too.

An enabled author model solution keeps its authored checkmark and is excluded
from learner selection editing, clearing and capture. The source build never
loads `.work`; its embedded AI describes the same shuffled questions and input
opportunities, not actual learner answers.
