# muweave target syntax specification

Audience: MuWeave document authors and vocabulary authors

This document describes the implemented MuWeave source syntax. Normative
package conditions live in [`REQUIREMENTS.md`](../REQUIREMENTS.md), and
unfinished implementation work lives in [`TODO.md`](../TODO.md). Python 3.13
or newer is the syntax authority; MuWeave does not define a substitute grammar
for Python expressions.

## Source model

Input is Unicode text containing ordinary target text and optional muweave commands.
A command marker is the single character `µ` (U+00B5). There is no whitespace
between an active marker and its expression or registered text-command name.

At MuWeave's format-neutral layer, `µ` is the only source character with a
global structural role. Every other character, including `&`, `$`, `%`, `#`,
backticks, and backslashes not used to escape `µ`, is ordinary target text.
MuWeave neither assigns those characters portable meaning nor escapes them for
a target. A vocabulary may define additional syntax only inside the explicit
scope of one of its own values or operations; such local syntax does not
become MuWeave syntax.

All source offsets are Unicode code-point offsets into the original text.
Stored spans are end-exclusive. User-facing lines and columns are one based.

## Marker escaping

Let `n` be the number of consecutive backslashes immediately before a `µ`:

* even `n` makes the marker active;
* odd `n` makes the marker literal;
* for a literal marker, exactly the last of those backslashes is consumed;
* every other character remains unchanged.

Therefore the following source-level transformations apply before any command
semantics are considered:

```text
source       result before command evaluation
\µx          µx
\\µx         \\ + active command x
\\\µx        \\µx
\\\\µx       \\\\ + active command x
```

An escaped marker never begins a command. Scanning resumes normally, so later
markers in the same text can still be active.

## Literal active markers

An active `µ` remains literal when the immediately following source cannot
begin either an allowed compact Python primary or a registered text command.
This includes an end-of-file marker and these forms:

```text
µ.
µ,
µ!
µ;
µ:
µ(
```

The unnamed `µ(...)` form is deliberately absent. Use `µexpr(...)` for a
parenthesized general expression.

## Compact Python form

The compact form consists of an allowed Python atom followed by zero or more
ordinary Python primary trailers:

```text
atom (attribute | call | subscription)*
```

Target atom starts are:

* identifiers, including `True`, `False`, and `None`;
* Python numeric literals;
* Python string, bytes, and formatted-string literals, including Python's
  implicit concatenation of adjacent literals;
* list, set, and dictionary displays and their comprehensions;
* the ellipsis literal.

A leading parenthesized atom or generator expression is the one deliberate
exception; `µ(...)` remains literal. Use `µexpr(...)` instead. Unary operators,
binary operators, comparisons, lambdas, conditional expressions, and named
expressions are likewise written inside `expr(...)` when they occur at the
root.

Trailers have their normal Python meaning and can be chained without a muweave
limit:

```text
µperson.name
µmake_items()[i][j]
µmake_items()[1:5]
µfactory()().value[2:7].strip()
```

At the outer compact-primary level, every `.attribute`, `(...)`, and `[...]`
trailer must begin at the code point immediately following the preceding atom
or trailer. This embedding boundary prevents prose such as `µvalue. Next` or
`µfactory (note)` from being consumed as Python; those forms extract only
`value` and `factory`. Whitespace, comments, and newlines remain fully governed
by Python inside an already opened call, subscription, container, string, or
f-string. Implicitly concatenated string literals follow Python's own `strings`
atom rule and may contain intervening horizontal whitespace.

Call arguments, subscription expressions, and slices may contain full Python
expressions, including operators, lambdas, comprehensions, conditionals, and
nested containers. Python tokenization governs strings, comments, escapes,
and delimiter nesting. A `µ` inside an accepted Python string, f-string, or
delimited Python comment is therefore content owned by that Python expression,
not a new outer command marker.

The extractor selects the longest syntactically valid prefix whose root has
the compact-primary shape. It does not execute candidates. For example:

```text
The title is µmake_items(topic="vectors")[5].title.
```

extracts only:

```python
make_items(topic="vectors")[5].title
```

The final period stays in the document. Similarly, `µx is positive` extracts
only `x`; comparison operators are not compact-root continuations.

Python lexical rules can create boundaries that prose authors should notice.
For example, the period in `µ1.` belongs to the valid floating-point literal
`1.`. Authors can avoid such ambiguity by using `µexpr(1).`.

Once a trailer has clearly started, an incomplete or invalid trailer is an
error rather than permission to silently use a shorter prefix. Thus
`µmake_items(` and `µitems[` raise `MuWeaveParseError`. A sentence-ending period
after an otherwise complete primary remains text rather than an incomplete
attribute trailer.

## General expressions with `expr`

Every context provides the ordinary identity callable:

```python
def expr(value):
    return value
```

It gives a clear boundary for root-level general expressions:

```text
µexpr(2 * a + b)
µexpr(x if condition else y)
µexpr(a is b)
µexpr(sum(x**2 for x in values))
```

`expr` is not a parser mode. Python evaluates its argument normally, and any
following trailers remain ordinary compact trailers:

```text
µexpr(create_a() if condition else create_b())[2].name
```

## Dynamic `eval` and `exec`

`eval` and `exec` are context-bound callables distinct from `expr`:

```text
µeval("2 * a + b")
µexec("answer = 6 * 7")
```

They evaluate the contents of a Python string in the same persistent namespace
used by normal commands. `eval` returns its Python value. `exec` normally
returns `None`, which renders as empty text, while its namespace changes remain
visible to later commands.

At context construction, muweave installs and reserves the names `expr`, `eval`,
and `exec`, replacing any initial namespace entries with those names. The
namespace remains ordinary mutable Python state afterward.

The wrapper signatures accept exactly one positional source argument:

```python
context.eval(source, /)
context.exec(source, /)
```

Besides strings, the wrappers preserve the bytes and compiled-code source forms
accepted by Python's built-ins. Optional globals, locals, and `exec` closure
arguments are deliberately unsupported because muweave always uses its own
persistent dictionary. Explicitly imported `builtins.eval` and `builtins.exec`
remain available to trusted code that intentionally needs different
dictionaries.

A syntax or runtime error inside dynamic source occurs during evaluation of the
outer command. It therefore raises `MuWeaveEvaluationError` with the complete
outer command span and retains the nested Python exception as its cause.

## Registered brace text form

Registration may opt a named command into a braced text body:

```text
µemph{Hello}
```

The target may be a Python name or directly adjacent attribute-only chain such
as `tikz.axis`. No whitespace is allowed between the target and opening brace.
The context registry must contain that exact qualified name with either a
singular `brace_argument` or plural `brace_arguments` declaration;
registration is not inferred from ordinary callability.

The singular form always calls the handler with one exact string. The plural
form treats an exactly empty body as zero arguments and otherwise splits it at
top-level `,,` into positional strings. Splitting belongs to the original
source and occurs before each argument is independently processed, so nested
groups, nested command source, and expansion output cannot introduce outer
separators. Use canonical Python-call syntax when one plural-form argument must
contain a literal top-level `,,`.

`123`, `True`, whitespace, and every ordinary comma remain string content. The
registered `brace_body_policy` determines whether active commands in each
selected string are expanded before the outer command, retained for structured
evaluation after it, or kept opaque. Its values are `"expanded"`, the default,
`"deferred"`, and `"raw"`. No policy implicitly trims, dedents, normalizes,
coerces, or target-format-escapes an argument.

Nested unescaped braces balance the body. A brace preceded by an odd run of
backslashes is treated as a literal target-text brace and does not change nesting;
the brace backslash itself is preserved. This is a brace-balancing rule only,
not a general TeX parser.

Braces owned by the syntactically extracted Python source of a nested active
muweave command, including braces inside Python strings and containers, do not
participate in the surrounding raw-body balance.

Use of `{...}` after a command that did not opt in is a command error with a
canonical `µname(...)` suggestion. muweave does not define repeated brace
arguments or mixed call/brace syntax globally.

After the selected body policy is applied, the registered callable is invoked
exactly once with the selected positional string arguments. Directly adjacent
Python call, attribute, and subscription trailers after the closing brace
operate on that real result before its final rendering.

A handler with `brace_body_policy="deferred"` may return the immediate control
`DeferredBodySelection(indices)`. Only the named already parsed body ranges
are then evaluated and inserted transparently; an empty tuple omits every body.
The selection neither changes the source grammar nor makes omitted source raw:
all deferred bodies remain part of strict parsing and non-evaluating analysis.
The value is invalid outside that direct deferred-command result boundary.

## Discarded source with `comment`

Every context reserves `comment` as a raw brace command and as a canonical
Python callable:

```text
µcomment{
This source remains in the physical file but produces no output.
Nested source such as µunknown() is not parsed or evaluated.
}
```

The raw brace form treats its complete body as opaque source and returns the
empty string. It is therefore suitable for temporarily excluding prose,
commands, or incomplete MuWeave expressions from every output target. Braces
must still balance so the end of the comment can be found. A `µcomment(...)`
Python call also returns the empty string, but its ordinary Python argument is
evaluated before the call; use the brace form when content must be inert.

This differs from `lit`: a comment discards its body, whereas `lit` preserves
and eventually publishes its body unchanged.

## Literal quotation with `lit`

Every context reserves `lit` as a raw brace command and as a canonical Python
callable:

```text
µlit{µemph{Hello}}
µlit('µemph("Hello")')
```

Both forms protect the supplied text through intermediate `expand_fragment`
calls. Internally the result is an opaque, context-owned capsule embedded in an
ordinary `str`, so normal concatenation, joining, formatting, and f-string
interpolation preserve the protection. The intermediate encoding is private
to that context and is not a persistence or interchange format.

`expand_string` first expands every unprotected command occurrence, then runs
deferred computations and resolves references while literal capsules remain
opaque. It replaces literal capsules with their exact payloads only afterward.
Released payloads are not scanned. An outer `lit` consequently preserves nested
`lit` source literally. This is distinct from `\µ`, which escapes a marker for
only the scan in which that backslash occurs; if surrounding generated text is
scanned later, the revealed marker can become active.

`lit` protects MuWeave expansion only. It performs no target-specific
escaping or verbatim typesetting. Arbitrary destructive string operations can
also destroy a capsule; the supported interoperability contract is transparent
string composition, not preservation through deliberate character rewriting.

## Explicit deferred computation with `defer`

Every context reserves `defer` as a normal canonical Python callable:

```text
µdefer(lambda: objects["satz-a"].title)
```

Its one positional argument must be callable. `defer` immediately returns a
context-owned capsule; `expand_string` invokes the callable exactly as
`thunk()` after ordinary transitive expansion. There is no registered brace or
modifier form, no signature guessing, and no proxy for later trailers. Put the
complete postponed Python operation inside the callable:

```text
µdefer(lambda: objects["satz-a"].title.upper())
```

The final object uses the normal rendering protocol. Its rendered string is not
rescanned for active `µ`, but context capsules returned through it continue to
the appropriate later phase. Nested defer capsules resolve depth-first;
references validate afterward; `lit` payloads remain last. The complete timing,
exactly-once, limit, cycle, and error contract is in
[DEFERRED.md](DEFERRED.md).

## Semantic reference callables

Every context also reserves three normal canonical Python callables:

```text
µref("satz-a")
µtarget("satz-a")
µtarget("satz-a", semantic_object)
µexternal_ref("other-document")
```

`ref(key)` produces a deferred reference capsule. `target(key, value=None)`
registers that key exactly once and returns a caller-rendered target marker;
the optional value is metadata and is not automatically rendered at that
position. `external_ref(key)` explicitly creates a deferred semantic reference
without requiring a local target.

These are ordinary Python calls, not parser modes. Keys are nonempty strings
without edge whitespace. A local target may occur before or after a reference.
`expand_fragment` retains the capsule; `expand_string` validates every visible
local reference after ordinary expansion and explicit deferred computation,
resolves references without rescanning their rendered text, and releases `lit`
afterward. The exact semantic and diagnostic contract is in
[REFERENCES.md](REFERENCES.md).

## Registered modifier text form

A brace command may separately opt into:

```text
µemph[red]{Hello}
```

The exact registered qualified target must have a singular or plural brace
declaration plus `bracket_argument`. With the default mapping, the selected
body string or strings are positional arguments and the exact raw bracket
string is passed under the keyword named by `bracket_argument`. For example, a
`bracket_argument` of `"color"` maps the source above to the handler call
`emph("Hello", color="red")`.

Bracket content has no global meaning. It is not Python source and muweave does
not evaluate, trim, normalize, target-format-escape, or recursively process it. Nested
brackets balance. An odd run of backslashes immediately before `[` or `]`
makes that bracket literal for balancing, while an even run leaves it
structural; the backslashes remain in the raw modifier string. Empty and
multiline modifier strings are valid.

A registered command-specific adapter may replace the default mapping. It is
called exactly once as `adapter(raw_modifier, selected_body)` and receives a
string for singular syntax or a tuple of strings for plural syntax. It must
return `CommandArguments(args=tuple(...), kwargs={...})`. Those are the
complete arguments for the one handler call; muweave does not append implicit
values. Adapter and handler failures remain evaluation failures associated
with the outer command.

Only a balanced `[...]` directly followed by `{` has the modifier source shape.
That shape is recognized structurally without checking whether the qualified
name or modifier form exists. Otherwise brackets retain normal Python
subscription meaning:

```text
µvalue[key] {literal body}
µvalue[key][second]{literal body}
```

The first example contains a Python subscription followed by whitespace and a
literal group. The second contains two Python subscriptions followed by a
literal group. Once a direct modifier shape has begun, an unclosed brace body
is a text-command parse error; without a balanced bracket and direct opening
brace, an incomplete bracket remains an incomplete Python subscription.

`analyze_string()`, `parse_string()`, and `parse_analysis()` all accept the
same balanced surface structure. This does not authorize the name or infer an
executable body policy. Expansion raises `MuWeaveEvaluationError` when it
reaches a form absent from the schema, just as canonical `µname(...)` fails at
evaluation when `name` is absent from the namespace.

Trailers after the completed brace command always operate on its real Python
result before rendering:

```text
µemph{Hello}[1:4]
µemph[red]{Hello}[1:4]
µemph{Hello}.upper()
```

## Evaluation and rendering

Commands execute in document order in one persistent context. The final
accepted expression is evaluated exactly once. Only after all calls,
attributes, and subscriptions finish is the result rendered.

An ordinary string rendered from an immediate command is then treated as
generated source: active, unprotected commands in it are expanded transitively,
depth-first and in left-to-right order. The occurrence that produced the string
is never reevaluated. Canonical Python string arguments are not pre-expanded;
in `µfunction("µother()")`, Python passes the exact literal to `function`, and
only the function's returned text enters generated-source expansion. Expansion
is bounded by documented command-count, generated-depth, and generated-size
limits so self-reproducing output fails with `MuWeaveExpansionError`. Results
rendered during the later explicit deferred phase instead follow its documented
no-rescan boundary.

Rendering priority is:

1. `None` to empty text;
2. `str` unchanged;
3. most-specific context renderer;
4. `value.__muweave__(context)`;
5. fail closed for an unhandled `SemanticValue`;
6. `str(value)`.

Registered renderers and object protocols must return `str`. Containers receive
no implicit element-wise treatment. No output receives automatic target-format
escaping.

## Trusted-code boundary

muweave documents execute Python code with normal builtins in the configured
context. Access to files, imports, subprocesses, and other Python capabilities
is therefore possible.

```text
muweave documents execute Python code.
Only compile trusted muweave documents.
```

A restricted mode, if ever added, is a separate future feature and must not
silently weaken the normal Python semantics specified here.
