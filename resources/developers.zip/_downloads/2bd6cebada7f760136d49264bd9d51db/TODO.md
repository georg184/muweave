# MuWeave Suite TODO

## Portable mathematics and an additional Typst renderer

The agreed direction retains MuWeave/Python authoring and the existing
backends. See the staged [Typst and portable mathematics plan](docs/PLAN-TYPST-UND-PORTABLE-MATHEMATIK.md),
which follows the [Gemini discussion review](docs/REVIEW-TYPST-MATHML-LERNCOACH.md).

- [x] Inventory active TeX dependencies throughout `muweave_documents` and
  `muweave_library`, distinguishing mathematical content from literal/native
  examples. Extend existing semantic math values for portable composition.
- [x] Add an optional Typst-to-MathML formula renderer to existing PyHTML,
  selected by CLI and forwarded by MuCompose. Keep MathJax as the initial
  default; verify a small end-to-end corpus before broad source migration.
- [x] Extend portable notation and renderer propagation to equation previews,
  static/native-reactive graphic labels, measured trim/height matching and
  Reader notebook protocol 2. Add editable comparisons and an explicitly
  provisional native angle-label profile without relabeling old samples.
- [x] Migrate and verify the first real item group (49–55 and 73), retaining
  item identities, prose and structure; rebuild the existing Vektorgeometrie
  and showcase artifacts with the default backends.
- [x] Migrate the complete `.muweave` corpus incrementally, preserving item
  identities, content and AI semantics. See the
  [corpus audit](docs/AUDIT-PORTABLE-MATHEMATIK.md) for precise native exceptions.
- [ ] Complete graphic-label, calibration,
  module and notebook support without hidden MathJax dependencies in the new
  mode; test real offline browsers and existing LuaLaTeX output throughout.
- [x] Transfer native optical fraction/matrix settings with real Chrome,
  Firefox and Reader measurement tests, editable comparison cells, unchanged
  mathematical structure and a fixed fraction axis.
- [x] Expose immutable real math defaults and editable fraction/parenthesis
  presets in the main showcase. Support native fixed/minimum fence sizes and
  configurable inner clearance; remove only marked matrices' outer cell
  padding. Full native showcases explicitly select link-only Motion examples.
- [ ] Complete remaining notation and runtime-module coverage, and gather direct native
  angle-label evidence before treating that profile as calibrated.
- [ ] Add the full `pytypst` package with independent PDF/HTML projections.
  Then extend the normal MuCompose build to `name.pdf`, `name.ai/`,
  `name.html`, `name_typst.pdf`, and `name_typst.html`, with isolated target
  evaluation, collision-safe paths and documented dependency/error handling.

The limited formula pilot is available with `--html-math-renderer` in both
PyHTML and MuCompose. The source migration is complete; extra Typst outputs
and the remaining native notation/calibration/runtime coverage are still planned.
The renderer's supported subset and explicit failures are documented
in the [HTML mathematics guide](../pyhtml/docs/MATHEMATICS.md#experimental-native-mathml).

## AI context: author document first, learning coach later

The immediate milestone is the complete source-derived export described in
[PyAI's TODO](../pyai/TODO.md). It includes declared future input opportunities
but does not ingest `.work` or execute a quiz. The two consuming use cases share
one author-context contract, not two independently generated author documents:
authoring/style assistance uses it alone; a learning coach adds separately
attributed learner context and tutor policy. See MS-AI-01 and MS-AI-02.

Reusable input-bearing content can be an item, whether a task, quiz, scaffold,
or other authored unit. Use that existing item identity as the content-owner
anchor; qualify multiple input places with the part and local input identity.
This avoids an independent AI ID catalogue without assuming every input API
already derives its runtime key automatically from an item. Existing explicit
field/instance names remain valid; no blanket inline-content migration is part
of the first step.

- [x] Complete the static PyAI milestone and verify the exact same authored
  input identities in visible HTML and its embedded semantic projection.
  Preserve default AI inclusion in HTML and the existing explicit opt-out.
- [x] Audit item-owned input context for the other input kinds after canvases,
  reusing structured-item identity and each kind's existing field/instance key.
  Preserve one-to-many item/input relationships instead of treating an item ID
  alone as the identity of every answer inside it.
  The isolated all-input corpus covers keyed parts, nested items, list entries,
  native/module activities, text/graphic responses and editable showcases.
  PyAI's optional text normalization is separate from this content milestone.
- [ ] Define the versioned context-join protocol before implementing the
  runtime adapter. Identify both the logical document and exact publication,
  then resolve contributions against existing item/part/appearance, response,
  interactive-instance, reactive-graphic, or notebook identities. Keep
  unresolved/stale references explicit; never attach work to a different task
  merely because its visible number or position now matches.
- [ ] Build a separate runtime projection of relevant `.work` content and,
  where necessary, current in-memory quiz/notebook results. Keep the static
  author document unchanged. Separate authored givens and model solutions,
  learner attempts, generated quiz questions, and coach feedback by origin.
  An imported learner answer is content to consider, not a replacement for
  author instructions or trusted tutor policy.
- [ ] Distinguish an input declaration with no loaded learner state from a
  known empty answer, an attempted answer, an unknown state, and an unavailable
  or incompatible record. Neither absence nor saving a record proves success
  or completion.
- [ ] Include available occurrence times and ordering in the learner context.
  Preserve per-attempt/per-object or event provenance where captured; a file's
  save time is not the creation time of every answer or stroke. Record missing
  historical times as unknown rather than inventing them. Resolve event
  granularity and retention in [the open questions](OPEN_QUESTIONS.md).
- [ ] Provide model-facing visual snapshots of handwriting and drawings,
  initially targeting PNG views rather than raw SVG/XML in the text prompt.
  Keep original vector strokes and history in learner storage as authoritative
  editable data; snapshots are derived views, not replacements. Label the
  snapshot's input/document identity, covered region, included authored layers,
  represented state revision, and capture time separately from creation times.
- [ ] Render enough context for a drawing to be understood: include or link
  its authored axes/scaffold and identify which marks are the learner's.
  Distinguish authored coordinate meaning from the technical transform needed
  to align ink. Root-overlay marks require an explicit region-to-content
  association; a document-global pixel location alone is not a stable target.
- [ ] Make time-filtered views or progress comparisons possible when recorded
  history supports them. Do not promise to reconstruct a weeks-old picture from
  one current PNG or from undo history that no longer retains those events.
- [ ] Add the learner-facing prompt window/model integration as a later host
  feature, using the HTML's matching AI bundle and the resolved runtime context.
  Keep model-provider transport, user-controlled disclosure, and tutor policy
  separate from static PyAI serialization. Reference shared assets instead of
  duplicating the author document into `.work` or every attempt record.
- [ ] Test document extension, moved/repeated items, removed inputs, changed
  quiz schemas, unresolved work, multi-session ink, and notebook reruns without
  mutating author semantics. Test that author-only use never receives learner
  data and that coach input distinguishes authors, learners, and coach messages.

These entries describe planned work, not an implemented `.work`-to-model API.
They do not select a model provider or authorize an upload of learner data.

## Exam printing and local scan processing

The [choice-question and individualized-print plan](docs/PLAN-MULTIPLE-CHOICE-PRUEFUNGEN.md)
adds item-owned three-option and true/false questions, retained permutations,
safe learner-state/AI projections, and `--exam-copies` PDF stacks. Construction
and scoring are documented in MuVocab; orchestration belongs to PyTeX5 and
MuCompose delegates to it.

- [x] Implement both choice types and ID-only groups, including stable answer
  keys, configurable checkbox geometry, aggregate scoring and model solutions.
- [x] Preserve native HTML selections by stable keys in `.work`; exclude model
  selections from learner state and hidden solutions from static learner AI.
- [x] Compile individualized PDF stacks with A/B cycling, progress, replay
  seeds, bounded duplicate-permutation retries and durable combined manifests.
- [ ] Extend the postponed scan consumer to validate a combined-stack PDF hash
  and resolve each retained publication/page range before cropping choices.
  Use `option_key`, not checkbox position or the shuffled visible question
  number; classify uncertain or multiple marks for review. Do not infer an
  answer key from the public print manifest. This is not implemented by the
  print exporter and does not resume OCR/provider integration.

The agreed [exam-scan plan](docs/PLAN-PRUEFUNGSSCANS.md) separates printable
answer regions, local identity/crop processing, and later model correction.
The print prototype, fixed-field geometry export and a first local importer
exist. The user chose on 2026-09-08 to adopt the existing print design for the
imminent actual exam before copier acceptance. Further processing is postponed;
the [scan-package resume checklist](../muweave-scan/TODO.md#resume-after-the-imminent-exam)
records the exact restart point and updated-environment issue.
Copier acceptance remains open. The Suite coordinates the work, not a
new umbrella CLI; the optional `muweave-scan` component owns scan processing.

- [x] Build a separate print prototype: clearly framed answer areas, no
  solution title/QED for exam occurrences, a bounded first-page name/number
  field and explicit START/page QR roles. The isolated exam source is
  `muweave_documents/Pruefungsscan_Prototyp/Druckprobe.muweave`; A/B output
  uses local named test items, not newly allocated canonical item numbers.
  Ordinary item rendering and AI input identities are covered by regressions.
- [x] Separate `Zusatzblatt.muweave` from the exam: generic reusable front/back
  sheets, two answer regions per side, separate task/subtask fields, optional
  front-page name field and neutral registration marks only. No course, date,
  exam/group binding, header/footer, page number or QR code.
- [x] Adopt the current print design in the actual four-page exam and its
  reusable template at the user's explicit request, without claiming copier
  acceptance. Keep A/B builds, field geometry sidecars and a separate generic
  supplement; see `muweave_documents/Pruefungsvorlagen/README.md` in the workspace.
- [ ] Accept the print design with real copier scans. Fix final marker family, dimensions and line weights
  from those results; provisional squares/QR codes are not a scan protocol.
  Retain three/four supplement divisions as later variants of the same design.
- [x] Export a versioned scan manifest from final PDF layout, binding exact
  page/region geometry to the printed exam, group and publication. Reuse
  item/part/input identities qualified by occurrence and answer segment;
  resolve visible task numbers only within that exam/group. Keep technical
  geometry outside the model-readable static author document.
  Give generic supplementary templates a separate versioned geometry manifest
  without exam identity; bind handwritten task/subtask fields only on import.
  PyTeX5 now exports opt-in fixed boxes through native FitR destinations;
  all prototype PDFs get `.scan.json` sidecars. Arbitrary-count reference
  marks, exact PDF hashes, audience validation and aliased owners are covered.
  See [format and explicit limits](../pytex5/docs/SCAN_MANIFEST.md).
- [ ] Extend print export beyond the tested fixed-box boundary where required:
  split breakable writing flows into real physical segments and instrument
  each placement of reused native boxes separately. Existing input uniqueness
  remains unchanged; duplicate destination diagnostics must never be ignored.
- [x] Implement initial local page recognition, rectification and PNG extraction
  with manual identity/task matching first. Consume guaranteed contiguous
  submission blocks: START, the expected regular pages, then generic supplement
  pages until the next START. A name/ID on the first exam page suffices.
  A missing QR alone must never classify a page as a supplement; require a
  known layout and confirmed block boundaries. Preserve duplex provenance.
  Accept multi-page copier PDFs, preserve originals and page order, rasterize
  pagewise at a configurable initial 300 dpi and preserve colour/grayscale
  when producing lossless PNG crops. No blanket JPEG recompression/binarisation.
  Use an arbitrary number of well-distributed marks, not a four-corner limit.
  Preserve original scans and crop provenance, including authored scaffolds;
  distinguish missing, uncertain and not-yet-reviewed responses. Template page
  codes do not identify learners: independently shuffled anonymous backs must
  remain unresolved, not be guessed from scan order.
  The [local importer](../muweave-scan/README.md) now provides a CLI, private
  offline review report and hash-bound manual decisions for reruns. Generic
  supplement proposals always require explicit confirmation for now. No OCR,
  automatic grading, anonymized export or provider access is implemented.
- [x] Add reproducible image-quality stress tests, independent field-corner
  checks and faint-ink witnesses. The scan package's
  [quality test model](../muweave-scan/docs/SYNTHETIC_SCAN_TESTS.md) distinguishes
  required recognition, required review and exploratory degradation. These
  experimental profiles do not replace the real copier acceptance above.
- [ ] Add optional local handwriting recognition and reviewable batch
  recovery beyond the initial complete rerun: ambiguous numbers, duplicate or
  missing scans, identity conflicts, confirmed-empty supplementary fields and
  resumable confirmed assignments.
  Validate real copier batches of roughly 80 pages plus supplementary sheets;
  synthetic image-only PDF tests do not complete copier acceptance.
- [ ] Join verified scan contributions with the shared learner-context
  protocol and the matching task, occurrence-specific rubric and correction
  policy. Keep identity mappings local and exclude name fields/full pages
  from default correction payloads; inspect for identifiers inside answers
  before authorized disclosure. Keep provider integration and uploads separate.

Marker/identifier design is tracked in the
[open questions](OPEN_QUESTIONS.md#exam-scanning). Detailed stage acceptance
criteria are in the plan; completing it does not authorize learner-data uploads.
