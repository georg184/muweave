# AI bundle format
Audience: users, AI agents, and developers

`pyai INPUT` creates `INPUT.ai/` (replacing the final source suffix) with four
entry files and optional assets:

```text
chapter.ai/
├── manifest.json
├── document.md
├── document.json
├── provenance.json
└── assets/
```

Read `manifest.json` first. Its `entrypoints.reading` selects the concise
Markdown view and `entrypoints.structure` selects the canonical semantic tree.
`entrypoints.provenance` selects the separate diagnostic source map for tools;
do not include it in model input by default. The integer `format_version`
changes when an older consumer must interpret the
stored meaning differently.

Bundle manifest version 37 and canonical document schema version 34 retain
concrete anchors for repeated logical reference names. A target's `label` and
a reference's `target` identify the selected occurrence. Where it differs from
the authored logical name, `reference_name` retains that name explicitly in JSON
and the Markdown reading view, including equation rows. Number and link share
this binding. Variant controls are resolved before projection; only selected
content appears. Rebuild older bundles and their containing HTML documents.
Embedding transport 2 and provenance 1 are unchanged.

Bundle manifest version 36 and canonical document schema version 33 add
native `typst` math source and occurrence-local `typst_symbols` spelling pairs.
They are derived from the same retained portable values as the TeX source;
no source is evaluated again and no formula compiler is needed for export.
Both JSON and Markdown retain the additional notation. Embedding transport 2
and provenance 1 remain unchanged. Rebuild older bundles and HTML worksheets
to supply these spellings to a learning coach.

Bundle manifest version 35 and canonical document schema version 32 add
optional `coach_instructions`: an ordered array of author-authored didactic
strings on the exact semantic node they describe. Nested scopes specialize
their ancestors; flattened annotations retain outer-to-inner order. These
instructions are published metadata, separate from subject matter and learner
messages, and remain explicit in JSON and Markdown, including mathematical
annotations. Build-only `AiNode.occurrences` connect matching HTML and AI
projections but never enter either exported view. Embedding transport 2 and
provenance 1 remain unchanged. See the
[learning-coach guide](../../pyhtml/docs/LEARNING_COACH.md) for runtime selection.

Bundle manifest version 34 and canonical document schema version 31 add
symbolic slider bounds and conditional mathematical labels. Slider `minimum`
and `maximum` strings may be expressions over earlier declared controls;
`label` may be an object containing `when`, `when_true` and `when_false`.
Conditional computed outputs retain `label_condition` and ordered
`output_label_true` / `output_label_false` children with the complete
mathematical text and nested explanations of both alternatives. Their
significant-digit dependencies are retained for displayed comparisons.
JSON and Markdown preserve these rules, never just the initially selected
label. Embedding transport 2 and provenance 1 remain unchanged.

Bundle manifest version 33 and canonical document schema version 30 add
`graphic_function_area`: original `expression`, locally bound `variable`,
symbolic `interval`, numeric `baseline`, ordered `breakpoints`,
`colors.positive`, `colors.negative` and `fill_opacity`. Positive/negative refer
to values above/below the baseline; this describes a sampled fill, not a
numerical integral. `graphic_function_plot` additionally retains explicit
nonempty `breakpoints` so discontinuities are not confused with connected
curves. The reading view retains the complete semantic subtree; sampling
density and generated polygons are presentation. Embedding transport 2 and
provenance 1 remain unchanged.

Bundle manifest version 32 and canonical document schema version 29 add
`person_mention` and `person_profile`. Both retain `person_id`, full `name`,
`short_name`, explicit `aliases`, optional authored `dates` and named `links`
(`title`, `url`, optional `kind`/`language`). Mentions retain their exact visible
`text` and `footnote` role. Profiles add ordinary title, label, number and tag.
Children distinguish `person_summary`, `person_biography` (profiles only) and
optional `person_portrait`, whose ordinary image node uses the shared asset
store. The reading view retains identity, rich prose and linked resources;
physical catalogue paths remain in provenance only. A mention does not export
the unselected full biography. No popup geometry or hover state is semantic
data. Embedding transport 2 and provenance 1 remain unchanged.

Bundle manifest version 31 and canonical document schema version 28 add
native checkbox controls (`kind: "checkbox"`, Boolean `default`, optional
`label`). Their symbolic parameter has numeric value `0` or `1`. Conditional
`graphic_point` and `graphic_vector` nodes retain `when` comparisons, including
visibility of draggable points. A vector-valued `computed_output` retains an
`expression` object with `type: "coordinate_vector"` and ordered component
expressions in `coordinates`; scalar expressions remain strings. JSON and
Markdown retain these declarations independently of current learner values.
Hidden slider rows and output frames are presentation only. Embedding
transport 2 and provenance 1 remain unchanged.

Bundle manifest version 30 and canonical document schema version 27 add
`draggable: true` to movable `graphic_point` nodes. Their original symbolic
`position` identifies writable sliders in the enclosing `interactive_graphic`;
constant coordinates stay fixed. JSON and Markdown retain this author-declared
input opportunity, including the existing slider ranges, steps and defaults.
No separate point input identity, hit geometry or learner position is added.
Embedding transport 2 and provenance 1 remain unchanged.

Bundle manifest version 29 and canonical document schema version 26 add
native `applet` blocks. Their `applet_content` and `applet_description`
children preserve the full web content and print companion separately.
Ordinary block identity, title, number, tag and `canonical_url` remain semantic
attributes; the reading view includes both bounded bodies and an online link.
HTML's visible print-description omission does not erase its embedded AI
meaning. No live learner state or QR geometry enters either semantic artifact.
Embedding transport 2 and provenance 1 remain unchanged.

Bundle manifest version 28 and canonical document schema version 25 add
optional mathematical point labels. `graphic_point` retains the original
`position`, optional `name` and readable `label_text`, fill/label colors, and
sparse `graphic_label` children for annotated mathematics. JSON and Markdown
omit marker size and polar label placement. Embedding transport 2 and
provenance 1 remain unchanged.

Bundle manifest version 27 and canonical document schema version 24 add
`graphic_curve` nodes inside coordinate systems and free drawings. Both JSON
and Markdown retain `interpolation: "hobby"`, ordered `points`, `tension`,
`closed`, endpoint `start_curl`/`end_curl` for open curves, and `segments`
containing each cubic's `start`, `control1`, `control2`, and `end`. Coordinates
are numeric strings in the original data frame, without target scaling.
Stroke color remains identifying information; width and cap style are omitted.
Embedding transport 2 and provenance 1 remain unchanged.

Bundle manifest version 26 and canonical document schema version 23 add
semantic `quote` blocks. JSON retains their nested bodies, emphasis, optional
title, number/tag, label, item identity and explanations. Markdown identifies
the quotation and keeps its body in a finite nested scope. Physical indentation
and spacing are omitted. Embedding transport 2 and provenance 1 remain unchanged.

Bundle manifest version 25 and canonical document schema version 22 define
native choice `selection: "at_most_one"`: selecting no option is permitted,
while selecting more than one violates the input rule. JSON retains this
cardinality and Markdown states the permission to leave a question unanswered
explicitly. This is authored input policy, not evidence of a learner's current
response. Rebuild older choice bundles that declared `exactly_one`; do not
interpret them as the current permission to omit an answer. Embedding transport
2 and provenance 1 remain unchanged.

Bundle manifest version 24 and canonical document schema version 21 add
item-owned `single_choice` and `true_false` inputs and `multiple_choice`
collections. Both JSON and Markdown retain the actual shuffled item/option
order, canonical input and option keys, prerequisites and group scoring.
Correct keys and explanation children occur only with solutions enabled;
learner bundles contain neither. Physical boxes, relative widths and the
tooling replay seed are omitted. Embedding transport 2 and provenance 1 remain
unchanged.

Bundle manifest version 23 and canonical document schema version 20 specify
that a coupled slider keeps its interior value until reaching a boundary, then
follows that boundary until manually moved inside. This updates the existing
`slider_values` contract without importing learner view state into author data.

Bundle manifest version 22 and canonical document schema version 19 retain
coordinate panning and the zoom policy's preservation of slider values while
their transformed range and step admit them. These replace the previous
value-scaling interpretation. Embedding transport 2 and tool provenance 1 are
unchanged.

Bundle manifest version 21 and canonical document schema version 18 add
coordinate zoom contracts and shared graphic/output conditions. A condition
with `displayed: true` retains the affected slider's
`condition_significant_digits`: changing that precision changes the domain.
Ordinary numeric display precision is still omitted. Zoom retains its centre,
control coupling, factor, step limit and adaptive precision rule; current
learner view bounds and numeric results never enter the author bundle.
Embedding transport 2 and tool provenance 1 are unchanged.

Bundle manifest version 20 and canonical document schema version 17 retain
composed interactive bodies, computed numeric outputs with explicit domains,
and mathematical names on general arrows. Output values and label visibility
remain derived presentation, not learner state. Embedding transport 2 and tool
provenance 1 are unchanged.

Bundle manifest version 19 and canonical document schema version 16 add inline
`exam_credit` checkpoints with exact achievable scores and exam/item identity.
These are marking guidance, not awarded learner scores. Private per-task time
notes remain excluded. Embedding transport 2 and tool provenance 1 are unchanged.

Bundle manifest version 18 and canonical document schema version 15 retain
the series in `exam.group` on headers, task occurrences and selected histories.
The former header-only `variant` attribute is replaced by this exam identity;
rebuild older exam bundles to obtain consistent series relationships. Group
selection exports only the selected content, not the inactive branches.

Bundle manifest version 17 and canonical document schema version 14 add
exam identity, occurrence-specific achievable points, validated score grids,
unfilled assessment fields and explicitly selected item exam histories.
These are authored assessment context, not learner answers or awarded marks.
Embedding transport 2 and tool provenance 1 remain unchanged.

Bundle manifest version 16 and canonical document schema version 13 add
free inline drawing and triangle semantics without invented axes. Embedding
transport 2 and tool provenance 1 remain unchanged.

Bundle manifest version 15 and canonical document schema version 12 retain
nested direct Python layout/list contents through the shared typed-body path.
Opted-in MuWeave content strings are expanded rather than exported as literal
commands; nested semantic blocks, annotations, numbering, and input identities
are preserved. Rebuild older bundles using such direct calls. This changes
content interpretation, not the node shape or provenance/embedding transports.

Bundle manifest version 14 and canonical document schema version 11 omit
occurrence-local following space from MuVocab's typed logical quantifiers.
Rebuild older bundles for layout-invariant `\forall{}` / `\exists{}` source
and matching semantic ranges. Raw authored TeX is not rewritten; tool
provenance format 1 and embedding transport 2 are unchanged.

Bundle manifest version 13 and canonical document schema version 10 remove
diagnostic `source` fields from nodes and metadata. Tool provenance format
version 1 retains those origins separately and binds them to the exact
`document.json` bytes. Rebuild older bundles to obtain compact semantic JSON
and the map; do not interpret a missing node `source` as lost provenance.

Bundle manifest version 12 and canonical document schema version 9 add exact
circular arcs and correct the meaning of a plain graphical line name: `a` is
scalar, while explicit vector notation remains `\vec{a}`. Rebuild older
exports after migrating any intentionally implicit vector line names.

Bundle manifest version 11 preserves finite owner scopes, source-item identity,
and keyed companion parts in the reading view and rejects ambiguous notebook
sessions. Canonical document schema version 8 removes reserved text-field line
counts: they are layout, not an answer-length contract. Rebuild older bundles
to obtain the current reading boundaries and validated input declarations.
Bundle manifest version 10 and canonical document schema version 7 retain
the resolved backgrounds of named educational panels, together with their
kind and reference identity. Rebuild older exports to obtain these colors;
an old block kind alone cannot recover an author's overridden theme.
Bundle manifest version 9 makes asset aliases unique even when authored names
already occupy a generated digest or numbered fallback. Rebuild older bundles
that contain colliding asset names; the wrong payload cannot be recovered from
an ambiguous old alias. That change kept canonical document schema version 6.
Bundle manifest version 8 makes editable-showcase intent and existing notebook
cell identities explicit in the reading view, with separate author-source and
original-build-result roles.
Bundle manifest version 7 and canonical document schema version 6 retain
content-identifying colors at their text, mathematical, and graphic scopes.
Manifest version 6 introduced explicit text roles, question explanations,
and protected prose/verbatim content in the reading projection; document
version 5 removed question centering as presentation-only data.
Manifest version 5 and document version 4 introduced complete selected
symbol/index entries, supplied meanings, hierarchical paths, and occurrence
anchors. Manifest version 4 introduced
complete supplied interactive metadata; document version 3 removed
presentation-only control and curve-resolution fields. Earlier versions
introduced response content, exact graphics, scoped mathematical explanations,
and reference destinations. Rebuild older bundles to obtain the current
semantic views; missing annotations cannot be recovered from flattened TeX.
Embedding transport remains version 2; these versions are independent.

`document.json` stores metadata and ordered nodes. Every node has a stable
semantic `type`; relevant nodes add text, semantic attributes, and children.
Nearest author-source coordinates are indexed in `provenance.json` instead.
Pure decoration and physical page layout
are absent; identifying content colors are retained as described below.
Asset records contain bundle paths, MIME types, sizes, and SHA-256 hashes.

Private author-note bodies are absent even in an ordinary working export and
are skipped before nested evaluation. Stable structured-item IDs remain on
the corresponding semantic block nodes because they are useful for tutoring,
references, and matching learner work; visual bare-ID badges and the
`Arbeitsfassung` status are presentation and never enter the bundle.

Model-solution visibility follows the same strict source-ordered `solutions`
configuration as visible targets and defaults to true. With
`--config ~solutions`, generic `µsolution{...}` nodes and a canvas's optional
model-solution child are absent. A retained mathematical solution in `reserve`
mode instead leaves an empty, explicitly withheld span, never its answer or
annotations. A pedagogical `µblank{expected}` is the
intentional exception: its expected answer remains semantic tutoring data even
when visible output hides it, while underline, padding, and box dimensions are
discarded as presentation. This policy is independent of `--publish`.
The visible-target `theme.solution.foreground` color is likewise presentation
and is not serialized into semantic AI content.

The bundle is static data. It does not contact a model and contains no key.

## Embedded transport

PyHTML places this same semantic context inside a standalone worksheet by
default:

```console
pyhtml chapter.muweave
mucompose chapter.muweave --backends=html
```

Use `--no-embed-ai` in PyHTML or `--no-html-embed-ai` in MuCompose to omit it
deliberately.

The HTML then contains one invisible element:

```html
<script id="muweave-ai-bundle" type="application/json">...</script>
```

Its outer object has format `muweave-ai-embedded-bundle`, an integer
`format_version`, the parsed canonical manifest, exact `document.md`,
`document.json`, and `provenance.json` strings under `files`, and asset records.
In normal PyHTML output, `asset_storage` is `references`: every bundle-relative path points to a
content-addressed object in the adjacent `muweave-asset-store` element. The
payload therefore occurs only once in the HTML. The envelope is transport, not
another semantic truth: parse `files["document.json"]` for the canonical
document. `provenance.json` is tool data, potentially including local author
paths; it is not part of the model-facing content. Do not send the complete
envelope blindly to a model. This separation is not a privacy-redaction switch
for distributed HTML; provenance remains embedded and inspectable.

The payload is inert and makes no request. PyHTML escapes HTML parser-sensitive
text before insertion; ordinary JSON parsing restores the original author
text. Saving an annotated worksheet preserves the element unchanged while the
separate `worksheet-state` element records learner answers and pen strokes.

```javascript
const envelope = JSON.parse(
  document.querySelector("#muweave-ai-bundle").textContent,
);
const semanticDocument = JSON.parse(envelope.files["document.json"]);
```

The AI manifest retains each portable path, MIME type, size, and digest while
the visible element and AI record share one object ID. Embedding remains the
default. Use the explicit negative switch only when the semantic context itself
is unwanted; it is no longer necessary to avoid a duplicate asset payload.

The embedded bundle is generated from the exact typed expansion used for the
visible HTML. Author commands therefore execute once, and target gates describe
the HTML view. A separately invoked `pyai` process intentionally evaluates a
fresh AI target and may differ when a source contains target-specific content.

## Reading policy

`document.md` is the reading projection without repeated source coordinates or
rendering internals. Response areas retain their available authored children:
given scaffolds/diagrams and enabled model solutions are quoted below the stable
input identity and explicitly distinguished. An empty area remains an
**authored input declaration**, not a statement that a learner has failed to
answer. The quoted group ends before subsequent document text.

Coordinate systems and 3D scenes include a fenced semantic JSON description,
not only their range summary. This retains the provider's exact geometry,
axis labels and units, symbolic functions, angle ray types, and annotations.
It is derived from the source-coordinate-free canonical node with redundant
summary text and renderer-only curve sample counts removed; it is
neither SVG nor a screenshot. This also applies to diagrams inside a response
area. Plain prose and equations in a model solution use the ordinary reading
projection, without a second source evaluation.

The reading view retains reference captions and destinations, external URLs,
solution-to-owner relations, supplied interactive-control/activity metadata,
selected symbol/index entries, and the text roles described below. The
[static-context milestone](../TODO.md) tracks the remaining completeness work,
including the broader input-kind audit.
An omission in a view must not be treated as author intent.

### Exams and assessment context

`exam_problem` is a task scope with ordinary numbering, label and `item_id`,
plus exact achievable `points` as a decimal string. Optional `exam` contains
`key`, `title`, the unchanged `course`, an ISO calendar `date`, and optional
`group` (such as A, B, N or N2). Optional `topics` is an ordered string list,
`duration_minutes` a positive integer, and `course_label` the header display
alias, never a replacement for the canonical course. Absent optional fields
mean unspecified metadata, not an inferred duration or course label. These are
the points for this task **in this exam**, not an intrinsic task difficulty or
an awarded learner score. The Markdown projection retains both properties.

Topics and duration remain authored exam facts in AI even when they are not
printed. The topics' private first-header visual projection and the lack of a
visible duration are presentation choices, not semantic redaction. This does
not change the exclusion of explicit `µprivate{...}` bodies from all AI output.

`exam_header` retains the exam/series metadata, ordered score-grid
entries (`target`, `number`, `points`) and `total_points`. Its grid is validated
against actual task occurrences before rendering. Page layout, ruling,
repeated page chrome and teacher footer signature are omitted. The initially
empty name, awarded-score and grade roles are listed in `unfilled_fields`,
without a claim about a learner's actual identity or result.

An explicitly selected item history contains `exam_appearance` records with
exam identity and that use's points, bounded by the owning item part. The
unselected `exam_appearances` part is not evaluated or exported. Compilation
does not record a new historical use, and PyAI reads no sidecar or assessment
database. See [exam authoring](../../muvocab/docs/AUTHORING.md#exams-and-occurrence-specific-points).

An inline `exam_credit` follows the solution step to which it applies. Its
`points` is an exact decimal string; `step` is the item's checkpoint key,
`item_id` identifies the reusable item, and `exam_key` plus nullable `group`
identify the assessment occurrence. Full exam metadata lives on the owning
task/header; it is not repeated at every checkpoint. Markdown retains these
identifiers beside the achievable credit. The surrounding solution supplies
the criterion's content. Circle size, border, and placement are not semantic
data. Private per-task time estimates requested by `grading.time()` are omitted,
unlike the independently declared exam-wide `Exam.duration_minutes`.

### Text roles and literal source

Canonical `strong`, `emphasis`, `underline`, and `definition_term` nodes retain
their separate roles and ordered children. A definition term additionally
retains its supplied `convention`, currently `meta` or `zfc` for MuVocab.
Bold text alone does not declare a definition, an examination priority, or any
other inferred importance.

The reading view expresses strong and ordinary emphasis through inline
`<strong>` and `<em>` tags. Unlike runs of asterisks, these remain unambiguous
for adjacent, nested, whitespace-padded, and mid-word spans. Underlining is
explicitly labelled `[Underlined: ...]`; a definition term is labelled
`[Defined term; convention=meta: ...]` or the supplied convention. These notes
scope the retained content; they do not add an interpretation of its subject.
Their square brackets are escaped in Markdown to prevent adjacent parentheses
from turning them into links. Explanations remain beside the annotated value,
including inside footnotes and response content.

A `question` retains its question kind, body, authored title, numbering/tag,
reference key, and any explanation attached to the block. Enclosing item and
response structure supplies its context. The reading view identifies the
question and includes its block explanation after the body. Alignment, panel
colors, and dimensions are not part of either AI view; changing `center` alone
does not change its semantics. No new item or input identity is allocated by
this projection.

A `quote` identifies an authored quotation independently of its font weight.
It retains the same optional designation and reference/item metadata as other
blocks. Its children include every quoted paragraph, mathematical expression
and nested block; `strong` or `emphasis` only occur when authored. The reading
view introduces the quotation with its semantic designation and bounds its
children with block-quote syntax, resuming ordinary prose after the quote.
Block explanations stay inside that scope. Indentation is presentation only.

Ordinary prose, titles, captions, and explanations are **literal text, not
Markdown source**. Their soft whitespace is normalized and active Markdown/HTML
characters are escaped. Paragraph-leading heading, list, and rule syntax is
protected as well. Formatting comes from semantic nodes, not from punctuation
that happens to occur in authored text. Mathematical TeX and its annotation
ranges never pass through this prose escaping.

Verbatim bodies and showcase sources remain literal code. Fences are longer
than any backtick run in the source; an existing final newline or blank line is
preserved without adding another blank line. A source lacking a final newline
gets only the separator required before the closing fence. Inline code uses
CommonMark's padding rule to preserve edge spaces and literal backticks. Empty
or multiline inline code uses `<code>` with escaped characters and numeric
line-ending references, because ordinary code spans normalize newlines.
Canonical JSON always retains the exact original literal string, including
tabs and line endings. Showcase source and the already evaluated result remain
distinct; showing the source never runs it again.

### Showcases and editable notebook cells

A `showcase` contains an exact literal `showcase_source` and an already
evaluated `showcase_result`. Both are **author content**. The reading view
quotes the branches together under explicit source/result headings, so a
nested showcase or a following paragraph cannot be mistaken for part of a
different cell. Results retain their ordinary semantic projection, including
formulas, diagrams, references, colors, and explanations; the source remains
literal MuWeave, not model instructions or a second execution.

`attributes.editable=true` declares an opportunity to edit and manually execute
the source in a supported native host. `attributes.session` is the existing
stable document-local cell identity, also used by the HTML notebook. The
reading view preserves it as `session=...`; it is not a learner-attempt ID.
Without editable intent, a showcase remains a static author example. An empty
cell still retains its declaration and empty source/result branches, without
claiming that a learner has or has not answered it.

Containing item blocks, companion labels/owner references, and ordered section
headings supply context without repeating the task text or allocating AI-only
IDs. For example, a cell with `session="41:experiment"` stays within item `41`
even if that exercise's displayed number changes. Session names are authored,
not automatically item-prefixed; authors must keep them document-unique, as
required by the existing editable-showcase API.

The bundle does not load edited source from `.work`, invoke a notebook kernel,
or include later runtime results. Opening or editing a notebook does not
rewrite the original author bundle. Future learner attachments must reference
the matching document/publication and this existing cell identity separately.
An omitted private or hidden solution body contributes no cell declaration;
literal source intentionally displayed by a retained showcase remains literal
author content, subject to the same source-display policy as visible targets.

### Computed outputs and composed interactive content

An `interactive_graphic` retains ordered control declarations and the complete
symbolic content body. Its children may include several axes and outputs;
layout columns do not add semantic nodes. Control names are local to the
owning interactive ID. No current browser values or generated SVG coordinates
are exported.

`computed_output` is a read-only scalar display, not a response declaration.
Its attributes retain `expression`, optional unit, `undefined` text, optional
`when` with `left`, `comparison`, and `right`, and optional readable
`label_text`. Its mathematical label is the node text, with existing sparse
math children for annotations. The renderer-added equals sign is not authored
content. The explicit comparison keeps a domain hole even if the symbolic
expression has simplified. Numeric display precision and rounded default/live
results are omitted; they cannot alter the expression's meaning. Markdown
retains the same bounded JSON description and every nested annotation.
General `graphic_arrow` nodes likewise retain an optional mathematical name,
readable identity, label color and sparse annotations using the existing
segment-name contract. Label position and minimum visible length are omitted.

### Free drawings and triangles

`graphic_canvas` groups original graphic children in local coordinates,
without implying visible axes, coordinate ranges or a learner input surface.
`graphic_triangle` retains `vertices` in authored a/b/c order; its three
`graphic_line` children connect BC, CA and AB respectively. Their optional
names therefore denote the sides opposite the corresponding vertices.
`graphic_angle` children identify their actual vertex and both ray directions.
Vertex names use `graphic_label` children with `position`, mathematical `text`,
optional human-readable `label_text`, label color and sparse math annotations.
Only present labels/angles are emitted. A standalone triangle has the same
meaning as a composed triangle, without an extra invented coordinate system.

The reading view preserves the same subtree, including colors and nested
annotations. Sizes, fit aspect, geometry scale, layout `bbox`, baseline,
padding, stroke widths and measured bounding boxes are omitted. These
presentation settings do not change the authored local-coordinate geometry.

### Circular arcs and mathematical graphic names

Circular arcs retain exact authored geometry as `graphic_arc`: `center`,
`radius`, `start_angle`, and signed `sweep`. Coordinates and radius are in the
containing axis's data coordinates; `angle_unit="degree"` and
`positive_orientation="counterclockwise"` disambiguate the direction. A sweep
of `360` or `-360` is a complete circle. SVG paths, projected ellipse radii,
stroke widths, line caps, and label offsets are presentation data and are not
exported. The reading view includes the same semantic graphic subtree, not an
image placeholder.

Line, arc and point names are mathematical labels without an implicit vector accent.
For example, `g.line(..., name="a")` retains `name="a"`, whereas explicit
`name=v.a` or `name="µv.a"` retains `name="\\vec{a}"`.
`g.vector(..., name="a")` continues to denote a named mathematical vector.
Quoted MuWeave names use their already evaluated, source-ordered math argument;
AI projection never expands them again. A supplied `math_label` also retains
its readable `label_text` when that differs from the mathematical spelling.

`g.point(..., label=p.A[1])` projects as `graphic_point` with original
`position` coordinates and `name="A_{1}"`. An unnamed point omits `name`.
Point marker `radius`, `label_angle`, and `label_radius` are presentation
data and never enter either AI view. The marker's color is retained under
`colors.fill`; a present label adds `colors.label`.

Nontrivial label content adds a `graphic_label` child with the existing sparse
mathematical fragments, so scoped explanations, blanks, and explicit colors
are not lost by flattening the label to its formula. The graphic retains its
exact stroke and label colors under `attributes.colors`, using the contract
below. Label placement alone does not change either AI view.

### Content colors

Explicit foreground annotations, generated graphic-object colors, and named
educational-panel backgrounds are retained even when the author never mentions
a color in prose: a learner may later ask about "the red curve" or "the text
in the green box". MuVocab uses its existing portable `Color`
model rather than reinterpreting CSS, LaTeX, or color names during AI export.
Each affected node has `attributes.colors`, a mapping from paint role to exact
opaque sRGB, with an exact portable palette name when available:

```json
{
  "type": "graphic_function_plot",
  "attributes": {
    "expression": "2*t",
    "variable": "t",
    "domain": ["0", "3"],
    "colors": {"stroke": {"srgb": "#FF0000", "name": "red"}}
  }
}
```

The `srgb` field is canonical uppercase `#RRGGBB`. `name` is optional and uses
the lexically first exact alias from the existing palette; it is not a nearest
color guess. Equivalent names, hexadecimal inputs, and `Color` objects produce
the same data. A custom RGB color without an exact name retains its RGB alone.

`foreground` describes an explicit content scope. The innermost scope takes
precedence; flattened inner-first annotation tuples retain their first color.
Child colors remain more local than parent colors. The reading view marks
inline content as `[Color foreground=red (#FF0000): ...]` with escaped brackets.
A colored block is a bounded quotation introduced by its color scope. This
preserves references, code, and nested scopes without pretending the Markdown
renderer has to paint the color. No importance, correctness, or pedagogical
meaning is inferred from a hue.

`background` identifies the main surface of a `theorem`, `definition`,
`remark`, `attention`, or `question` block. It is attached to that node beside
its ordinary kind, title, number, reference key, and item identity where
applicable. For example, a default theorem has
`"colors": {"background": {"srgb": "#B8E2B5"}}`. Plain blocks do not acquire
an invented independent background. The reading projection retains the panel
and its complete contents in the same bounded color scope; it does not need
to draw a colored box itself.

These colors come from the block occurrence's resolved `Theme`, not from a
fixed AI palette or the final configuration after source evaluation. Complete
themes, individual role overrides, and source-order changes use the same
resolution as HTML and LaTeX. Nested panels retain their own backgrounds;
foreground annotations remain a separate role and never overwrite the
background. When embedded in HTML, this metadata is projected from the same
already evaluated occurrences as the visible panels.

Inside mathematics, existing `math_fragment` children carry `colors` beside
their exact half-open TeX ranges. A whole formula or conceptual equation cell
can have its own foreground, with narrower segment/fragment overrides. Reading
notes identify the row, cell, segment, and/or TeX range. The mathematical TeX
is unchanged: no color macros or extra delimiters are inserted, and identical
terms at different positions remain distinguishable.

Graphic roles distinguish `stroke`, `fill`, and `label` where applicable.
Riemann sums additionally retain an optional `approximation` trace color and
exact `fill_opacity` from zero to one; absence of an approximation color means
no separate trace was requested. The RGB is the original paint, not a guessed
composite against a background. Object colors, including default paint colors,
stay with the exact geometry in both 2D and 3D and in reactive graphics. Canvas
underlays retain colors in their authored scaffold; enabled model-solution
children remain separate. Graphic reading JSON retains these same fields.

This does not copy every theme role: automatic link/unit/solution palettes,
side-tab and border accents, author badges, and editing chrome remain outside
this projection. Stroke widths, font sizes, zoom, and spacing remain layout.
Explicit `µcolor` scopes and
graphic paint colors are not discarded merely because they might be decorative.
Hidden private content, phantoms, and withheld solutions supply no colors;
the documented expected-answer exception for `blank` remains unchanged.
No source is evaluated again, and no image, webpage, or running quiz is
inspected to infer additional colors. Existing local-image assets retain their
original content instead of acquiring an invented color legend.

### Links and targets

References use the producer's resolved designation and exact stable key:

```markdown
Siehe [(PG.2)](<#eq:power-same-exponent>).
Siehe [Aufgabe 2.1 a)](<#41/entry/derive>).
```

The destination is not guessed from a heading slug or the current task number.
An explicit empty HTML anchor declares each retained target in Markdown, for
example `<a id="41/entry/derive"></a>` beside the corresponding list marker.
Section, named-block (including question), figure, and whole-equation labels
are anchored at their designation. Equation-row labels are identified by row
and tag in the accompanying math details, outside the unchanged TeX. Explicit
inline anchors retain their source position. An input area's human caption is
not a reference ID; its worksheet identity remains its qualified `name`.

Solution/companion blocks also include a `For:` reference to their declared
owner, without copying the task statement. Short and full list-reference
captions can therefore point to the same owner-qualified entry key. Links
survive nesting in emphasis, footnotes, tooltips, and authored response content.

A QR link becomes `[Link](<https://example.test/quiz>)`; a URL without a distinct
caption is written once as `<https://example.test/quiz>`. QR geometry is not
included. An interactive activity includes its supplied `canonical_url` as
an `Online version` link. This does not run the activity or add external-page
content to the author document. No URL is fetched during export.

Captions are escaped as literal text. Destination escaping preserves URL
delimiters, existing URL escapes, and exact internal keys, including literal
percent signs. JSON stores the original unescaped values. The reading view's
links express semantic relationships, independently of whether the visible
backend enables clickable links or previews. It never reconstructs an omitted
target: a reference in a partial export can retain its key even when the target
body is absent. The canonical tree remains authoritative for target lookup;
Markdown consumers that strip HTML anchors can still read the stable IDs in
the source, but may not provide working in-document navigation.

`document.json` retains substantially more content and structure. Important
examples are:

- stable labels and resolved reference targets;
- theorem, definition, problem, exercise, sample-problem, solution, and proof
  roles;
- enumerated-list order, visible entry markers, stable entry keys, and
  owner-qualified entry targets, regardless of vertical or grid presentation;
- equation rows, cells, alignment segments, tags, and automatic numbers;
- response-field identities and intended text, graphic, or local-canvas answer
  type, including an enabled canvas model-solution child;
- exact coordinate-system and 3D-scene geometry;
- interactive controls with their symbolic geometry, and supplied activity
  objectives, identities, and versions;
- keyword/symbol directory occurrences;
- tooltip text as model-readable explanations;
- explicit foreground scopes and graphic paint colors, including mathematical
  subexpression ranges and Riemann fill opacity.

The reading view and structured view are generated from one immutable tree.
Neither is reconstructed from the other.

The remaining static-context audit is tracked in the package TODO. JSON is not
a workaround for every possible provider omission; the intended
meaning-preservation contract is PAI-SEM-01, not a claim that every supported
combination has already been audited.

### Selected terms and symbols

Only explicit MuVocab `index.term`, `index.mark`, `symbols.term`, and
`symbols.mark` occurrences contribute entries. Ordinary words and mathematical
appearances are not searched. A `symbols.define` metadata declaration without
a retained marker does not create an entry. Meanings are the author's supplied
descriptions, not interpretations invented by the exporter.

Each `symbol_marker` retains its stable symbol `key`, TeX `notation`,
`description`, optional `group`, selected-location `role`, and occurrence
`anchor`. Only a visible `symbols.term` also has visible `text`; an invisible
mark still communicates its metadata without claiming the notation was printed
at that point. An `index_term` retains its exact visible phrase; both index
marker kinds retain every selected `paths` value, role, and occurrence anchor.
The roles remain `definition`, `explanation`, `example`, and `related`.

Every retained `index` or `symbol_directory` listing is assembled after the
complete AI projection, including nested bodies. Thus a directory placed first
also contains selected occurrences later in the document. Omitted private or
ordinary solution content contributes nothing, even if measurement of a hidden
solution had evaluated its body earlier. Enabled model solutions remain
authored content in their enclosing scope. No source is evaluated again and no
live final namespace or sibling `.work` is consulted.

Directory children have type `directory_entry`:

- An index entry's `text` is one path component; its `path` attribute is the
  complete displayed path. Nested entries preserve arbitrary hierarchy.
  Intermediate entries may have occurrences of their own as well as children.
  MuVocab's existing explicit-key/case-insensitive sorting applies; no extra
  word splitting or path permutations are introduced.
- A symbol entry's `text` is its TeX notation. Its attributes retain `key`,
  `description`, and optional `group`, in MuVocab's ordinary group/sort order.
- Both carry ordered `occurrences`, each containing `anchor` and `role`.
  Multiple definitions and repeated selected locations remain distinct.
  A directory with no retained selected occurrences is legitimately empty.

The reading view uses math delimiters for symbol notation, literal escaped
text for descriptions and paths, and links labelled by the selected-location
role. Explicit anchors at the markers make these links navigable without
inventing PDF page numbers. Nested index entries remain nested lists.
Marker meanings and roles are also readable when no listing is requested.

A symbol key is authored identity. Generated occurrence anchors are
deterministic **within a publication**, avoid authored target keys, and locate
selected passages; they are not persistent learner-input IDs across revisions.
The surrounding item/part structure and separate tool provenance retain
the passage's context. This AI assembly does not add a visual directory
renderer to PyHTML.

## Interactive input declarations

Native choice questions are complete authored input declarations, unlike a
module that may generate questions later. A `single_choice` or `true_false`
node retains `name` (`ITEM_SCOPE/choice/LOCAL_NAME`), `local_name`, and
`selection: "at_most_one"`. A question may be left unanswered; it does not
require a selection. Markdown repeats this authored permission explicitly so
the reading view cannot imply that the learner must choose an option.
Its `question_prompt` or `statement` and optional
`prerequisites` contain ordinary recursive subject matter. Ordered
`choice_option` children each retain `key`, `id` (the input ID plus
`/option/KEY`), and their complete content. True/false uses keys `true` and
`false`, displayed as `w` and `f` in the authored material.

With solutions enabled, the question additionally has `correct` naming one
stable option key and may have a `solution` explanation child. Disabled
explanation source is never evaluated and neither artifact carries a hidden
correct key. A correct key denotes the author's model answer, never a learner
selection or completed attempt. Learner `.work` remains outside the bundle.
Permission to omit a response likewise makes no claim that the learner has
left it blank. When a collection supplies scoring, its `blank` value governs
an omitted response independently of the selection limit.

A `multiple_choice` collection retains its stable `name`, shuffled `items`
sequence and a `scoring` object. Each `choice_item` child identifies its
canonical `item_id` and one-based current `position`. Scoring retains exact
decimal-string `correct`, `blank`, `floor`, and `maximum`, the rule
`incorrect: "-correct/(option_count-1)"`, `multiple_marks: "incorrect"`, and
`floor_scope: "whole_group"`. A positive `correct` is achievable credit; the
floor applies once after all penalties. Nested `exam_credit` remains the
existing occurrence-specific rubric semantics. Markdown carries these same
attributes and recursively bounded children, including option IDs and
prerequisites. No renderer-specific box, width, replay seed, or model-color
field becomes subject matter.

HTML and its embedded bundle consume one typed expansion, not independent
randomization. Separate builds use the same nonempty `exam.shuffle_seed`
configuration to replay the order; its value is tooling, not AI content.

An `interactive_graphic` retains its controls and symbolic coordinate-system
child together in one fenced semantic JSON description in `document.md`.
Its document-global `id` is the same identity used by the HTML runtime;
parameter names address the controls within that graphic. There is no separate
AI numbering system or execution of the author's graphic function for the
reading projection.

The `parameters` array retains the declaration order and these contracts:

- A `slider` has a `name`, inclusive `minimum` and `maximum`, exact `default`,
  and `continuous` flag. A discrete slider includes its exact `step`; a
  continuous slider omits `step`. Optional `label` and `unit` retain their
  mathematical text. Numeric values are strings preserving the semantic
  model's precision, not values rounded for the on-screen display.
- A `select` has a `name`, optional `label`, ordered `options` with each
  option's label and scalar expression, and both `default_index` and the
  selected label in `default`. The index is zero-based. The same parameter name
  in the symbolic geometry denotes that option index in a `Piecewise`
  expression. All alternatives survive, including initially inactive ones.
- A `checkbox` has a `name`, a Boolean `default` and an optional plain-text
  `label`. Its symbolic value is numeric `1` when checked and `0` when
  unchecked. Conditions can use this value to select visible geometry.

These defaults are **author-specified initial values**, not learner input.
Slider bounds may be symbolic scalar expressions referencing only earlier
controls. They are resolved in declaration order, with the current value kept
until it leaves the interval and then clamped and step-normalized. A collapsed
symbolic interval has one fixed value. Conditional slider labels use
`label: {when, when_true, when_false}`; both alternatives are mathematical
strings. Computed outputs instead use `label_condition` with
`output_label_true` and `output_label_false` child nodes. These retain rich
mathematical text, optional `label_text` and nested semantic explanations.
The chosen label does not change the output expression or its domain.

Within a 2D coordinate system, `graphic_point.draggable: true` permits direct
coordinate manipulation. Each nonconstant entry of `position` is the name of
a distinct slider in the enclosing scope; a constant entry stays fixed. The
slider's range/step contract governs movement, including any declared view
coupling. The flag is absent for an ordinary non-draggable marker. The complete
symbolic position and flag appear in both semantic views, without importing
browser state or presentation-only hit-target sizes. A point's `when` guard
also controls whether its label and drag interaction are available.

For example, a Riemann-sum graphic retains the whole family of selectable
integrands, the control `n`, its allowed range and step, and the sum's
`partitions: "n"`, interval, and `sample: "midpoint"`. A plot's independent
variable remains distinct from these control parameters. Slider-row and track
visibility, display precision, curve-rendering sample counts, physical size,
and browser controls do not belong to either semantic view. The mathematical
partition count and quadrature rule do.

An explicit display-aware condition is the exception to display precision
being purely presentational: `when.displayed` and the involved sliders'
`condition_significant_digits` retain its exact domain rule. Both operands
identify slider symbols. Conditions remain attached to their `graphic_line`,
`graphic_arrow`, `graphic_vector`, `graphic_point` or `computed_output`, even
if false at the authored defaults. A computed scalar retains its expression
as a string. A computed coordinate vector uses an `expression` object with
`type: "coordinate_vector"` and ordered string `coordinates`. Results and
output frames are derived presentation and are omitted from AI.
A `coordinate_system.zoom` retains `center`, `x_controls`, `y_controls`,
`factor`, `max_steps`, `pan`, `slider_values`, and `slider_precision`.
`pan` permits translating the viewport; `slider_values` specifies preservation
of interior values, attachment to reached boundaries, and discrete-step
normalization. It describes the available view
operation and how it changes coupled inputs; it is not a saved learner view.
These complete nested attributes also reach the Markdown reading description.

An `interactive_activity` retains its stable `instance`, module ID and version,
state version, selected activity, localized titles, supplied activity kind,
learning objectives, explanations, and canonical URL. The reading view uses
its ordinary block designation and URL link, with the remaining supplied
metadata in a fenced JSON object. Additional semantic fields are preserved,
not silently filtered through a second field list. Inline/tab, compact/full,
and viewport settings do not change this declaration's content.

Module metadata describes the selected authored activity, **not a running
quiz session**. Absent kinds, objectives, or future randomized questions are
not guessed. The exporter neither executes the quiz nor fetches its online
page, and does not use application JavaScript as a task description.

Enclosing item/part/section structure and companion-owner references supply
context without repeating the task statement inside each control. Native
graphic IDs and module instances remain document-global where those APIs
require it; placing them in an item does not automatically qualify their IDs
like a response canvas's name. Nesting in a response area does not turn this
authored content into a learner's attempt. `.work` is not read; hidden ordinary
solutions are not recovered. Embedded HTML/AI still share the single original
HTML expansion, including its target selection and captured configuration.

## Meaning inside mathematics

Formulas retain ordinary TeX in `text`, without HTML/MathJax macros or invented
`[blank: ...]` TeX wrappers. Optional sparse children carry meaning that TeX alone
cannot express:

- `math_fragment`: explanations for exactly one mathematical subexpression;
- `math_solution`: an authored model-solution fragment, with `visibility`
  equal to `visible` or `hidden`;
- `math_blank`: an intentional fill-in fragment whose `text` is the permitted
  expected answer, with the same occurrence-local visibility designation.

For example, `µm{F=µtooltip(v.a, "Kraft im Punkt A")}` produces this formula:

```json
{
  "type": "inline_math",
  "text": "F=\\vec{a}",
  "children": [{
    "type": "math_fragment",
    "text": "\\vec{a}",
    "attributes": {
      "start": 2,
      "end": 9,
      "explanations": ["Kraft im Punkt A"]
    }
  }]
}
```

`start` is inclusive and `end` exclusive, measured in **Unicode code points in
the immediate parent's `text`**. A span's text equals that exact slice.
Nested spans use their own parent's text; equal-looking occurrences have
different ranges. These are formula-local selectors, not source offsets,
rendered coordinates, or persistent learner-input IDs. JavaScript consumers
must account for its UTF-16 string indexing, for example by slicing
`Array.from(parent.text)` rather than treating code-point offsets as code units.

Unmarked mathematical text is given author content, subject to any enclosing
solution/blank role. A formula containing a `math_blank` may therefore include
an expected answer that the visible worksheet hides: **do not infer visible
givens from the formula string alone**. A hidden ordinary `math_solution`
has empty text, an empty range, and no child explanation or answer. A disabled
`omit` body has already been discarded before evaluation and leaves no span.
The blank exception does not bypass a nested ordinary solution's visibility.
Plain phantoms and their annotations remain layout-only and are absent.

This projection covers retained bodies and supported semantic operands,
including fractions, interval endpoints, lengths, structured vector indices,
mathematical list entries, and equation segments. It does not parse raw TeX into
an algebraic tree, reparse literal strings, or add unsupported author syntax.
Each visible backend retains its own supported annotation-placement boundary.

The reading view prints the formula and then compact **Math details**, with the
subexpression, its range, explanation, and applicable answer role. In equation
systems, row/cell/segment locations disambiguate the range's owner; annotations
on a whole aligned cell are retained as whole-cell explanations. Both exports
come from the same traversal of already evaluated values and their captured
configuration; no mathematical body is evaluated a second time.

### Mathematical notation and understanding

The formula's `text` remains ordinary mathematical LaTeX/TeX,
with the surrounding author prose, definitions, symbol descriptions, units,
references, and scoped annotations. Additional `attributes.typst` gives the
equivalent native Typst math without outer dollar delimiters or embedded code.
For example, a vector has `text: "\\vec{v}"` and `typst: "arrow(v)"`, while
a column vector uses `vec(1, 2)`. `typst_symbols` is an ordered, deduplicated
array of `{text, typst}` pairs for literal symbols, typed notation and reusable
subexpressions actually present in that formula. It does not invent physical
meanings or collect unused Python namespace entries.

Inline formulas, equations, equation segments, mathematical annotations and
selected symbol-directory entries carry this data. Graphic labels retain it
alongside their original label data (`name_math`, axis `x_math`/`y_math` and
unit counterparts, or within an angle's `label`); conditional output labels
retain their own branch's spellings. Existing semantic ranges still address
the parent's TeX `text`, never the added Typst string.

The shared native projector omits HTML wrappers, spacing and other physical
layout settings. Explanations, colors and didactic instructions remain in
their existing semantic fields. Hidden solutions and phantoms are not traversed;
intentional blanks retain their expected answer under the existing disclosure
contract. A null `typst` with `typst_unavailable: "unsupported_source"` means
the source cannot currently be represented within the code-free Typst subset.
This includes arbitrary raw LaTeX commands and some open matrix-stack layouts.
Their exact TeX is retained, and supported nested portable symbols can still
have spelling pairs. Export never guesses a translation or labels TeX as Typst.
The reading view displays the spelling and availability data as literal code.

Mathematical alphabets are notation, not disposable document fonts. `R`,
`\mathbb{R}`, `\mathcal{R}`, `\mathbf{R}`, and `\vec{R}` remain distinct,
as do supplied Unicode mathematical letters and combining accents. Export
does not apply compatibility normalization that could turn them all into
ordinary letters. Index grouping, vector arrows, accents, matrix structure,
fractions, and single versus double vertical delimiters are retained. Changing
only the outer document font size cannot erase these distinctions. The same
policy applies to mathematical list entries and graphic labels.

Portable MuVocab values project to ordinary notation, for example `v.x` to
`\vec{x}`, `v.x[2]` to `\vec{x}_{2}`, and `length(v.x)` to
`\left|\vec{x}\right|`. Their AI representation does not depend on PDF macros
such as `\vv` or on a MathJax font's glyph paths. Literal TeX inside a math body
is retained, not interpreted by a TeX engine, rewritten, or symbolically
simplified during export. Arbitrary raw TeX macros therefore remain opaque;
prefer supported semantic commands or standard notation with an explanation,
not unexplained custom macros. MuWeave commands have already been evaluated
once before this projection.

Notation alone does not define an object's meaning. `\mathbf{A}` does not
automatically declare a vector, and `x` does not automatically mean the length
of `\vec{x}`. Preserve what the author says, including nonstandard conventions,
rather than adding guessed types or definitions. Explicit symbol descriptions
and annotations provide that context without paraphrasing every formula.

An image or a rendered SVG is not the primary formula representation when the
source is available. Presentation MathML is also not automatically an algebraic
meaning tree; [Content MathML](https://www.w3.org/TR/MathML3/chapter4.html#contm.intro)
addresses explicit mathematical semantics separately. PyAI does not construct
either a second MathML/CAS representation or redundant verbal transcriptions
for every formula. Additional formal structure would need a concrete consumer
and a reliable, author-supported interpretation, not guesses from typography.

## Author context and declared inputs

A bundle describes the evaluated author document. It does not read a sibling
`.work`, query browser storage, or represent the current learner session.
An authoring assistant can consume it without any learner data. A future coach
uses the same immutable document together with a separately attributed runtime
projection; that join is not a second evaluation of the source.

Input opportunities are themselves author content. A local canvas, text
response, or quiz declaration tells a model where input is intended and which
authored context it belongs to; its existence says nothing about a learner's
progress. Given diagrams and scaffolds remain author content, as do permitted
model solutions inside a canvas. They must not be confused with learner ink.

Reusable input-bearing content can live in an item file, not only a problem
statement: the item's canonical identity then supplies the content owner.
Multiple input places inside it still need their local names/part distinction;
one item ID does not collapse all its responses into one answer. This reuses
the ordinary item lookup/allocation workflow and requires no second AI item
catalogue or separate explicit block label.

### Input identities and context

These are existing vocabulary/worksheet identities, not an AI-only registry:

| Authored input | Canonical kind | Identity and scope |
| --- | --- | --- |
| Text response | `response_text` | `name`, qualified as `<item-or-part>/text/<local-name>` for a source selected with `block.response`; otherwise the existing explicit document-global name |
| Graphic insertion | `response_graphic` | `name`, explicitly document-global; shares the response namespace |
| Handwriting surface | `response_canvas` | `name`, qualified by source item/part, for example `35341/solution/canvas/calculation`, or the explicit document-global name outside an item; `local_name` retains the authored name |
| Native choice question | `single_choice` / `true_false` | `name` such as `11/choice/answer`, `local_name`, and stable child option `key`/`id`; order never changes identity |
| External quiz/module | `interactive_activity` | Document-global `instance`, together with `module_id`, `activity`, and module/state versions |
| Native slider/select graphic | `interactive_graphic` | Document-global `id`; the ordered parameter names identify its controls |
| Editable showcase | `showcase` with `editable=true` | Document-global `session`; a static showcase has no learner-input identity |
| Text or mathematical blank | `blank` or `math_blank` | Containing content and, in mathematics, the exact TeX span; no independently persisted worksheet field is invented |

Dedicated `block.canvas` and `block.response` sources retain a `text_block`
owner named `Canvas` or `Textantwort`, its ordinary item/reference identity,
optional instructions, and exactly one corresponding response child. Their
reading groups preserve the same bounded ownership. This uses existing node
shapes; no older input key or serialized node changes its meaning. Appearance
and reference-label overrides do not allocate a new input identity.

Input kind/namespace is part of a future join: a response named `shared` and a
notebook session named `shared` are distinct. Within a namespace, duplicate
identities fail rather than merging unrelated content. Notebook session
uniqueness is checked by shared document preparation, including standalone AI,
not only by HTML. A blank remains pedagogical author content; handwriting over
it belongs to the containing drawing layer unless an explicit response surface
has been authored. Source positions and TeX spans are not persistent answer IDs.

Canonical children retain nesting in items, subitems, figures, and response
areas. Ordered section nodes and their logical levels supply the heading
context. A detached solution keeps its own location in that section sequence
and an `owner` reference to its task; its placement does not reassign the task.
The reading view quotes educational-block and list-entry bodies with finite,
nested scope, so a following global response cannot be mistaken for part of
the previous task. No whole task statement is copied into each input.

The occurrence's `label` and source `item_id` are different concepts. Reading
headings keep `[id: ...]` as the actual reference target; they add `[item: ...]`
when the item differs from that target, and `[part: ...]` for an explicit
companion key. For example, an occurrence named `answer:worked` may belong to
item `41`, part `worked`, with `owner="task:motion"`. Changing visible numbering
changes no input key. Local canvas keys follow the source item/part, not an
overridden block label. Repeating the same item/part/canvas under a different
block label therefore remains a duplicate, not a new learner surface; distinct
appearances do not implicitly allocate new persistence identities.

Names, labels, instructions, meaningful axes/units, authored scaffolds, and
permitted model answers remain in both views. A module declares only its
manifest-provided objectives and activity kind, not the individual questions
or answer-field identities a future randomized runtime may generate.
Declared inputs do not state whether a learner has answered them. No `.work`
data or notebook execution results are loaded. See the
[cross-component plan](../../muweave-suite/TODO.md) for publication matching,
learner timestamps, and derived visual snapshots.

## Deliberately absent information

The intended selection rule drops information that changes presentation but not
subject or pedagogical meaning: page breaks, indentation markers, QED ornaments,
external gaps, block margins, body ratios, decorative colors and font choices, visible
dimensions used only for layout, equation-column justification, and alignment
wrappers such as columns or text wrapping. The content inside a layout wrapper
remains in reading order. This includes direct Python calls containing semantic
objects or opted-in source strings, not only registered brace syntax.
Enumerated grids likewise become one ordered entry
sequence without a column count. Meaningful emphasis, mathematical notation,
and identifying distinctions such as "the red curve" must remain recoverable.
Explicit foreground and graphic paint associations follow the content-color
contract above, without guessing whether prose might refer to them later.
A requested response's text, graphic, or canvas role is semantic; response
geometry and paper styling are not. Reserved writing-line counts are omitted
from both semantic views; an explicit author-written answer-length instruction
remains ordinary meaningful content.

### Boundary between appearance and content

The distinction is made on semantic objects, not by deleting keys or TeX
commands from serialized output. The following pairs illustrate the current
MuVocab projection:

| Family | Omitted presentation controls | Retained author information |
| --- | --- | --- |
| Text and headings | Font size/steps, line height, paragraph and heading gaps | Text, hierarchy, numbering, emphasis, underlining, definition conventions |
| Mathematics | Fraction-clearance tuning, matrix row pitch, fence sizing, typed quantifier kerns, equation-column justification | Exact terms, alphabets, delimiters, quantifier kind, ordered rows/cells, tags, scoped explanations |
| Lists and composition | Grid column count, column widths, wrapping side, alignment and outer spacing | Entry order, markers, keys, references, and nested content in author order |
| Diagrams | Physical width/height/scale, placement anchors, stroke thickness, calibrated angle-label placement, plot rendering resolution | Data coordinates/ranges, axis labels/units, tick and grid increments, geometry, functions, names, identifying colors |
| Input surfaces | Reserved line counts, canvas dimensions, frame, padding and paper ruling, slider-track/number-display style | Input type/identity/owner, prompts, given diagrams, permitted model solutions, control ranges/defaults/alternatives |

An axis's physical `scale` is layout; its data range, numbered tick spacing,
and supplied grid are part of interpreting the given diagram. A camera's
projection and view parameters similarly describe the depicted 3D view,
not a document margin. A Riemann partition count is mathematical data, unlike
the number of points used to render a smooth curve. Changing any of those
retained values changes both semantic views. Colors remain identifying context;
they do not imply importance or correctness.

A literal passage about `µsize`, or a showcase displaying that command, must
still include it: there the source is itself instructional content. Likewise,
raw TeX is preserved exactly, including any authored spacing command. Only
known typed values omit their renderer-specific tuning; mathematical alphabets
and accents are never treated as disposable font settings. This is not a
mathematical-equivalence simplifier or a whitespace/code reformatter.

Regression pairs compare complete `document.json` and `document.md` artifacts,
without filtering attributes from either side. Each tested family also has
positive cases that change content, notation, identity, or explanation.
The separate diagnostic provenance map may change as source ranges move.
Tests cover both direct AI export and the shared, exactly-once HTML expansion;
item-owned inputs use isolated library fixtures rather than mutable lesson files.

Byte equality here concerns changing presentation parameters in an otherwise
unchanged retained content structure. Adding/removing a transparent wrapper
such as `µsize` may split or join canonical text leaves, while the reading
view and their combined text remain unchanged. Source reformatting can also
change retained prose whitespace. The canonical artifact is not a universal
semantic-equivalence hash; its source map still addresses the exact retained
nodes. Normalizing such segmentation would also need to preserve all affected
source origins, not discard them as a side effect of merging text.

## Local assets

Local images are copied and referenced by a relative bundle path. Their source
filesystem path is never written to the public manifest. Internet resources
remain links when the active vocabulary supports them; PyAI does not download
them. Rebuilding a bundle removes obsolete files from its owned `assets/`
directory while preserving unrelated files elsewhere in the bundle root.

Asset paths are allocated in first-registration order from sanitized filenames.
Collisions are checked without regard to case, including collisions introduced
by filename sanitization. A colliding name gets a twelve-hex-digit content-hash
suffix; if that candidate is occupied too, numbered suffixes starting at `-2`
are tried until a free name is found. No generated candidate replaces an
existing source's alias. Registering the same canonical physical path again
returns its existing alias. Distinct source files retain distinct aliases even
when their bytes are identical; PyHTML can still store those identical bytes
only once and map all aliases to the same content object. These paths identify
resources within a bundle, not persistent item or learner-input identities.

## Canonical document shape

The root object contains:

```json
{
  "format": "muweave-ai-document",
  "format_version": 22,
  "metadata": {},
  "content": []
}
```

Each content entry has `type` and may have `text`, `attributes`, and `children`.
Neither a node nor root metadata has an automatically captured `source` field.
Unknown future node types remain explicit rather than being
stringified. Consumers must check the integer format version before assuming
the meaning of fields.

`manifest.json` hashes `document.md`, `document.json`, and `provenance.json`
and lists every asset with its media type, byte size, and SHA-256 digest. The manifest is published
last. Replacements are atomic per file, not across the whole directory;
consumers reading during a rebuild must verify the hashes and retry if files
do not yet match the manifest.

## Citation and tool provenance

Use the existing item/part keys, labels, list-entry targets, equation-row
labels, and input identities to identify subject content. These remain in
`document.json` and in the corresponding reading scopes. Source line numbers
are not their identities. No parallel AI numbering or ID on every text fragment
is introduced.

For an unlabelled fragment, a tool can use its JSON Pointer inside the exact
structured artifact, for example `/content/3/children/0`. Such a pointer is an
export-local locator: qualify it by the SHA-256 of `document.json`, not merely
a document filename. It is not a persistent learner-state key. Existing
content references remain preferable when available; even generated directory
occurrence anchors only promise identity within their publication.

`provenance.json` contains:

```json
{
  "format": "muweave-ai-provenance",
  "format_version": 1,
  "document": {"path": "document.json", "sha256": "<exact artifact digest>"},
  "primary_file": "f1",
  "files": {"f1": "/author/lesson.muweave"},
  "ranges": {
    "r1": {
      "file": "f1",
      "start_offset": 0, "end_offset": 5,
      "start_line": 1, "start_column": 1,
      "end_line": 1, "end_column": 6
    }
  },
  "nodes": {"/content/0": "r1", "/content/0/children/0": "r1"}
}
```

- `files` stores each exact physical or virtual source name once. Equal
  basenames from different directories remain distinct. `primary_file` is
  present only when the in-memory document has a primary source name.
- `ranges` deduplicates equal `(filename, coordinates)` tuples. Offsets are
  zero-based Unicode-code-point positions in the original source, with an
  inclusive start and exclusive end; lines and columns are one-based.
- `nodes` maps occurrence pointers to known ranges. Repeated occurrences keep
  separate pointers even when they share a range. Unknown source origins are
  absent, never inferred from parents; source-less generated nodes still
  remain in the content tree.
- `f1`, `r1`, etc. are deterministic first-occurrence table keys, not item IDs
  and not stable across revisions. The optional primary file is registered
  first, followed by retained nodes in depth-first document order.

To resolve an origin, verify manifest hashes and `document.sha256`, then use
`nodes[pointer]` to obtain a range and `files[range["file"]]` for its filename.
Resolve labels against the canonical content tree before looking up the
resulting pointer. The map does not embed source text, reread files, or supply
a complete expansion stack: it retains the same nearest range that `AiSource`
records. It covers only finalized, retained nodes, never omitted private or
solution bodies. If provenance changes while content stays byte-identical,
the canonical digest stays unchanged and the manifest's provenance digest
identifies the current origin map.

Diagnostic paths may be absolute and identify the author's local machine.
They are not portable asset links and must not be opened as bundle resources.
Keep this artifact out of ordinary model requests; a tool can return one
requested location when appropriate. Authored literal paths and semantic
attributes named `source`, `start`, or `end` are not stripped. In particular,
mathematical subexpression offsets remain in the canonical tree because they
address meaning inside a formula rather than locations in a `.muweave` file.

## Python API

```python
from pathlib import Path

import muweave
import muvocab
import pyai

schema = muvocab.create_text_command_schema()
parsed = muweave.parse_string(
    'µsection(title="Kinematik")\n\nZeit: µm{t}.',
    source_name="lesson.muweave",
    text_command_schema=schema,
)
bundle = pyai.build_parsed(
    parsed,
    muvocab.create_ai_context(schema),
    title="Physik",
    language="de-CH",
)
pyai.publish_bundle(bundle, Path("lesson.ai"))
```

`build_string(...)` is the corresponding parse-and-build convenience API.
`AiDocument` and `AiNode` form the generic interchange model;
`AiVocabularyAdapter` is the narrow provider boundary for another vocabulary.
Its `prepare(...)` may return
`AiPreparedDocument(document, state, finalize_content=callback)`. This optional
provider-owned callback receives the complete retained `tuple[AiNode, ...]`
once after root projection, never separately for nested bodies, and must return
a `tuple[AiNode, ...]`. It can assemble cross-occurrence semantics such as
directories; it must not reevaluate source or restore omitted content. PyAI
validates the result and reports failures as `PyaiRenderError`. The provider's
opaque `state` may carry its per-projection collection data; PyAI does not
interpret it. Both output views use the finalized immutable tree.

`AiNode.source` and `AiMetadata.source_name` remain available to Python tools.
`AiNode.to_object()`, `AiMetadata.to_object()`, and `AiDocument.to_object()`
serialize semantic content only. `build_bundle(document)` additionally builds
`bundle.provenance_json` from the retained source ranges. It never reevaluates
the source or changes provider-owned labels and attributes.

`serialize_embedded_bundle(bundle)` creates an inline-asset JSON envelope
without adding an HTML element. A containing format can pass the exact
`asset_references` mapping to produce reference records instead; PyHTML owns
that shared-store integration.
