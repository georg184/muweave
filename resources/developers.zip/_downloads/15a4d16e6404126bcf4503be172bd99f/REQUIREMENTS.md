# MuWeave Reader requirements

Audience: maintainers and reviewers of the native reader

- **MR-BOUND-01:** MuWeave Reader owns only the optional native host, its
  bounded native capabilities, the host-to-worker protocol, and execution
  lifecycle. MuWeave owns parsing and evaluation, MuVocab owns semantic
  authoring values, and PyHTML owns document and `.work` serialization,
  freshness reconciliation, and the browser worksheet runtime.
- **MR-DOC-01:** The reader loads the exact standalone PyHTML artifact that an
  ordinary browser loads. A document without the reader remains usable; native
  capabilities are progressive enhancement and require no network service.
- **MR-DOC-02:** The reader exposes a visible native reload action, including
  `F5` and `Ctrl+R`, which reloads the original canonical local artifact rather
  than navigating the privileged main frame elsewhere.
- **MR-EXEC-01:** No notebook source executes automatically. The user initiates
  every run and grants explicit trust before the first run in a window.
  Execution has unrestricted current-user Python authority; process isolation
  and time limits are not represented as a security sandbox.
- **MR-HIGHLIGHT-01:** An enabled native notebook editor retains live syntax
  highlighting derived from MuWeave's authoritative, non-evaluating structural
  source analysis. Highlighting uses a versioned, size-bounded bridge request,
  preserves the edited source exactly, and never requests or implies execution
  trust. The transparent input and highlighted layer use identical text and box
  geometry, including trailing empty lines, and must not acquire independent
  scroll offsets. The browser must not maintain an independent MuWeave grammar.
- **MR-PROTOCOL-01:** Browser/host and host/worker boundaries use a closed,
  integer-versioned, size-bounded JSON protocol. At most one execution is in
  flight, and an independently terminable worker enforces a finite wall-clock
  limit.
- **MR-STATE-01:** A stable session retains user Python bindings and MuWeave
  configuration between manual runs. Each run creates fresh document
  structure and asset state, so prior counters, references, and placements do
  not contaminate it.
- **MR-MATH-01:** Every notebook execution uses the hosted publication's
  mathematical renderer and identifies that renderer in the response. The host
  rejects a mismatched result; unsupported notation does not introduce another
  mathematics runtime. Native styles replace the previous result's styles and
  reuse the publication's font resources.
- **MR-PERSIST-01:** PyHTML `.work` state may persist edited notebook source,
  but never persists dynamic rendered HTML. Runtime results
  do not mutate the author's original expansion or its embedded AI bundle.
- **MR-PERSIST-02:** For a hosted `name.html` or `name.htm`, the reader exposes
  only the fixed sibling `name.work` through a closed, size-bounded protocol.
  It loads that sidecar automatically, creates an absent or empty one without a
  picker, and uses an atomic replacement for saves. Invalid nonempty content
  fails without being overwritten.
- **MR-PERSIST-03:** Each native sidecar load identifies the exact bytes read.
  A save carries that identity as its expected base; immediately before atomic
  replacement the reader rereads the fixed sidecar and rejects the save as a
  conflict if those bytes have changed. A stale hosted view must never blindly
  overwrite a newer physical work state.
- **MR-NAV-01:** The privileged main frame remains bound to its original
  canonical local document. Explicit links are opened outside that frame.
- **MR-NAV-02:** Reading-position navigation neither reloads the document nor
  changes authored content or learner work. Manual-scroll recording is optional
  and confined to the main document, excluding nested editing and interactive
  surfaces. Restoring history must not create new reading-history entries;
  native navigation preferences and transient history are separate from `.work`.
