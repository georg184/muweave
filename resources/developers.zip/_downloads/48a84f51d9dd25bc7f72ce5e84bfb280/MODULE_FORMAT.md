# MuWeb module format
Audience: interactive-project developers and package maintainers

The current format version 3 packages one interactive application for
host-side composition in a deterministic ZIP-compatible file named
`<id>.muweb`. The archive is not a standalone learner deliverable. One
application may expose several named activities, and it may name pinned shared
runtime profiles without copying those runtime bytes. Consumers validate the
entire artifact before using any entry and never extract it into the worksheet
directory. Format versions 1 and 2 remain supported compatibility inputs.

## Source directory

The minimal build input is:

```text
motion-module/
├── muweave-module.json
└── embed.html
```

All paths are relative POSIX paths. Empty segments, `.`, `..`, leading `/`,
backslashes, control characters, duplicate spelling, Unicode-case collisions,
directories inside the archive, symbolic links, and special files are
rejected. Individual entries and the complete uncompressed artifact are
bounded by the public `MAX_*` constants.

The build command must write outside the source directory:

```console
muweb build motion-module ../motion.muweb
```

The output basename must agree exactly with the manifest `id`. Source mtimes,
permissions, traversal order, and manifest whitespace do not enter the output;
files are ordered and ZIP metadata is fixed. Running the same MuWeb release on
the same bytes consequently produces the same archive bytes and SHA-256
identity.

## Manifest

The exact version-3 members are:

```json
{
  "format": "muweave-interactive-module",
  "format_version": 3,
  "id": "motion",
  "version": "20260829.4",
  "entry": "embed.html",
  "canonical_url": "https://georg184.github.io/motion/",
  "title": {
    "de": "Bewegungsdiagramme",
    "en": "Motion diagrams"
  },
  "offline": true,
  "state_version": 1,
  "preferred_height": "11cm",
  "permissions": [],
  "ai": {
    "kind": "quiz",
    "learning_objectives": [
      "Interpret position and velocity diagrams"
    ]
  },
  "default_activity": "piecewise_uniform",
  "activities": {
    "uniform": {
      "canonical_url": "https://georg184.github.io/motion/?activity=uniform",
      "title": {
        "de": "Gleichförmige Bewegung",
        "en": "Uniform motion"
      },
      "preferred_height": "11cm",
      "ai": {
        "kind": "quiz",
        "learning_objectives": [
          "Read initial position and constant velocity from a position-time graph",
          "Draw a uniform position-time graph from initial position and velocity"
        ]
      }
    }
  },
  "runtime_requirements": {
    "math": "muweave-mathjax-4-svg-v1"
  }
}
```

- `format_version` changes only when archive or manifest interpretation is no
  longer compatible.
- `id` is a stable lowercase ASCII identifier and determines the filename.
- `version` belongs to the producing application and is not a schema number.
- Top-level `canonical_url`, `title`, `preferred_height`, and `ai` describe
  the named default activity.
- `canonical_url` is that activity's standalone printable HTTPS fallback.
- `title` contains one or more localized display titles.
- `offline` is always `true` in every supported version. It asserts that the
  entry and all declared host runtimes can be composed without network access;
  it does not claim that the `.muweb` archive is itself a standalone page.
- `state_version` is the positive integer schema of the JSON learner state.
  It changes only when old state needs migration; it is independent of both
  application and archive versions. A producer that increments it registers
  every supported adjacent migration through the packaged bridge; migration
  declarations do not belong in the manifest.
- `preferred_height` is the default activity's compact inline-layout hint with
  an explicit unit.
- `permissions` is empty. Unknown capabilities fail validation.
- `ai` is static semantic metadata, not executable tutoring behavior.
- `default_activity` is the stable activity selected when an author omits the
  activity name.
- `activities` maps every additional name to the same four metadata fields.
  It never repeats `default_activity`; all entries still use the one `entry`,
  module `version`, and `state_version`.
- `runtime_requirements` maps a stable lowercase role to one opaque pinned
  host profile. A role uses lowercase ASCII words separated by underscores.
  A profile uses lowercase ASCII components separated by `-`, `_`, or `.`.
  Neither spelling is a URL, path, npm/pip request, or executable source. An
  empty object means the entry needs no host-supplied runtime.

MuWeb validates and preserves runtime declarations but does not contain a
runtime registry. The consuming frontend owns profile support, verified local
bytes, ordering, injection into the isolated document, and content
deduplication. It must reject every unknown or unavailable profile before
publishing. Distinct module occurrences requesting the same profile therefore
need only one stored payload in the final document even though each isolated
JavaScript realm initializes its own runtime instance.

Activity names are stable lowercase ASCII words separated with underscores;
legacy hyphen-separated names remain readable. They select a logical
subapplication inside the one artifact. They are independent
of the host-selected `compact` or `full` presentation: presentation belongs to
bridge initialization and never to the manifest or learner-state payload.

A version-1 manifest has the earlier exact shape without `default_activity`,
`activities`, or `runtime_requirements`. Consumers expose it as one synthetic
activity named `main`. Version 2 adds the activity fields but has no runtime
requirements. Adding named activities requires format version 2 or 3; adding
host runtimes requires version 3 rather than silently extending an older
shape.

Unknown and missing members are errors. The JSON is strict UTF-8, has no
duplicate names or non-finite numbers, and is stored in MuWeb's canonical
compact representation inside the archive. Producers may keep indented JSON
in their source directory; `muweb build` canonicalizes it.

## Entry HTML and offline composition

`embed.html` is strict UTF-8 and contains exactly one `html`, `head`, and `body`
element plus `<!doctype html>`. Project-owned JavaScript and CSS are inline.
Declared images and similar active resources use data URLs; linked
stylesheets, script `src`, CSS imports, relative resource paths, forms with
actions, base elements, object elements, and meta refresh are rejected. A
shared host runtime is declared only in `runtime_requirements`; it never
appears as an external URL in the entry.

The head contains exactly one CSP meta element. At minimum its policy has:

```text
default-src 'none';
connect-src 'none';
object-src 'none';
base-uri 'none';
form-action 'none'
```

Specific directives may additionally allow inline code, data URLs, and Blob
URLs. They cannot grant an external origin. A normal HTTPS anchor is permitted
because it represents explicit learner navigation, not an offline runtime
dependency.

The packaged browser bridge must be inlined into the entry document. Any state
migrations are registered with that exact bridge before its DOM-ready
announcement; see `BRIDGE.md`. A later format version may define separately
content-addressed project resources; no supported version makes undeclared
relative archive files browser-addressable.

The final PyHTML file, rather than `embed.html` or `<id>.muweb`, is the
learner-facing offline unit. PyHTML must embed every selected entry and every
unique required runtime from its local pinned registry, then provide the
runtime to each sandboxed module before module code executes. The final file
must make no CDN request and require neither Node.js nor a local server.

Current PyHTML implements the closed
`math: muweave-mathjax-4-svg-v1` profile. A producer that needs that runtime
declares it in format three and omits the corresponding MathJax source from
its entry. Other role/profile pairs remain unsupported until a frontend pins
and implements them; they fail publication rather than triggering a download.

The same bridge supplies the host document's normal font size, line height,
and geometric size-step factor. Module CSS should derive ordinary typography
from its published custom properties, and JavaScript may use its signed finite
real-step helper. That helper rounds to the same `0.001 pt` quantum as
MuVocab's `µsize`. These are runtime presentation inputs and do not belong in
the module manifest or learner-state schema. The same applies to the compact
or full view: a module reads its activity and presentation through
`MuWeaveModuleBridge.getModuleContext()`.
