# Interactive web modules
Audience: MuWeave authors, AI authoring agents, and interactive-project developers

`block.interactive` places one validated external MuWeb application in a
portable MuWeave document. It is the sole MuWeb-application API: the
occurrence is an ordinary semantic block, may be numbered, and is
referenceable through its stable instance ID. There is no parallel top-level
`interactive(...)` command. Native slider-driven MuVocab graphics use the
separate `@g.interactive(..., parameter=ui.slider(...))` interface documented
under “Native parameter-driven graphics” in [AUTHORING.md](AUTHORING.md); they
do not load a `.muweb` artifact or an application runtime.
Use `block.applet` when such native content forms a reusable item whose PDF
shows only its linked print description. It is documented under
[native applet items](AUTHORING.md#native-applet-items) and does not introduce
another MuWeb loader.

Application source stays in its independent project repository. A document
resolves only the installed immutable artifact
`<interactive-directory>/<module-id>.muweb`; it never embeds a mutable source
checkout or downloads the public site while building.

MuWeave source executes unrestricted Python. A MuWeb artifact is separately
validated and is composed by PyHTML without network or same-origin access.
The `.muweb` file is not itself a learner-facing offline page; the finished
PyHTML document is. Use only author source and module artifacts you trust.

## Author API

The complete public call is:

```python
block.interactive(
    module_id,
    *,
    instance,
    activity=None,
    presentation=None,
    mode="embed",
    open="inline",
    height=None,
    title=None,
    numbered=False,
    tag=None,
)
```

The usual in-document form is:

```text
µblock.interactive(
    "motion",
    instance="kinematics-motion-1",
    activity="piecewise_uniform",
    presentation="compact",
    height="11cm",
)
```

- `module_id` is the manifest ID and filename stem. `"motion"` resolves only
  `motion.muweb` below the captured interactive directory.
- `instance` is both the block reference key and the stable learner-state key.
  It is required, unique in the complete logical document, and independent of
  numbering, source order, and rendered position.
- `activity` selects one activity declared by the artifact. Omitting it selects
  the manifest default. A format-version-1 artifact exposes the synthetic
  activity `main`.
- `presentation` is `"compact"` or `"full"`. Inline occurrences default to
  compact; tab occurrences default to full. This changes surrounding app
  chrome, not the activity or its learner state.
- `mode="embed"` uses the captured entry plus every locally resolved host
  runtime declared by its manifest. `mode="link"` publishes only the selected
  activity's canonical HTTPS URL and serializes no app bytes.
- `open="inline"` places a viewport in document flow. `open="tab"` supplies a
  launch control for a separate tab.
- `height` is an optional positive number of centimetres; `11` and `"11cm"`
  are equivalent. Omitting it uses the selected activity's manifest height.
- `title` overrides the localized activity title for this block.
- `numbered=True` consumes the common block counter. The default is unnumbered.
  `tag` is an independent visible designation.

An unnumbered occurrence remains referenceable:

```text
µblock.interactive(
    "motion",
    instance="motion-practice",
)

Öffne später wieder µref("motion-practice").
```

For a numbered occurrence, `µref("motion-practice")` uses the ordinary block
designation such as `Interaktiv 2.3`.

## Compact and full views

Activity and presentation solve different problems:

- `activity="uniform"` versus `activity="piecewise_uniform"` selects
  different subject matter or task behavior inside one application.
- `presentation="compact"` versus `presentation="full"` selects how much
  standalone page chrome surrounds that same activity.

A compact view keeps the actual task, controls, feedback, accessibility text,
and learner-state behavior. It omits the standalone introduction, global page
heading, navigation, language chrome when the host owns language, and similar
material already supplied by the MuWeave document. A full view retains the
application's complete chrome inside a PyHTML frame or tab; it does not turn
the `.muweb` archive into an independent deliverable.

Both views come from the same `embed.html`; do not build separate compact and
full artifacts. A producer may build its ordinary standalone site from the
same application sources, but that site and `embed.html` have different
publication boundaries. The PyHTML host sends the selection in bridge
initialization, and a module reads it through:

```javascript
const context = MuWeaveModuleBridge.getModuleContext();
const presentation = context?.presentation ?? "full";
document.documentElement.dataset.muweavePresentation = presentation;
```

For a static site, a query parameter may offer the same selection, but
standalone use should default to full. Project markup should identify its
full-only introduction and page chrome explicitly, for example:

```html
<header data-muweave-full-only>...</header>
<main>...activity controls...</main>
```

```css
html[data-muweave-presentation="compact"] [data-muweave-full-only] {
  display: none;
}
```

## Inline, offline tab, and online link

Use a full offline tab when the application needs more space:

```text
µblock.interactive(
    "motion",
    instance="motion-full-tab",
    activity="piecewise_uniform",
    open="tab",
)
```

An explicit compact tab is also valid. Use an online link only by deliberate
choice:

```text
µblock.interactive(
    "motion",
    instance="motion-online",
    activity="piecewise_uniform",
    mode="link",
    open="tab",
)
```

Link mode requires `open="tab"` and `presentation="full"`. Tab mode accepts no
`height`. Invalid combinations, unknown activities, missing libraries,
malformed artifacts, and duplicate instances are located author errors. An
offline request never silently degrades to a remote iframe or link.

## Configure the canonical library

These configuration surfaces are equivalent:

```console
export MUWEAVE_INTERACTIVE_DIR=/path/to/muweave_library/interactive
pyhtml lesson.muweave --interactive-dir /path/to/muweave_library/interactive
mucompose lesson.muweave --interactive-dir /path/to/muweave_library/interactive
```

Python context factories use `interactive_directory=Path(...)`. An explicit
CLI or Python path overrides the environment. One context validates and
captures the first requested artifact bytes, then reuses that immutable
snapshot for every occurrence of the module.

Module developers build and install artifacts with MuWeb:

```console
muweb build build/motion-module /tmp/motion.muweb
muweb validate /tmp/motion.muweb
muweb install /tmp/motion.muweb --interactive-dir "$MUWEAVE_INTERACTIVE_DIR"
```

See the [MuWeb module format](../../muweb/docs/MODULE_FORMAT.md) and
[bridge contract](../../muweb/docs/BRIDGE.md).

## Shared document typography

An isolated application cannot inherit outer CSS. PyHTML sends the retained
normal font size, line-height multiplier, and `typography.scale_factor` during
bridge initialization. The bridge publishes:

- `--muweave-body-font-size`;
- `--muweave-line-height`;
- `--muweave-size-factor`.

Use those properties for ordinary module text and `fontSizePt(step)` for the
same signed real size steps as `µsize[step]{...}`. Do not scale the entire app
with a CSS transform: it also changes hit testing, canvas coordinates, and
responsive geometry. Typography and presentation are view inputs and must not
be persisted as learner state.

## Target behavior

| Target | Result |
| --- | --- |
| PyHTML, embed/inline | Sandboxed offline iframe using the selected compact or full view. |
| PyHTML, embed/tab | Launch control for a host-owned offline tab using the same instance and state. |
| PyHTML, link/tab | External link to the selected activity's canonical HTTPS URL; no app bytes. |
| PyTeX5 | Referenceable block with linked localized title and a linked vector QR fallback. |
| PyMyST | Referenceable block linking to the selected canonical online activity. |
| PyAI | `interactive_activity` node with block identity, selected activity, URL, title, kind, and learning objectives; no executable bytes or presentation noise. |

Both PyAI views retain the supplied module/activity metadata, including module
and state versions, localized titles, explanations, and stable instance. An
item's containment and companion references supply the owning task context.
This is an authored activity declaration, not a learner session: absent
objectives and future randomized questions are not inferred or fetched.
See the [AI input contract](../../pyai/docs/BUNDLE.md#interactive-input-declarations).

Repeated embedded occurrences of identical entry bytes share one
content-addressed PyHTML object. Format-three modules can additionally declare
closed host-runtime profiles; the final frontend publication stores each
unique profile payload once and supplies it to every requesting isolated
module before application code executes. Current PyHTML implements
`math: muweave-mathjax-4-svg-v1`. A module using that profile omits MathJax
from its own entry; unknown profiles remain located publication errors.

## Learner state and replacement

PyHTML is the persistence authority. The adjacent `<document-name>.work` file
stores each module record under `instance`, including module ID, activity,
producer release, integer state schema, state, progress, and result.
Presentation is deliberately absent.

Replacing an HTML worksheet preserves a record when instance, module ID,
activity, and state schema remain compatible. Changing only the producer
release or switching compact/full view preserves state. Changing the selected
activity for an existing instance does not reinterpret the old state: the host
retains it in quarantine and starts the new activity cleanly.

When a schema increases, the host runs every module-owned adjacent migration
before initialization. It keeps the original record until the complete final
state has been validated and durably stored. Missing, malformed, timed-out,
failed, or future migrations retain the exact old record in quarantine and
produce a visible compatibility notice.

## Minimal workflow

```text
µsection(title="Gleichförmige Bewegung", level=1)

Untersuche die Orts- und Geschwindigkeitsdiagramme.

µblock.interactive(
    "motion",
    instance="kinematics-motion-1",
    activity="piecewise_uniform",
    height="11cm",
)
```

```console
mucompose lesson.muweave \
  --interactive-dir /path/to/muweave_library/interactive
```

This produces the PDF fallback, offline interactive HTML, and semantic AI
description from one target-neutral block occurrence. Preserve `instance`
across harmless document extensions and compact/full changes; change it when
the pedagogical activity represents genuinely new learner work.
