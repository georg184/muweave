# MuVocab to MuDoc integration

Audience: Python integrators and maintainers of structured document frontends

MuVocab owns the concrete placement policy for its semantic values. MuDoc
remains vocabulary-agnostic: it supplies immutable nodes and paragraph
parsing, but it never imports MuVocab or infers placement from Python class
names.

## Pipeline

Use one `TextCommandSchema` for parsing, target-neutral evaluation, and the
adapter:

```python
import mudoc
import muweave
import muvocab

source = """µsection(title="Kinematik")

Ein µbold{wichtiger µemph{Begriff}}.
"""
schema = muvocab.create_text_command_schema()
parsed = muweave.parse_string(
    source,
    source_name="lesson.muweave",
    text_command_schema=schema,
)
expanded = muweave.expand_parsed_typed(
    parsed,
    muvocab.create_document_context(schema),
)
document = muvocab.document_from_expansion(
    expanded,
    text_command_schema=schema,
)
prepared = muvocab.prepare_document(document)

assert isinstance(document, mudoc.Document)
assert prepared.document is document
```

`create_document_context(schema, ...)` installs the portable author namespace
and text-command bindings shared by the LaTeX, MyST, direct-HTML, and
semantic-AI factories.
It does not install any target renderer. The explicit `backend` source gate is
present for schema consistency but fails when evaluated because this context
has no target identity; source using that gate must be expanded in a concrete
target context. The document context is fresh on every call, so namespace
state, configuration, deferred work, files, index data, and symbol data are not
shared between documents.

`document_from_expansion(expansion, *, text_command_schema=None)` performs no
Python evaluation and calls no target renderer. Omitting the schema selects a
fresh standard MuVocab schema. Pass the actual schema whenever it has been
extended; its brace-body policies are authoritative.

`prepare_document(document)` is the next explicit target-neutral step. It
evaluates no Python and leaves the MuDoc tree unchanged. It traverses semantic
occurrences parent-first, assigns logical section numbers and the shared
portable block counter from each occurrence's configuration snapshot, gathers
all labels, validates companion owners, and resolves forward references only
after every target is known. The immutable result can be reused by multiple
serializers without creating or sharing LaTeX, MyST, HTML, or AI contexts.

## Explicit placement

The adapter currently maps concrete MuVocab occurrences as follows:

| MuDoc placement | MuVocab values |
| --- | --- |
| `Block` | sections and explicit page breaks; text, named, companion, and file-backed blocks; figures and generated axes; text, graphic, and item-owned canvas responses; multi-paragraph or explicitly block-structured solutions; columns and wraps; gap adjustments; index/symbol listings; block verbatim |
| `DisplayMath` | a single formula or structured aligned system returned by `block.equation` |
| `InlineMath` | inline mathematics, mathematical fences, intervals, vector lengths, scalar terms, points, vectors, matrices, physical units, and quantities |
| `Inline` | typography, abbreviations, definition terms, blanks, and footnotes; single-paragraph solutions; annotated plain values; images; references and targets; index/symbol markers; inline verbatim; `noin` and `qedsymbol` |

Unknown `SemanticValue` subclasses fail explicitly. `SymbolEntry` also fails
when placed directly because it is registry metadata; authors place
`symbols.term(...)` or `symbols.mark(...)` instead. Extensions therefore do
not become inline merely because `str(value)` happens to work.

## Structured and opaque bodies

Every semantic MuDoc node retains its original `muweave.ExpansionValue`.
Registered command bodies are additionally represented by ordered
`mudoc.SemanticBody` values:

- an expanded body keeps its original `TypedExpansion` and a recursively
  parsed `Document`;
- a deferred body reaches its semantic outer handler as exact source first,
  then keeps its independently evaluated `TypedExpansion` and recursively
  parsed `Document`;
- a raw body keeps its original protected `TypedExpansion` and has
  `document is None` and `opaque is True`.

The adapter never reconstructs structure from fields of the returned semantic
object and never scans a rendered string. This preserves exactly-once
evaluation, command provenance, and literal protection.

On this structured path, direct Python content owners also retain positional
`SemanticBody` values: `layout.columns`, `layout.wrap`, `lists.enumerated`,
ordinary/named/companion blocks, inline typography, and single-formula math.
MuVocab explicitly selects these content fields; MuWeave does not walk arbitrary
Python attributes. Their strings become parsed-source insertions, while already
constructed semantic children enter the same typed adapter path unchanged.
Annotation wrappers delegate materialization to the underlying type and reattach
their metadata. Existing registered bodies take precedence without reparsing.
Literal/verbatim payloads, keys, and descriptions are not opted in.

Nested objects therefore participate in the same preparation traversal for
numbering, targets, input identities, and state snapshots. Python arguments are
still evaluated eagerly before body expansion; there is no constructor replay.

## Portable annotations

`AnnotatedValue` attaches ordered `ValueAnnotation` metadata to one unchanged
plain or semantic value. It is deliberately a real wrapper rather than a
transparent proxy or subclass of the wrapped type. MuVocab's classifier and
structure preparer unwrap only for placement, numbering, target collection,
and reference resolution; the original `ExpansionValue` and annotation tuple
remain unchanged for serialization.

Controlled vocabulary transformations preserve annotations explicitly through
`transform_annotated(value, transform)`. Ordinary Python code is not made
annotation-aware by interception: a caller either transforms first, uses that
helper, or deliberately passes `annotated.value`. This keeps exactly-once
evaluation and ordinary Python type behavior visible.

`ColorAnnotation` carries one exact sRGB foreground without replacing its
wrapped value. Target serializers apply it after recursively rendering that
value, so nested typography, mathematics, references, tooltips, and block
semantics remain intact. Direct HTML projects it to exact CSS, LaTeX to
xcolor's `HTML` model, and MyST to inline HTML. Mathematical annotations have
to coincide with a formula, structured cell, or aligned-segment boundary;
MuVocab does not parse annotations out of an opaque TeX-style string.

`SpacingAnnotation` is consumed only while a structured target classifies
visible blocks for layout. MuVocab supplies each value's default `BoxSpacing`;
MuDoc's `plan_block_flow` then resolves the greater adjacent request and any
ordered `GapAdjustment` occurrences. The semantic tree stays unchanged, and
each invisible adjustment remains an original provenance-bearing `Block` node
in that tree. Body-font and explicit centimetre components remain distinct in
the resolved gap until the target serializer. Direct HTML and complete PyTeX5
documents use this planner.
Complete PyTeX5 serializes ordinary automatic boundaries with breakable
LaTeX spacing, so a following unbreakable block cannot pull the end of the
preceding paragraph onto the next page. Explicit `gap` directives and explicit
flow-edge spacing remain persistent at a physical page edge.
Low-level value-stream expansion and PyMyST reject structured spacing rather
than losing it.

Display-equation classification supplies compact ordinary edge requests plus
larger paragraph-break-specific requests for both sides. MuDoc selects those
requests against the complete retained boundary only after any invisible gap
directives have joined their surrounding whitespace. Direct adjacency leaves
the equation's automatic before request at zero, so the preceding paragraph's
ordinary after request controls that edge; its compact trailing request
controls direct prose after the display. A retained physical or generated
blank-line separator enlarges only the corresponding edge. This distinction
is neither encoded as target text nor recovered by scanning rendered output or
adjacent source provenance. A target serializer may preserve a native display
transition for direct adjacency; complete PyTeX5 does so on both edges instead
of emitting an additional paragraph gap.

The bare `newpage` value remains a zero-spacing page-edge block for structured
LaTeX. Its renderer emits the actual page-break syntax, while the flow planner
suppresses unrelated automatic gaps at that physical page edge. Direct
continuous HTML instead classifies the same semantic occurrence as a
`TransparentBlock`: it emits no marker and joins the exact source boundaries
around it. Consequently the ordinary visible boxes on either side determine
screen spacing just as if the inapplicable page marker were absent. Ordered
explicit `gap` operations remain attached to their original boundaries in
both cases. Complete PyTeX5 reproduces a blank line after `newpage` exactly
when the typed expansion contains that blank line, including one generated by
a trusted command. The generated LaTeX command remains self-delimiting
independently of source whitespace.

Direct HTML presents `TooltipAnnotation`; LaTeX and MyST preserve its complete
visible value without hover UI. A serializer must fail explicitly when
dropping metadata would also lose or misrepresent visible content.
PyAI retains tooltip text as a semantic explanation but drops color and
spacing annotations because they carry presentation rather than subject
meaning.

MuVocab declares all `block.*` brace bodies `deferred`. Their outer semantic
block is therefore evaluated first, and nested text or blocks are then
available recursively without parsing a rendered string. Both verbatim forms
remain `raw` and opaque. Expanded forms such as `bold`, `emph`, `m`, `fence`,
`Set`, `p`, `v`, and `layout` are likewise recursively structured, but their
bodies run before the handler.

`solution` and the body-bearing `response.canvas` form are also deferred. A
disabled omitted solution returns an empty body selection, so nested source is
never evaluated or represented. A retained generic solution is classified as
inline only when its body is one ordinary paragraph; multiple paragraphs or an
explicit block make it a block. A canvas always remains a block and retains
its one body as a conditional model-solution layer. Reserve-mode measurement
belongs to target serialization and never mutates the MuDoc tree.

## Prepared numbering and references

`muvocab.structure.PreparedDocument` retains these read-only views:

- `document` is the exact original MuDoc tree;
- `placements` maps each section or block `ExpansionValue` occurrence to a
  `SectionPlacement` or `BlockPlacement`;
- `targets` maps stable labels to `DocumentTarget` declarations;
- `references` maps each `ReferenceRequest` occurrence to its target and
  concrete built-in display facet, or to custom text policy;
- `configuration` contains the initial document-wide settings captured before
  body evaluation;
- `outline` maps section occurrences, in structural order, to immutable
  `muvocab.contents.OutlineEntry` values;
- `toc_options` contains the validated initial `toc` and `toc.max_level`
  settings as `muvocab.contents.TableOfContentsOptions`;
- `toc_entries` is a tuple selecting visible directory entries from the full
  outline, or an empty tuple when `toc` is false.

The maps use `ExpansionValue` identity because the typed result is explicitly
process-local. No semantic value is copied or mutated. `SectionPlacement`
stores the effective level and dot-separated number. `BlockPlacement` stores
the allocated automatic number separately from the configured presentation
position. For `block.equation(..., numbering="rows")`, its `row_numbers`
tuple has one entry per semantic equation row; `None` marks a row that did not
consume the counter. The outer `number` is then `None`. Multiple row labels
may resolve to the same parent `ExpansionValue` occurrence while retaining
their independently allocated numbers and reference capabilities. A tag can
therefore be a target designation without consuming the automatic counter
selected for that occurrence.

Configuration snapshots preserve source order. In this example the outer
block stays unnumbered, while the nested and later blocks consume `1` and `2`:

```text
µblock.text{
outer

µconfig.set("block.default_numbered", True)
µblock.text{inner}
}
µblock.text{later}
```

A reference request is prepared only after every local target has been
collected. Missing targets, duplicate labels, invalid companion owners, and
unsupported display facets raise source-located `MuWeaveReferenceError`
before any target serializer runs.

### Complete outline and contents selection

An `OutlineEntry` retains the exact section `title`, effective zero-based
`level`, allocated `number` (or `None`), navigation `anchor`, and
`parent_anchor`. Its parent is the nearest preceding heading at a shallower
level. Skipped levels retain the existing structural warning but create no
synthetic headings. Repeated titles and repeated unlabeled file insertions
remain distinct occurrences; `File.insert(level_offset=...)` is already
accounted for in their effective levels. A level-0 heading is content, not
automatically document-title metadata, and unnumbered headings remain in the
outline.

Explicit section labels are reused verbatim as anchors. Unlabeled headings
get deterministic document-local keys such as `muweave-section-1`. Allocation
occurs after collecting all targets; numeric suffixes avoid collisions even
with a label declared later in the source. These keys neither enter `targets`
nor provide a new `ref(...)` API. They are navigation identities within the
prepared artifact, not durable author labels across arbitrary source edits.

```python
prepared = muvocab.prepare_document(
    document,
    configuration={"toc": True, "toc.max_level": "2"},
)
all_headings = tuple(prepared.outline.values())
visible_contents = prepared.toc_entries
```

`toc` requires a real boolean and defaults to `True`. `toc.max_level`
defaults to `2` and accepts an integer from 0 through 5 or its decimal string
from MuCLI. Invalid values fail even for a document without headings or with
`toc=False`. Visibility/depth do not modify the original `Document`, its
placements, references, or full outline. Adapters use their initial
configuration snapshot, not the final mutable context, for this whole-document
presentation policy.

The shared foundation is available through the HTML, LaTeX, and AI adapters.
The HTML adapter emits the prepared anchors and forwards the selected view as
PyHTML's generic `HtmlNavigationEntry` tuple, leaving panel layout and browser
behavior to PyHTML. Every heading receives its anchor, even with `toc=False`.
Shell-free notebook results prepend the frontend's unique per-render
`heading_id_prefix` to heading IDs and local references to those headings;
they neither duplicate compiled heading IDs nor create another document
contents panel. This namespace is runtime output identity, not a persistent
author-reference API. It does not change unrelated block/response identities.
The LaTeX adapter projects the selected view into PyTeX5's generic
`LatexNavigationEntry` tuple. Every heading retains a native label destination,
including automatic outline anchors. The adapter suppresses native automatic
contents writes and emits exactly the selected prepared entries through the
frontend's navigation helper. Native heading display numbers use the prepared
number, including deep headings and headings below unnumbered parents;
LaTeX's own counter-depth defaults cannot silently change the display.
PyTeX5 owns the front list and actual page-number resolution. AI serialization
keeps its existing full heading structure without adding a duplicate list.

Before adaptation, every file-backed block is a MuVocab request rather than a
partially classified document node. During typed expansion MuVocab resolves its
selected physical range, applies the source-declared or explicit kind, and
replaces the request with the corresponding direct block value. The selected
range becomes that value's structured parsed body. Consequently neutral
`block.from_file(...)` reaches `prepare_document` with an authoritative kind,
normal numbering defaults, nested semantic content, and physical provenance;
the preparer never guesses from a filename or unresolved request.

Selected Python parameters can use the same typed child mechanism without
pretending to be brace bodies. MuVocab's typed adapters currently recognize
active MuWeave source in a quoted `length` value and in `g.axis`'s `x` and
`y` strings, parse each selected value once, and attach it to
`ExpansionValue.arguments` under its public parameter name. `_DocumentAdapter`
converts those entries into the semantic node's read-only named `SemanticBody`
mapping. They participate in the same source-ordered state timeline and global
deferred/reference finalization as positional bodies. HTML, LaTeX, and AI
adapters recursively render that body in inline flow; none converts it through
another target merely to recover a string.

## Boundary

The adapter produces coarse document placement and nested body structure;
`prepare_document` performs the current section/block numbering and local
reference transform. Directory assembly and further validation remain later
tree transforms. LaTeX, MyST, and direct HTML serialization, escaping,
templates, assets, and publication remain frontend responsibilities.
